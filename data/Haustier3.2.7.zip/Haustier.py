from tkinter import HIDDEN, NORMAL, Tk, Canvas, Button, FLAT, NW, simpledialog, W, messagebox
import random, pygame, time
from winsound import Beep
import pyautogui as py

pygame.mixer.init()

score = 0
scoret = 0

def check_aktien():
    with open("./programdata/haustier/aktien/teilnehmer.txt", "r") as neu:
        teilnehmer = list(neu.read().split())
        neu.close()
    if c.plus in teilnehmer:
        root.title("Molly die Maus AG")
        return True
    else:
        return False

def alter():
    todolist = ["Entwickleroptionen", "Sounds an", "Sounds aus", "Vollbild an", "Vollbild aus", "Aktien aktivieren"]
    if check_aktien():
        todolist.remove("Aktien aktivieren")
    x = py.confirm("Was wollen Sie ändern?", "OPTIONEN", buttons=(tuple(todolist)))
    if x == "Sounds an":
        c.playmusic = True
    elif x == "Sounds aus":
        c.playmusic = False
    elif x == "Vollbild an":
        root.attributes("-fullscreen", True)
    elif x == "Vollbild aus":
        root.attributes("-fullscreen", False)
    elif x == "Entwickleroptionen":
        dev()
    elif x == "Aktien aktivieren":
        root.title("Molly die Maus AG")
        with open("./programdata/haustier/aktien/teilnehmer.txt", "r") as neu:
            teilnehmer = list(neu.read().split())
            neu.close()
        with open("./programdata/haustier/aktien/teilnehmer.txt", "a") as neu:
            neu.write(" " + c.plus)
            neu.close()
        with open("./programdata/haustier/aktien/münz.txt", "a") as neu:
            neu.write(str(c.münzen))
            neu.close()
        for i in teilnehmer:
            with open("./programdata/haustier/aktien/anteile" + i + ".txt", "a") as neu:
                neu.write(" 0")
                neu.close()
        with open("./programdata/haustier/aktien/bank.txt", "a") as neu:
            neu.write(" 0")
            neu.close()
        with open("./programdata/haustier/aktien/anteile" + c.plus + ".txt", "a") as neu:
            neu.write(c.plus + " ")
            for i in teilnehmer:
                neu.write("0 ")
            neu.write("100")
            neu.close()

def toggle_eyes():
    current_color = c.itemcget(eye_left, "fill")
    new_color = c.body_color if current_color == "white" else "white"
    current_state = c.itemcget(pupil_left, "state")
    new_state = NORMAL if current_state == HIDDEN else HIDDEN
    c.itemconfigure(pupil_left, state=new_state)
    c.itemconfigure(pupil_right, state=new_state)
    c.itemconfigure(eye_left, fill=new_color)
    c.itemconfigure(eye_right, fill=new_color)
    
def blink():
    toggle_eyes()
    root.after(300, toggle_eyes)
    root.after(3000, blink)
    if c.fette_level > 3 and c.fette_level < 11:
        c.coords(body, 25, 30, 390, 360)
    if c.fette_level < 3 and c.fette_level > -1:
        c.coords(body, 45, 30, 375, 360)
    if c.fette_level > 10 and c.fette_level <= 20:
        c.coords(body, 10, 30, 410, 360)
    if c.fette_level < 0:
        c.coords(body, 55, 30, 365, 360)
    if c.fette_level > 20:
        c.coords(body, 3, 30, 417, 360)
    
def toggle_pupils():
    if not c.eyes_crossed:
       c.move(pupil_left, 10, -5)
       c.move(pupil_right, -10, -5)
       c.eyes_crossed = True
    else:
        c.move(pupil_left, -10, 5)
        c.move(pupil_right, 10, 5)
        c.eyes_crossed = False
        
def toggle_tongue():
    if not c.tongue_out:
        c.itemconfigure(tongue_tip, state=NORMAL)
        c.itemconfigure(tongue_main, state=NORMAL)
        c.tongue_out = True
    else:
        c.itemconfigure(tongue_tip, state=HIDDEN)
        c.itemconfigure(tongue_main, state=HIDDEN)
        c.tongue_out = False
        
def cheeky(event):
    toggle_tongue()
    toggle_pupils()
    hide_happy(event)
    root.after(1000, toggle_tongue)
    root.after(1000, toggle_pupils)
    return

def show_happy(event):
    global scoret
    if (20 <= event.x <= 350) and (20 <= event.y <= 350):
        c.itemconfigure(cheek_left, state=NORMAL)
        c.itemconfigure(cheek_right, state=NORMAL)
        c.itemconfigure(mouth_happy, state=NORMAL)
        c.itemconfigure(mouth_normal, state=HIDDEN)
        c.itemconfigure(mouth_sad, state=HIDDEN)
        if c.happy_level < c.fette_level:
            if c.nebenwirkung == True:
                c.happy_level += random.randint(0, 1)
            else:
                c.happy_level += 1
            if c.happy_level > (c.fette_level * 0.5):
                if c.playmusic == True:
                    pygame.mixer.music.load("./programdata/haustier/music/powerup.mp3")
                    pygame.mixer.music.set_volume(0.1)
                    pygame.mixer.music.play()
    return

def hide_happy(event):
    c.itemconfigure(cheek_left, state=HIDDEN)
    c.itemconfigure(cheek_right, state=HIDDEN)
    c.itemconfigure(mouth_happy, state=HIDDEN)
    c.itemconfigure(mouth_normal, state=NORMAL)
    c.itemconfigure(mouth_sad, state=HIDDEN)
    return

def sad():
    if c.happy_level <= 0 and c.happy_level > -25:
        c.itemconfigure(mouth_happy, state=HIDDEN)
        c.itemconfigure(mouth_normal, state=HIDDEN)
        c.itemconfigure(mouth_sad, state=NORMAL)
    c.happy_level -= 1
    root.after(800, sad)
    root.after(2000, vampir)

def vampir():
    if c.playmusic == True:
        if c.happy_level < -25:
            pygame.mixer.music.load("./programdata/haustier/music/PUNCH.mp3")
            pygame.mixer.music.set_volume(5.0)
            pygame.mixer.music.play()
            if c.happy_level < -99:
                Beep( 3500, 400 )
            root.after(2000, vampir)
    
def change_color():
    pet_colors = ["SkyBlue1", "tomato", "yellow", "purple", "green", "orange", "silver", "brown", "white"]
    c.body_color = random.choice(pet_colors)
    c.itemconfigure(body, outline=c.body_color, fill = c.body_color)
    c.itemconfigure(ear_left, outline=c.body_color, fill = c.body_color)
    c.itemconfigure(ear_right, outline=c.body_color, fill = c.body_color)
    c.itemconfigure(foot_left, outline=c.body_color, fill = c.body_color)
    c.itemconfigure(foot_right, outline=c.body_color, fill = c.body_color)
    root.after(10000, change_color)

def feed(x="hallo"):
    global score
    if c.geputzt == 0:
        c.fette_level += 1
        c.geputzt = 1
        root.after(5000, ausscheidungen)
        root.after(5000, putzerlaubnis)
        ran = 6 + c.impfung_level if c.impfung_level >= -5 else 1
        if random.randint(1, ran) == 1:
            virus()
    if x == "impf" and c.geputzt == 0 and c.gegessen == 0:
        if c.playmusic:
            pygame.mixer.music.load("./programdata/haustier/music/dreck.mp3")
            pygame.mixer.music.set_volume(10.0)
            pygame.mixer.music.play()
        c.fette_level = round(c.fette_level * 0.97)
        c.happy_level = round(c.happy_level * 0.93)
        c.impfung_level = round(c.impfung_level * 0.99)
        score = round(score * 0.987654321)

def delete_virus():
    c.delete(c.virus)

def virus():
    global score
    x = py.confirm("Virus aufhalten? Dies kostet ?? Münzen.", "VIRUSANGRIFF!", buttons=("JA", "NEIN"))
    if x != "JA":
        score = round((score * 0.72727))
        c.happy_level -= c.fette_level
        c.fette_level = round((c.fette_level * 0.90123))
        c.virus = c.create_oval(0, 0, 444, 399, outline="white", fill="red")
        if c.playmusic:
            pygame.mixer.music.load("./programdata/haustier/music/corona.mp3")
            pygame.mixer.music.set_volume(10.0)
            pygame.mixer.music.play()
        c.impfung_level += random.randint(0, 12)
        root.after(3000, delete_virus)
    else:
        c.münzen -= random.randint(random.randint(1, 50), random.randint(70, 170))

def putzerlaubnis():
    if not c.nebenwirkung:
        c.gegessen = 0
    else:
        root.after(2500, putzerlaubnis)
     
def fettabzug():
    c.fette_level -= 1
    root.after(30000, fettabzug)

def ausscheidungen():
    c.create_oval(380, 410, 410, 380, outline="brown", fill="brown")
    c.create_oval(415, 430, 430, 415, outline="brown", fill="brown")
    c.create_oval(380, 430, 430, 380, outline="brown", fill="brown")
    c.create_oval(350, 355, 355, 350, outline="brown", fill="brown")
    c.create_oval(415, 417, 417, 415, outline="brown", fill="brown")
    c.create_oval(380, 390, 390, 380, outline="brown", fill="brown")

def ausscheidungen2():
    c.create_oval(380, 410, 410, 380, outline="yellow", fill="yellow")
    c.create_oval(415, 430, 430, 415, outline="yellow", fill="yellow")
    c.create_oval(380, 430, 430, 380, outline="yellow", fill="yellow")
    c.create_oval(350, 355, 355, 350, outline="yellow", fill="yellow")
    c.create_oval(415, 417, 417, 415, outline="yellow", fill="yellow")
    c.create_oval(380, 390, 390, 380, outline="yellow", fill="yellow")

def putzen():
    if c.gegessen == 0:
        c.gegessen = 1
        c.create_oval(380, 410, 410, 380, outline="dark blue", fill="dark blue")
        c.create_oval(415, 430, 430, 415, outline="dark blue", fill="dark blue")
        c.create_oval(380, 430, 430, 380, outline="dark blue", fill="dark blue")
        c.create_oval(350, 355, 355, 350, outline="dark blue", fill="dark blue")
        c.create_oval(415, 417, 417, 415, outline="dark blue", fill="dark blue")
        c.create_oval(380, 390, 390, 380, outline="dark blue", fill="dark blue")
        c.geputzt = 0

def Zzz_reg():
    Zzz()
    root.after(c.save_setting, Zzz_reg)

def Zzz():
    global score
    with open(c.speicherort, "w") as saved:
        write = str(c.münzen) + " " + str(c.inflation) + " " + str(c.happy_level) + " " + str(c.fette_level) + " " + str(c.impfung_level) + " " + str(score) + " " + str(c.aktiverg)
        printlk("Speicherstand " + write)
        saved.write(write)
        saved.close()

def save_setting():
    schlafzeit = int(simpledialog.askstring("Speichereinstellungen", "Alle wie viele Sekunden soll der Spielstand gespeichert werden?\nMöglich zwischen 5 und 45. Bei ungültiger Eingabe 20."))
    speicherort = "./programdata/haustier/saved/saved"
    c.plus = simpledialog.askstring("Speicherort", "Speicherort angeben.\n")
    print(c.plus)
    speicherort += str(c.plus)
    c.speicherort = (speicherort + ".txt")
    c.save_setting = 1000*schlafzeit if schlafzeit >= 5 and schlafzeit <= 45 else 20000
    check_aktien()

def load_data():
    global score
    save_setting()
    try:
        with open(c.speicherort, "r") as saveddata:
            datastr = saveddata.read()
            c.münzen, c.inflation, c.happy_level, c.fette_level, c.impfung_level, score, c.aktiverg = datastr.split()
            c.happy_level = int(c.happy_level)
            c.fette_level = int(c.fette_level)
            c.impfung_level = int(c.impfung_level)
            c.münzen = int(c.münzen)
            c.inflation = int(c.inflation)
            c.aktiverg = int(c.aktiverg)
            score = int(score)
            saveddata.close()
    except:
        for i in [c.münzen, c.inflation, c.happy_level, c.fette_level, c.impfung_level, score, c.aktiverg]:
            i = 0
        c.happy_level += 5

def end():
    Zzz()
    quit()
        
def Trinken():
    if c.geputzt == 0:
        c.fette_level += 1
        c.geputzt = 1
        root.after(5000, ausscheidungen2)
        root.after(5000, putzerlaubnis)
        if random.randint(1, (5 + c.impfung_level)) == 1:
            virus()

def shop():
    global score
    printlk("Im Shop")
    kaufen = py.confirm("Was wollen Sie kaufen?", "Shop", buttons=tuple(c.produkte), timeout=10000)
    preis = c.preise[c.produkte.index(kaufen)]
    preis = round((preis * (1 + 0.01 * c.inflation)))
    really = py.confirm("Dieses Angebot kostet " + str(preis) + " Münzen!", "KOSTEN", buttons=("OK", "Quit"), timeout=10000)
    if really == "OK":
        if preis > 0:
            if c.münzen >= preis:
                shopkauf(kaufen, preis)
                printlk("Kauf ausgeführt")
        else:
            shopkauf(kaufen, preis)

def shopkauf(kaufen, preis):
    global score
    y = False
    if kaufen == "2*Punkte":
        score *= 2
    elif kaufen == "10%Punkte":
        score = round(score * 1.1)
    elif kaufen == "ImpfungBoost":
        c.impfung_level += 12
        c.happy_level = round((c.happy_level * -0.12345))
    elif kaufen == "BigMac":
        c.fette_level += 9
        c.happy_level -= 33
        if random.randint(1, (7 + c.impfung_level)) == 1:
            virus()
    elif kaufen == "HappyBoost":
        c.happy_level += 123
    elif kaufen == "Lotterie":
        c.happy_level += 12
        c.münzen += round((random.randint(-3, 17) * (1 + (0.0077 * c.inflation))))
    elif kaufen == "MiniLotto":
        c.happy_level += 1
        c.münzen += round((random.randint(-1, 5) * (1 + (0.0011 * c.inflation))))
    elif kaufen == "Deflation":
        deflation = preis + random.randint(7, 12)
        c.inflation -= deflation
        c.happy_level += 10
        c.fette_level -= 1
    elif kaufen == "Ereignisboost":
        c.aktiverg += 1
    elif kaufen == "Ereignissenkung":
        c.aktiverg -= 1
    else:
        c.münzen -= preis
        y = True
    c.münzen -= preis
    inflation_kauf(preis)
    if y == False:
        shop()

def inflation():
    global score
    if score >= 1111111:
        infl = random.randint(3, 12)
        c.inflation += infl
        printlk("INFLATION: " + str(infl))
    if c.inflation < 0:
        c.inflation = round(c.inflation * -(random.uniform(1.298, 12.98)))
        c.inflation -= 10
    root.after((random.randint(111111, 345678)), inflation)

def ergInfl():
    c.inflation += 1

def inflation_kauf(preis):
    c.inflation += preis

def impfung_down():
    c.impfung_level -= 1
    root.after(55000, impfung_down)

def impferlaubnis():
    c.impferlaubnis = True

def Impfung():
    if c.impferlaubnis:
        feed(x="impf")
        c.impfung_level += 1
        nebenwirkung()
        c.impferlaubnis = False
        root.after(10000, impferlaubnis)

def nebenwirkung():
    c.happy_level = round(c.happy_level * -0.88888)
    c.geputzt = 1
    c.nebenwirkung = True
    root.after(15000, nebenwirkungweg)

def nebenwirkungweg():
    c.nebenwirkung = False

def ereignis():
    global score
    printlk("EREIGNIS!")
    c.ausführungen.remove(c.ausführungen[0])
    erg = random.choice(c.ereignisse)
    if erg == "Bankzinsen":
        c.münzen = round(c.münzen * 1.123456789012345)
    elif erg == "Neue Haltungsauflagen":
        c.münzen -= 2
        c.happy_level -= 100
        c.fette_level -= 2
        score = round(score * 0.98765)
    elif erg == "Raub":
        c.münzen = round(c.münzen * 0.34567) if c.münzen >= 1 else -1
    elif erg == "Inflation":
        ergInfl()
    elif erg == "Erfindung":
        c.inflation -= random.randint(1, 5)
    elif erg == "Mehr Ereignisse":
        c.aktiverg += random.randint(0, random.randint(0, 2))
    elif erg == "Weniger Ereignisse":
        c.aktiverg -= 1 if c.aktiverg > 1 else 0
    elif erg == "Aktiendividende" or erg == "Jahresrente":
        c.münzen += 3
    elif erg == "Party":
        score += 123456789
        time.sleep(3)
        score -= 123456780
    elif erg == "Katta Enterprises!":
        c.münzen += 12
        inflation_kauf(random.choice(c.preise))
    elif erg == "Aktienabsturz":
        c.münzen -= 3
    else:
        pass
    x = root.after(123456, ereignis)
    c.ausführungen.append(x)
    messagebox.showinfo("EREIGNIS!", "Das Ereignis " + erg + " ist eingetreten.")
    printlk(str(len(c.ausführungen)) + " aktive Ereignisse")

def neuerg():
    c.aktiverg += 1

def zinsen():
    l = [1, 1, 1, 2, 3]
    for i in range(50 - (0 + c.münzen)):
        l.append(0)
    c.münzen -= random.choice(l)

def dev():
    x = py.password("Passwort eingeben!", "PASSWORT", timeout=5000)
    if x == "<|>":
        x = py.confirm("Option auswählen.", "ENTEICKLER", buttons=("M", "S", "F", "E", "I", "P", "%"), timeout=7000)
        if x == "M":
            c.münzen += 10000
        elif x == "S":
            c.happy_level += 100000
        elif x == "F":
            c.fette_level += 10000
        elif x == "E":
            c.aktiverg -= 1
        elif x == "I":
            c.impfung_level += 7
        elif x == "P":
            global score
            score += 1000000000
        elif x == "%":
            c.inflation -= 222

def ueberweisung(user, wert: int, aktuser=False):
    if aktuser:
        c.münzen += wert
    else:
        with open("./programdata/haustier/saved/saved" + user + ".txt", "r") as file:
            liste = list(file.read().split())
            file.close()
        alt = int(liste.pop(0))
        liste.insert(0, str(wert + alt))
        with open("./programdata/haustier/saved/saved" + user + ".txt", "w") as file:
            for i in liste:
                file.write(i + " ")

def zahlung(von, nach, wert: int, special="v", spcaktiv=False):
    if spcaktiv:
        if special == "v":
            ueberweisung(von, (-1 * wert), aktuser=True)
            ueberweisung(nach, wert)
        else:
            ueberweisung(von, (-1 * wert))
            ueberweisung(nach, wert, aktuser=True)
    else:
        ueberweisung(von, (-1 * wert))
        ueberweisung(nach, wert)

def börse():
    #Teilnehmer ermitteln
    with open("./programdata/haustier/aktien/teilnehmer.txt", "r") as teil:
        r = teil.read()
        teil.close()
    teilnehmerlist = list(r.split(" "))
    print(teilnehmerlist)#

    #Aktienwerte ermitteln
    aktienwert = 0
    wertlist = []
    münzlist = []
    liste = []
    for i in teilnehmerlist:
        with open("./programdata/haustier/saved/saved" + i + ".txt", "r") as file:
            liste = list(file.read().split())
            file.close()
        happylevel = int(liste[2]) if int(liste[2]) <= int(liste[3]) else int(liste[3])
        aktienwert = round(0.003 * happylevel * int(liste[3]) + int(liste[4]) * 0.1)
        wertlist.append(aktienwert)
        münzlist.append(int(liste[0]))


    #alte Münzstände auslesen
    altemünzen = []
    with open("./programdata/haustier/aktien/münz.txt", "r") as file:
        altemünzen = list(file.read().split())
        file.close()

    #Anteile auslesen
    anteilelist = []
    for i in teilnehmerlist:
        with open("./programdata/haustier/aktien/anteile" + i + ".txt", "r") as file:
            anteilelist.append(file.read())

    printlk("Initialisierung abgeschlossen")
    
    #Dividenden auszahlen
    anteilelist2 = anteilelist
    for i in anteilelist2:
        i2 = list(i.split())
        owner = i2.pop(0)
        d = 0
        ownerindex = teilnehmerlist.index(owner)
        for h in i2:
            wert = round((int(h) / 100) * (int(münzlist[ownerindex]) - int(altemünzen[ownerindex])))
            user = teilnehmerlist[d]
            if not user == owner and not wert == 0:
                if user == c.plus:
                    zahlung(owner, user, wert, special="n", spcaktiv=True)
                elif owner == c.plus:
                    zahlung(owner, user, wert, spcaktiv=True)
                else:
                    zahlung(owner, user, wert)
                py.alert(str(wert) + " wurde an " + user + " von " + owner + " überwiesen.", "Dividende")
            d += 1
            print(d)#

    printlk("Dividenden ausgezahlt")

    #Bankanteile auslesen
    with open("./programdata/haustier/aktien/bank.txt", "r") as file:
        banklist = list(file.read().split())
        file.close()

    printlk("Bank geladen")

    aktiv = c.plus
    while True:
        aktion = py.confirm("Welche der folenden Optionen wollen Sie durchführen?", "Börse",\
                            buttons=("Aktie kaufen", "Aktie verkaufen", "Firma übernehmen", "Quit"))
        if aktion == "Aktie kaufen":
            vonwem = py.confirm("Von welchem Nutzer wollen Sie Aktien kaufen?", "Von Wem?", buttons=tuple(teilnehmerlist))
            for i in anteilelist:
                if vonwem in i:
                    anteil = i
                    index = anteilelist.index(i)
            print(anteil, index)
            anteile = list(anteil.split())
            anteile.pop(0)
            for i in range(0, len(anteile)):
                anteile[i] = int(anteile[i])
            userindx = teilnehmerlist.index(aktiv)
            zielindx = teilnehmerlist.index(vonwem)
            for i in range(len(banklist)):
                banklist[i] = int(banklist[i])
            anzahl = int(py.prompt("Wie viele Aktien möchten Sie kaufen?\nMaximal sind " + str(banklist[zielindx]) + " möglich.", "Anzahl"))#Maximalanzahl ermitteln
            if banklist[zielindx] >= anzahl:
                anteile[userindx] += anzahl
                banklist[zielindx] -= anzahl
                wert = wertlist[zielindx] * anzahl
                py.alert("Sie geben " + str(wert) + " aus!", "!")
                ueberweisung(aktiv, (-1 * wert),aktuser=True)
                anteile.insert(0, vonwem)
                anteil = ""
                for i in range(0, len(anteile)):
                    anteile[i] = str(anteile[i])
                for i in anteile:
                    anteil += i
                    anteil += " "
                anteilelist[index] = anteil
        elif aktion == "Aktie verkaufen":
            userindx = teilnehmerlist.index(aktiv)
            for i in anteilelist:
                if aktiv in i:
                    akt = i
                    index = anteilelist.index(i)
            aktlist = list(akt.split())
            aktlist.pop(0)
            for i in range(len(aktlist)):
                aktlist[i] = int(aktlist[i])
            for i in range(len(banklist)):
                banklist[i] = int(banklist[i])
            print(aktlist)#
            anzahl = int(py.prompt("Wie viele ihrer Aktien möchten Sie verkaufen?\nMaximal sind " + str(aktlist[index]) + " möglich.", "Anzahl"))#Maximalanzahl ermitteln
            if aktlist[userindx] >= anzahl:
                aktlist[userindx] -= anzahl
                banklist[userindx] += anzahl
                for i in range(len(aktlist)):
                   aktlist[i] = str(aktlist[i])
                aktlist.insert(0, aktiv)
                akt = ""
                for i in aktlist:
                    akt += i
                    akt += " "
                anteilelist[index] = akt
                wert = wertlist[userindx] * anzahl
                py.alert("Sie bekommen " + str(wert) + " !", "!")
                ueberweisung(aktiv, wert, aktuser=True)
        elif aktion == "Firma übernehmen":
            """user = py.confirm("Wessen AG wollen Sie verwalten?", "Firma übernehmen", buttons=teilnehmerlist)"""
            py.alert("Feature noch nicht verfügbar.", "BETA")
        else:
            break
        printlk("Aktion durchgeführt")

    #neue Münzstände eintragen
    münzlist = []
    liste = []
    for i in teilnehmerlist:
        with open("./programdata/haustier/saved/saved" + i + ".txt", "r") as file:
            liste = list(file.read().split())
            file.close()
        münzlist.append(liste[0])
    with open("./programdata/haustier/aktien/münz.txt", "w") as file:
        for i in münzlist:
            file.write(str(i) + " ")
        file.close()

    #neue Anteile eintragen
    for i in teilnehmerlist:
        with open("./programdata/haustier/aktien/anteile" + i + ".txt", "w") as file:
            file.write(anteilelist[teilnehmerlist.index(i)])

    #Bank aktualisieren
    with open("./programdata/haustier/aktien/bank.txt", "w") as file:
        for i in banklist:
            file.write(str(i) + " ")
        file.close()

    printlk("Änderungen gespeichert")

def zeige_impfung():
    impfung = c.impfung_level
    c.itemconfig(impfung_text, text=str(impfung))
    root.after(1000, zeige_impfung)

def zeige_happy():
    happy = c.happy_level
    c.itemconfig(happy_text, text=str(happy))
    root.after(1000, zeige_happy)
               
def zeige_fette():
    fette = c.fette_level
    c.itemconfig(feed_text, text=str(fette))
    root.after(1000, zeige_fette)

def zeige_punkte():
    global score, scoret
    scoret = 2 * c.happy_level + round((c.happy_level / 2) * c.fette_level)
    score += scoret
    c.itemconfig(score_text, text=str(score))
    c.punkte_verdient += scoret
    if c.punkte_verdient >= 1000000:
        c.münzen += 1
        c.punkte_verdient = 0
    c.letzte_punkte = score
    c.letzteausführung = root.after(1000, zeige_punkte)

def zeige_tendenz():
    global scoret
    c.itemconfig(tendenz_text, text=str(scoret))
    root.after(1000, zeige_tendenz)

def zeige_münzen():
    if c.münzen < 0:
        zinsen()
    münzen = c.münzen
    c.itemconfig(münzen_text, text=str(münzen))
    root.after(1000, zeige_münzen)

def zeige_inflation():
    inflation = c.inflation
    c.itemconfig(inflation_text, text=str(inflation))
    root.after(1000, zeige_inflation)

def zeige_erg():
    erg = c.aktiverg
    c.itemconfig(erg_text, text=str(erg))
    root.after(1000, zeige_erg)

def neuerpreis(neu):
    if neu == "q":
        c.quitpreis = random.randint(-1, 17)
    elif neu == "e":
        c.ergpreis = random.randint(-4, 12)
    c.preise = [33, 12, 9, 3, 2, 7, 3, 12, c.ergpreis, 12, c.quitpreis]

def neuprq():
    neuerpreis("q")
    root.after(4444, neuprq)

def neupre():
    neuerpreis("e")
    root.after(4444, neupre)

def prüf_anzahl_erg():
    if len(c.ausführungen) < c.aktiverg:
        x = root.after(1, ereignis)
        c.ausführungen.append(x)
    elif len(c.ausführungen) > c.aktiverg:
        root.after_cancel(c.ausführungen[len(c.ausführungen) - 1])
        c.ausführungen.remove(c.ausführungen[len(c.ausführungen) - 1])
    else:
        pass
    root.after(10000, prüf_anzahl_erg)

def weiterleitungZurBörse():
    Zzz()
    printlk("Börse wird geöffnet...")
    börse()
    printlk("Erfolgreich zur Börse gegangen")

def printlk(message: str):
    alttext = c.itemcget(nachricht_text, "text")
    c.itemconfig(nachricht_text, text=message + " ; " + alttext)

def musicplay():
    pygame.mixer.music.load("./programdata/haustier/music/background.mp3")
    pygame.mixer.music.play()
    #TODO!
root = Tk()
root.title("Molly die Maus")
c = Canvas(root, width=900, height=605)
c.configure(bg="dark blue", highlightthickness=3)
c.body_color = "SkyBlue1"
body = c.create_oval(45, 30, 375, 360, outline=c.body_color, fill=c.body_color)
ear_left = c.create_polygon(85, 90, 85, 20, 175, 80, outline=c.body_color, fill=c.body_color)
ear_right = c.create_polygon(265, 55, 335, 20, 330, 80, outline=c.body_color, \
                             fill=c.body_color)

foot_left = c.create_oval(75, 330, 155, 370, outline=c.body_color, fill=c.body_color)
foot_right = c.create_oval(260, 330, 340, 370, outline=c.body_color, fill=c.body_color)

eye_left = c.create_oval(140, 120, 170, 180, outline="black", fill="white")
pupil_left = c.create_oval(150, 155, 160, 165, outline="black", fill="black")
eye_right = c.create_oval(240, 120, 270, 180, outline="black", fill="white")
pupil_right = c.create_oval(250, 155, 260, 165, outline="black", fill="black")

mouth_normal = c.create_line(180, 260, 210, 282, 240, 260, smooth=1, width=2, state=NORMAL)
mouth_happy = c.create_line(180, 260, 210, 292, 240, 260, smooth=1, width=2, state=HIDDEN)
mouth_sad = c.create_line(180, 260, 210, 242, 240, 260, smooth=1, width=2, state=HIDDEN)
tongue_main = c.create_rectangle(180, 260, 240, 310, outline="red", fill="red", state=HIDDEN)
tongue_tip = c.create_oval(180, 295, 240, 310, outline="red", fill="red", state=HIDDEN)

cheek_left = c.create_oval(80, 190, 130, 240, outline="pink", fill="pink", state=HIDDEN)
cheek_right = c.create_oval(290, 190, 340, 240, outline="pink", fill="pink", state=HIDDEN)

c.pack()

c.bind("<Motion>", show_happy)
c.bind("<Leave>", hide_happy)
c.bind("<Double-1>", cheeky)

c.geputzt = 0
c.gegessen = 0
c.fette_level = 0
c.happy_level = 3
c.impfung_level = 0
c.münzen = 0
c.punkte_verdient = 0
c.letzte_punkte = score
c.inflation = 0
c.aktiverg = 1
c.save_setting = 20000
c.speicherort = "./programdata/haustier/saved/saved1.txt"
c.plus = ""
c.eyes_crossed = False
c.tongue_out = False
c.playmusic = False
c.nebenwirkung = False
c.impferlaubnis = True
c.ausführungen = ["after#0"]
c.produkte = ["2*Punkte", "10%Punkte", "ImpfungBoost", "BigMac", "HappyBoost", "Lotterie", "MiniLotto", "Deflation", "Ereignisboost", "Ereignissenkung", "Quit"]
c.quitpreis = random.randint(-2, 3)
c.ergpreis = random.randint(-3, 2)
c.preise = [33, 12, 9, 3, 2, 7, 3, 12, c.ergpreis, 12, c.quitpreis]
c.ereignisse = ["Bankzinsen", "Neue Haltungsauflagen", "Raub", "Inflation", "Erfindung", "Mehr Ereignisse", "Weniger Ereignisse", "Aktiendividende", \
                "Jahresrente", "Party", "Katta Enterprises!", "Nichts", "Aktienabsturz"]

button1 = Button(root, text = "Füttern", command = feed)
button1.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button1_window = c.create_window(5, 500, anchor=NW, window=button1)

button2 = Button(root, text = "Putzen", command = putzen)
button2.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button2_window = c.create_window(185, 500, anchor=NW, window=button2)

button3 = Button(root, text = "Speichereinstellungen", command = save_setting)
button3.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button3_window = c.create_window(725, 500, anchor=NW, window=button3)

button4 = Button(root, text = "Wasser geben", command = Trinken)
button4.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button4_window = c.create_window(5, 550, anchor=NW, window=button4)

button5 = Button(root, text = "Optionen", command = alter)
button5.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button5_window = c.create_window(545, 500, anchor=NW, window=button5)

button6 = Button(root, text = "Wecken", command = load_data)
button6.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button6_window = c.create_window(725, 550, anchor=NW, window=button6)

button7 = Button(root, text = "Impfung", command = Impfung)
button7.configure(width = 20, activebackground = "#33B5E5", relief = FLAT)
button7_window = c.create_window(185, 550, anchor=NW, window=button7)

button8 = Button(root, text="Shop", command=shop)
button8.configure(width=20, activebackground = "#33B5E5", relief = FLAT)
button8_window = c.create_window(365, 500, anchor=NW, window=button8)

button9 = Button(root, text="Zur Börse", command=weiterleitungZurBörse)
button9.configure(width=20, activebackground = "#33B5E5", relief = FLAT)
button9_window = c.create_window(365, 550, anchor=NW, window=button9)

button10 = Button(root, text="Spiel beenden", command=end)
button10.configure(width=20, activebackground = "#33B5E5", relief = FLAT)
button10_window = c.create_window(545, 550, anchor=NW, window=button10)

happy = c.happy_level
fette = c.fette_level
c.create_text(600, 30, text="Nahrungslevel", fill="white")
c.create_text(750, 30, text="Stimmungslevel", fill="white")
c.create_text(850, 30, text="Punkte", fill="white")
c.create_text(850, 90, text="Tendenz", fill="white")
c.create_text(750, 90, text="Impfungslevel", fill="white")
c.create_text(850, 150, text="Münzen", fill="white")
c.create_text(750, 150, text="Inflation", fill="white")
c.create_text(825, 210, text="Aktive Ereignisse", fill="white")
tendenz_text = c.create_text(850, 110, fill = "white")
score_text = c.create_text(850, 50, fill="white")
happy_text = c.create_text(750, 50, fill="white")
feed_text = c.create_text(600, 50, fill="white")
impfung_text = c.create_text(750, 110, fill="white")
münzen_text = c.create_text(850, 170, fill="white")
inflation_text = c.create_text(750, 170, fill="white")
erg_text = c.create_text(825, 230, fill="white")

c.create_text(75, 595, text="Benachrichtigungen:", fill="white")
nachricht_text = c.create_text(175, 595, fill="white", anchor=W, text="Spiel gestartet.")

root.attributes("-fullscreen", False)
check_aktien()
load_data()

root.after(123456, ereignis)
root.after(20000, change_color)
root.after(1000, zeige_happy)
root.after(1000, zeige_fette)
root.after(1000, zeige_punkte)
root.after(1000, zeige_tendenz)
root.after(1000, zeige_impfung)
root.after(1000, zeige_münzen)
root.after(1000, zeige_inflation)
root.after(1000, zeige_erg)
root.after(30000, fettabzug)
root.after(1000, blink)
root.after(1000, sad)
root.after(60000, impfung_down)
root.after(c.save_setting, Zzz_reg)
root.after(111111, inflation)
root.after(2222, neuprq)
root.after(2222, neupre)
root.after(10000, prüf_anzahl_erg)
root.after(600000, neuerg)

printlk("Version 3.2.7 ")

root.mainloop()
