import bueroUtils
from tkinter import *
import sqlite3, os

bü = bueroUtils.bueroUtils(packageName="Kaffee Manager")
dLg = bü.dLg
py = bü.importPyautoguiCatched()

if not "coffeeDB.db" in os.listdir("./programdata/kaffee"):
    con = sqlite3.connect("./programdata/kaffee/coffeeDB.db")
    cur = con.cursor()

    sql_command = """
                    CREATE TABLE coffees ( 
                    coffeeNumber INTEGER PRIMARY KEY, 
                    coffeeName VARCHAR(30), 
                    coffeeDescr VARCHAR(70), 
                    intensity INTEGER, 
                    body INTEGER,
                    acidity INTEGER,
                    roasting INTEGER,
                    userExperience CHAR(1),
                    counter INTEGER);
                  """
    cur.execute(sql_command)

    sql_command = """
                    INSERT INTO coffees (coffeeNumber, coffeeName, coffeeDescr, intensity, body, acidity, roasting, userExperience, counter)
                    VALUES (0, "Noch kein Kaffee!", "Ohne Beschreibung", 1, 1, 1, 1, "g", 1);
                  """
    cur.execute(sql_command)

    coffees = [[0, "Noch kein Kaffee!", "Ohne Beschreibung", 1, 1, 1, 1, "g", 1]]
else:
    con = sqlite3.connect("./programdata/kaffee/coffeeDB.db")
    cur = con.cursor()

    cur.execute("SELECT * FROM coffees;")

    coffees = cur.fetchall()

def close():
    notification("Beenden...")
    dLg.finalsave_log()
    con.commit()
    con.close()
    quit()

def notification(n: str):
    c.itemconfig(c.benachrichtigung, text=n)

def updateCoffee():
    c.itemconfig(c.aktText, text=coffees[c.aktIdx][1])
    c.itemconfig(c.lmText, text=formatSchabl(coffees[c.aktIdx]))
    root.update()

def right():
    if len(coffees)>c.aktIdx+1:
        c.aktIdx += 1
        updateCoffee()
        notification("Gescrollt")
    else:
        notification("Schon ganz rechts")

def left():
    if c.aktIdx-1>=0:
        c.aktIdx -= 1
        updateCoffee()
        notification("Gescrollt")
    else:
        notification("Schon ganz links")

def getBeanScore(prompt, title):
    b = 0
    while b < 1 or b > 6:
        b = int(py.prompt(prompt, title))
    return b

def addCoffee():
    global coffees
    coffees.append([len(coffees), py.prompt("Kaffeenamen eingeben:", "Titel"), py.prompt("Beschreibung eingeben:", "Beschreibung", "Keine Beschreibung"),\
                    getBeanScore("Intensität eingeben", "Intensität"),\
                    getBeanScore("Körperberwerung eingeben:", "Körper"), getBeanScore("Säure eingeben:", "Säure"),\
                    getBeanScore("Röstungsbewertung eingeben:", "Röstung"), py.prompt("Bewertung (g oder s) eingeben:", "Bewertung"), 1])
    sql_command = """
                    INSERT INTO coffees (coffeeNumber, coffeeName, coffeeDescr, intensity, body, acidity, roasting, userExperience, counter)
                    VALUES ({});
                  """.format(str(coffees[-1]).lstrip("[").rstrip("]"))
    cur.execute(sql_command)
    c.aktIdx = len(coffees)-1
    updateCoffee()
    notification("Erfolgreich hinzugefügt")

def increaseCounter():
    global coffees
    idx = c.aktIdx
    cl = list(coffees[idx])
    cl[-1] = cl[-1]+1
    coffees[idx] = tuple(cl)
    updateCoffee()
    sql_command = """
                    UPDATE coffees SET counter={} WHERE coffeeNumber={};
                  """.format(str(coffees[idx][-1]), str(idx))
    cur.execute(sql_command)
    notification("Erfolgreich hinzugefügt")

def formatSchabl(coffeeListAkt: list):
    cLA = coffeeListAkt
    return schabl.format(str(cLA[0]), cLA[2], str(cLA[3]), str(cLA[4]), str(cLA[5]), str(cLA[6]), "gut" if cLA[7] == "g" else "schlecht", str(cLA[8]))

schabl = """
Kaffee-Index: {}
Beschreibung:
{}
Intensität: {}
Körper: {}
Säure: {}
Röstung: {}
Bewertung: {}
Anzahl: {}
"""

root = Tk()
root.title("Kaffee Manager")
    
c = Canvas(root, width=600, height=800)
c.configure(bg="light blue")
c.pack()

c.benachrichtigung = c.create_text(300, 750, text="Kaffee Manager gestartet", font=("Verdana", "17"))

c.create_text(300, 30, text="Kaffee", font=("Verdana", "30", "bold"))
c.create_text(300, 70, text="Manager", font=("Verdana", "30", "bold"))
c.create_text(300, 790, text="Copyright Leander Kafemann 2025  -  Version 1.0.0", font=("Verdana", "5"))

c.create_window(300, 680, window=Button(master=root, command=close, text="Beenden", background="light blue", relief="ridge", height=2, width=30))

c.aktIdx = 0

c.create_text(300, 120, text="aktueller Kaffee:", font=("Verdana", "10"))
c.aktText = c.create_text(300, 150, text=coffees[0][1], font=("Verdana", "20"), width=550)
c.lmText = c.create_text(300, 160, font=("Verdana", "15"), width=550, text=formatSchabl(coffees[0]), anchor="n")

c.create_window(360, 600, window=Button(master=root, command=right, text="⇒", background="light blue", activebackground="blue", relief="ridge", height=3), width=33)
c.create_window(240, 600, window=Button(master=root, command=left, text="⇐", background="light blue", activebackground="blue", relief="ridge", height=3), width=33)
c.create_window(280, 600, window=Button(master=root, command=addCoffee, text="🖎", background="light blue", activebackground="blue", relief="ridge", font=("Verdana", "21", "bold")), width=33)
c.create_window(320, 600, window=Button(master=root, command=increaseCounter, text="➕", background="light blue", activebackground="blue", relief="ridge", height=3), width=33)

root.mainloop()