import random, string, webbrowser, os
from time import sleep

name = input("Wie heißt du? ")

wortschatzl = ["eklige Tiere", "Garten", "Geld", "Kanalisation", "Landschaft", "Müll", "Urlaub", "Weltall"]

print("Was für einen Wortschatz willst du haben?")

for counter in range(len(wortschatzl)):
    print(wortschatzl[counter])
    if counter != (len(wortschatzl) - 1):
        print("oder")

while True:
    wortschatz = input("Was für einen Wortschatz willst du haben?")
    if wortschatz not in wortschatzl:
        raise SystemError("Falsche Eingabe")
    else:
        break

with open("./programdata/password/" + wortschatz + ".txt", "r", encoding="utf-8") as file:
    wl = file.read().split(";")

die_adjektive = wl[1].split(" ")
die_farben = wl[2].split(" ")
die_nomen = wl[0].split(" ")

print("Willkommen beim Passwort-Generator!")
print("Du startest Version 1.3.0!")

while True:
    adjektiv = random.choice(die_adjektive)
    farbe = random.choice(die_farben)
    nomen = random.choice(die_nomen)
    zahl = random.randrange(0, 100)
    zahl2 = random.randrange(-10, 1000)
    sonderz = random.choice(string.punctuation)

    passwort = adjektiv + farbe +  str(zahl2) + nomen + str(zahl) + sonderz
    print("Das neue Passwort ist: %s" %passwort)
    antwort2 = input("Wie hat dir der Generator gefallen? Schreibe g oder s")
    if antwort2 == "s":
        with open("./programdata/password/Bewertungen.txt", "a") as file:
            bewertung = input("Was kann ich noch verbessern?")
            if bewertung == "alles":
                print("Betrug!!!")
                break
            else:
                if name == "":
                    print("Betrug!")
                    break
                else:
                    file.write("\n" + bewertung + "/" + name)
                    print("Danke für deine Bewertung!")
                    sleep(1)
        if input("Willst du alle Bewertungen jetzt senden? Schreibe j oder n: ") == "j":
            with open("./programdata/password/Bewertungen.txt", "r", encoding="utf-8") as f:
                webbrowser.open("mailto:update-bot@lk.kafemann.berlin?subject=PasswortgeneratorRatings&body="+f.read())
            os.remove("./programdata/password/Bewertungen.txt")
            print("Deine Bewertungen wurden gesendet. Vielen Dank.")
    if antwort2 == "g":
        print("Schön!")
    antwort = input("Möchtest du noch ein Passwort? Schreibe j oder n: ")
    if antwort == "n":
        antwort3 = input("Wirklich nicht? Schreibe j oder n: ")
        if antwort3 == "n":
            print("Schade:(")
            sleep(3)
            break
        if antwort3 != "n":
            print("Juhu")
            sleep(3)
    if antwort == "j":
        print("Toll")
    if antwort == "":
        print("Du Dummi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        sleep(2)
        break
