﻿import pyautogui as py
import bueroUtils
from tkinter import *

try:
    bü = bueroUtils.bueroUtils(packageName="BüroBonus")
    dLg = bü.dLg
except ImportError:
    py.alert("Sie wurden deautorisiert.\nWenden Sie sich an den Kundenservice.", "Fehler beim Laden der bueroUtils")
    quit(code="Unautorisiertes Plugin")

BPATH = "./programdata/buero/"
HPATH = "./programdata/bonus/"

dLg.entry("Daten initialisiert")

with open(BPATH+"username.txt", "r", encoding="utf-8") as f:
    USER = f.read()
with open(BPATH+"devid.txt", "r", encoding="utf-8") as f:
    DEVID = f.read()
dLg.entrys("USER und DEVID ausgelesen", USER, DEVID)
    
try:
    with open("./premiumpass.txt", "r", encoding="utf-8") as f:
        premiumContent = f.read()
    PREMIUM = bü.checkPREMIUM(premiumContent)
except:
    PREMIUM = False

BETA = str(bü.checkBETA(USER))
dLg.entrys(PREMIUM, BETA)

with open(HPATH+"score.lkbonusscore", "r") as f:
    score = int(f.read())

with open(HPATH+"limit.lkbonusscore", "r") as f:
    limit = int(f.read())

with open(BPATH+"achievements.txt", "r", encoding="utf-8") as f:
    fileContent = f.read().split("#*#")
unlocked = len(fileContent[1].split(" "))
started = int(fileContent[0])
startscore = round(started / 200) + unlocked
startscore += 10 if PREMIUM else 0
startscoreO = startscore

while score+startscore > limit:
    startscore -= 1

root = Tk()
root.title("BüroBonus")
    
c = Canvas(root, width=800, height=400)
c.configure(bg="light blue")
c.pack()

def notification(n: str):
    c.itemconfig(c.benachrichtigung, text=n)

def info():
    py.alert("BüroBonus ist noch in Arbeit.", "Info")

def infoStartBonus():
    py.alert("Bei jedem Start von BüroBank erhältst du {} Punkte.\nDavon durch Erfolge: {}\n".format(str(startscore), str(unlocked))+\
             "Davon durch Büro-Startzähler: {}".format(str(round(started/100)))+("\nDavon durch PREMIUM: 10" if PREMIUM else "")+\
             "\n\nVon den {} Punkten konnten {} aufgenommen werden.".format(str(startscoreO), str(startscore)), "Bonuspunkte")

def updateScore():
    antiCheat()
    updateScores()

def updateScores():
    c.itemconfig(c.score, text=str(score))
    with open(HPATH+"score.lkbonusscore", "w") as f:
        f.write(str(score))
    c.itemconfig(c.scoreStart, text=str(startscore))
    c.itemconfig(c.scoreLimit, text=str(limit))
    with open(HPATH+"limit.lkbonusscore", "w") as f:
        f.write(str(limit))

def addStartScore():
    global score
    score += startscore
    updateScore()
    notification(str(startscore)+" Punkte durch Starten erhalten")

def antiCheat():
    global score, startscore, limit
    if bü.web_content("https://lkunited.pythonanywhere.com/bonus/antiCheat", {"user": USER, "score": score, "startscore": startscore}) != "ok":
        py.alert("Cheat-Verdacht!\nKontaktiere den Kundenservice, um deine Punkte wiederherzustellen.", "Cheater!")
        score = 0; startscore = 0; limit = 0
        updateScores()
    else:
        notification("Punktzahl geprüft")

def end():
    updateScore()
    dLg.finalsave_log()
    quit(code=end)

def share():
    bü.shareViaMail(py.prompt("Empfänger angeben:", "Empfänger"), "BüroBonus", "Ich habe {} BüroBonus-Punkte!".format(str(score)))

c.create_text(400, 30, text="BüroBonus", font=("Verdana", "32", "bold"))
c.create_text(400, 395, text="Copyright Leander Kafemann 2025  -  PRE__Version 0.3.0", font=("Verdana", "5"))

c.create_window(560, 30, anchor="w", window=Button(master=root, command=info, relief="flat", height=1, width=2, text="ⓘ", background="light blue", font=("Verdana", "20")))

c.benachrichtigung = c.create_text(400, 320, text="BüroBonus gestartet", font=("Verdana", "17"))

c.score = c.create_text(400, 120, text=str(score), font=("Verdana", "40", "bold"))
c.create_text(400, 165, text="Punkte momentan verfügbar", font=("Verdana", "10"))

c.scoreStart = c.create_text(100, 120, text=str(startscore), font=("Verdana", "25", "bold"))
c.create_text(100, 150, text="Punkte pro Start", font=("Verdana", "10"))
c.create_window(170, 149, anchor="w", window=Button(master=root, command=infoStartBonus, relief="flat", text="ⓘ", background="light blue", font=("Verdana", "10")))

c.scoreLimit = c.create_text(700, 120, text=str(limit), font=("Verdana", "25", "bold"))
c.create_text(700, 150, text="Punkte maximal", font=("Verdana", "10"))

c.create_window(415, 360, anchor="center", window=Button(master=root, command=share, relief="ridge", height=1, width=2, text="⮫", background="light blue"))
c.create_window(385, 360, anchor="center", window=Button(master=root, command=end, relief="ridge", height=1, width=2, text="⏹", background="light blue"))

if not BETA:
    py.alert("Leider sind Sie momentan nicht berechtigt, dieses Projekt zu sehen.")
    quit(code="BETAMismatch")

c.after(2000, addStartScore)

root.mainloop()