import pgzrun, random

WIDTH = 1280
HEIGHT = 720

main_box = Rect(0, 0, 820, 240)
timer_box = Rect(0, 0, 240, 240)
answer_box1 = Rect(0, 0, 495, 165)
answer_box2 = Rect(0, 0, 495, 165)
answer_box3 = Rect(0, 0, 495, 165)
answer_box4 = Rect(0, 0, 495, 165)

main_box.move_ip(50, 40)
timer_box.move_ip(990, 40)
answer_box1.move_ip(50, 358)
answer_box2.move_ip(735, 358)
answer_box3.move_ip(50, 538)
answer_box4.move_ip(735, 538)
answer_boxes = [answer_box1, answer_box2, answer_box3, answer_box4]

score = 0
time_left = 10
timeEnded = False

q1 = ["Die Hauptstadt von Frankreich ist... ?",
      "London", "Paris", "Berlin", "Tokio", 2]

q2 = ["Was ist 5 + 7?",
      "12", "10", "14", "8", 1]

q3 = ["Was ist der 7. Monat?",
      "April", "Mai", "Juni", "Juli", 4]

q4 = ["Welcher Planet ist der kleinste?",
      "Saturn", "Todesstern", "Merkur", "Venus", 3]

q5 = ["Wo steht der Schiefe Turm?",
      "Mailand", "Pisa", "Florenz", "Rom", 2]

q6 = ["Wie  viele Kreuzer bekommt Donald Duck von Dagobert in den Comics stündlich bezahlt?",
      "1237", "10", "17", "30", 4]

q7 = ["Was ist das wichtigste Fest der Christen?",
      "Weihnachten", "Ostern", "Pfingsten", "Halloween", 2]

q8 = ["Wie viele Länder gibt es?",
      "194", "195", "204", "3107", 1]

q9 = ["Was ist 15 * 15?",
      "132", "217", "225","173", 3]

q10 = ["Was ist die Hauptstadt von Swasiland?",
       "Maputo", "Pretoria", "Maserati", "Mbabane", 4]

q11 = ["Zu welchem Land gehört Grönland?",
       "Kanada", "Russland", "VdaN(Verband der arktischen Nationen)", "Dänemark", 4]

q12 = ["Welches Land hat die meisten Einwohner?",
       "USA", "China", "Entenhausen", "Indien", 4]

q13 = ["Von welchem Tier stammt die Blindschleiche ab?",
       "Eidechse", "Frosch", "Lurch", "Python", 1]

q14 = ["Wie heißt die Schauspielerin von Bellatrix Lestrange?",
       "Bonnie Wright", "Emma Watson", "Helena-Bonham-Carter", "Jack Sparrow", 3]

q15 = ["In welchem Jahr hat Deutschland die Fußball-WM das erste Mal gewonnen?",
       "753", "1954", "1974", "2014", 2]

q16 = ["Wie viel ist 1/6 * 1/12?",
       "1/6", "1/12", "1/72", "123/456", 3]

q17 = ["Wie hieß die Stadt New York ursprünglich?",
       "New York", "Los Angeles", "Ouagadougou", "New Amsterdam", 4]

q18 = ["Wie heißt der vom Glück begünstigte Vetter von Donald Duck?",
       "Dagobert Duck", "Gustav Gans", "Franz Gans", "Miraculix", 2]

q19 = ["Wie heißt der Autor*in von 'Sherlock Holmes'?",
       "Sir Conan Doyle", "Carl Barks", "Agatha Christie", "Edgar Allan Poe", 1]

q20 = ["Welches dieser Spiele existiert wirklich?",
       "Katzenheulen-das ultimative Spiel", "Indien-kratzmücke", "Asterix-Das Spiel", "Monopolie", 3]

q21 = ["Wie wird 'Lustiges Taschenbuch' abgekürzt?",
       "LB", "LuTa", "News from Duckbourg", "LTB", 4]

q22 = ["Aus welchem Land kommt die Abkürzung 'SOS'(Save Our Souls) ursprünglich?",
       "England", "Deutschland", "USA", "El Dorado", 2]

q23 = ["In welchem Verwandschaftdverhältnis stehen Luke und Leia aus 'Star Wars'?",
       "Zwillinge", "Mutter und Sohn", "Mann und Frau", "Vater und Tochter", 1]

q24 = ["Wie heißt der Verlag, der die meisten ???-Bücher druckt?",
       "Ravensburger", "Duck Oil", "Kosmos", "cbj", 3]

q25 = ["Wer schrieb die Filmmusik von Superman?",
       "Hans Zimmer", "Agent DoppelDuck", "Enrio Morricone", "John Williams", 4]

q26 = ["Welches Obst ist eigentlich eine Sammelnuss?",
       "Erdnuss", "Himbeere", "Brombeere", "Erdbeere", 4]

q27 = ["Welcher dieser Inselstaaten existiert nicht?",
       "Polynesien", "Mikro-Pazifika", "Fidschi", "Vanuatu", 2]

q28 = ["Was bewirkt die Tastenkombination Alt + F4?",
       "Fenster wird geschlossen", "Nichts", "Der aktuelle Vorgang wird abgebrochen", "Der PC lädt Viren", 1]

q29 = ["Welcher dieser Autoren schrieb Bücher wie 'Die Eissphinx' oder 'Nord gegen Süd'?",
       "Edgar Allan Poe", "Marc-Uwe-Kling", "Jules Verne", "Astrid Lindgren", 3]

q30 = ["Aus welchem Land kommt LEGO?",
       "Dänemark", "Deutschland", "Schweiz", "Rocky Beach", 1]

q31 = ["Wie heißt die Band, die 'Mamma Mia' und 'Waterloo' veröffentlichte?",
       "Queen", "Die Prinzen", "Krankenhouse", "ABBA", 4]

q32 = ["Wie heißt die Heimatstadt von Primus von Quack?",
       "Entenhausen", "Quackhausen", "Gansburg", "Tortuga", 2]

q33 = ["Was für ein Baum ist auf der Flagge des Libanon?",
       "Eiche", "Esche", "peitschende Weide", "Zeder", 4]

q34 = ["Wie nennt man das Schiff einer Flotte, auf dem der Kapitän seine Kabine hat?",
       "Hauptschiff", "Kein besonderer Name", "Flaggschiff", "Black Pearl", 3]

q35 = ["Wie heißt die Schusswaffe, die auf der Flagge Mosambiks zu sehen ist?",
       "Kalaschnikow", "Maschienengewehr", "Bazooka", "Laserpistole", 1]

q36 = ["Was bedeutet 'Star Wars'?",
       "Krieg der Sterne", "Star Wars", "Fluch der Karibik 6", "Krieg der Galaxien", 1]

q37 = ["Wie heißt der Autor der 'Anthologien' 'Über wachen und schlafen' und 'Über arbeiten und fertig sein'?",
       "Marc-Uwe-Klang", "Al Sweigart", "Robert Koch", "Marc-Uwe-Kling", 4]

q38 = ["Mit welchem Fahrzeug bringt Hagrid Harry Potter zu den Dursleys?",
       "Auto", "fliegenden Motorrad", "Besen", "U-Bahn", 2]

q39 = ["Wie heißt KEIN bekanntes Weihachtslied?",
       "Jingle Bells", "Morgen, Kinder wirds nichts geben", "Morgen kommt der Weihnachtsmann",
       "Leise rieselt der Schnee", 2]

q40 = ["Wer waren die Vorgänger der sogenannten \'Abrafaxe\'?",
       "Digedags", "Mosaiks", "Abrafax", "Strumtruppen", 1]

q41 = ["Wie heißt der Böse aus \'Herr der Ringe\'?",
       "Melkor", "Sauron", "Frodo", "Darth Vader", 2]

q42 = ["Wie lautet die Perfektform von aufhängen?",
       "aufgehängt", "aufgehangt", "aufgehangen", "aufgefangen", 3]

q43 = ["Woraus besteht Cola größtenteils?",
       "Phosphorsäure", "Apfelsaft", "Vielsafttrank", "Wasser", 4]

q44 = ["Welche ist dir Hauptstadt von Bulgarien?",
       "Sofia", "Budapest", "Naboo", "Antananarivo", 1]

q45 = ["Welcher bekannte Schauspieler stellte in der Hobbit-Trilogie Smaug dar und sprach den Nekromanten?",
       "Benedict Cumberbatch", "Johnny Depp", "Harrison Ford", "Buddy", 1]

q46 = ["Welche ist keine echte Währung?",
       "Forint", "Yen", "Euro", "Taler", 4]

q47 = ["Welcher ist der größte Saurier?",
       "T-Rex", "Brachiosaurier", "Giganotosaurier", "Endominus Rex", 3]

q48 = ["Welches ist das meistgedruckte Buch?",
       "Bibel", "Harry Potter 1", "IKEA-Katalog", "Star Trek-Das Buch zur Serie", 3]

q49 = ["Wofür steht \'HARIBO\'?",
       "Hans Riegel Bonn", "Harry Botter", "Hans Rigel Bonn", "Haans Riegel Bon", 1]

q50 = ["Ist dieses Quiz toll?", "Ja", "Ja, total", "Nein", "geht so", 2]

q51 = ["Wie wird der Komponist der Oper \'Carmen\' geschrieben?",
       "Bizet", "Baiser", "Kaiser", "Biezeth", 1]

q52 = ["Wie lautet die chemische Formel von Traubenzucker?",
       "SO2", "C6H12O6", "KyO2NH3", "CH3-CH2-CH3", 2]

questions1 = [q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20, q21, q22, q23, q24, q25, q26,
              q27, q28, q29, q30, q31, q32, q33, q34, q35, q36, q37, q38, q39, q40, q41, q42, q43, q44, q45, q46, q47, q48, q49, q50,
              q51, q52]
fragen = len(questions1)
questions = random.sample(questions1, fragen)
question = questions.pop(0)

def draw():
    screen.fill("dim grey")
    screen.draw.filled_rect(main_box, "green yellow")
    screen.draw.filled_rect(timer_box, "pale violet red")

    for box in answer_boxes:
        screen.draw.filled_rect(box, "goldenrod")

    screen.draw.textbox(str(time_left), timer_box, color=("black"))
    screen.draw.textbox(question[0], main_box, color=("black"))

    index = 1
    for box in answer_boxes:
        screen.draw.textbox(question[index], box, color=("black"))
        index = index + 1

music.play("quiz-music")

def game_over():
    global question, time_left, timeEnded
    message = "Ende. Du hast %s Fragen richtig." % str(score)
    message += "\nDas waren alle Fragen.\nHerzlichen Glückwunsch!" if timeEnded else "\nDas geht noch besser..."
    question = [message, "-", "-", "-", "-", 5]
    time_left = 0
    music.stop()

def correct_answer():
    global question, score, time_left, timeEnded

    score += 1
    if questions:
        question = questions.pop(0)
        for i in range(random.randint(1, 8)):
            if time_left < 10:
                time_left += 1
    else:
        print("Ende der Fragen")
        timeEnded = True
        game_over()

def on_mouse_down(pos):
    index = 1
    for box in answer_boxes:
        if box.collidepoint(pos):
            print("Du hast angeklickt: " + str(index))
            if index == question[5]:
                print("Das ist richtig!")
                correct_answer()
            else:
                print("Möglicherweise falsch...!")
                game_over()
        index += 1

def update_time_left():
    global time_left

    if time_left:
        time_left -= 1
    else:
        game_over()

clock.schedule_interval(update_time_left, 1.0)

pgzrun.go()
