import pyautogui as py
import bueroUtils

try:
    bü = bueroUtils.bueroUtils(packageName="BüroBank")
    dLg = bü.dLg
except ImportError:
    py.alert("Sie wurden deautorisiert.\nWenden Sie sich an den Kundenservice.", "Fehler beim Laden der bueroUtils")
    quit(code="Unautorisiertes Plugin")

BPATH = "./programdata/buero/"
HPATH = "./programdata/bank/"

dLg.entry("Daten initialisiert")

with open(BPATH+"username.txt", "r", encoding="utf-8") as f:
    USER = f.read()
with open(BPATH+"devid.txt", "r", encoding="utf-8") as f:
    DEVID = f.read()
dLg.entrys("USER und DEVID ausgelesen", USER, DEVID)
    
try:
    with open("./premiumpass.txt", "r", encoding="utf-8") as f:
        premiumContent = f.read()
except:
    PREMIUM = False

PREMIUM = bü.checkPREMIUM(premiumContent)
dLg.entry(PREMIUM)
    
if PREMIUM:
    from tkinter import *
    import webbrowser as wb
    import pyperclip

    BETA = "True" if bü.web_content("https://lkunited.pythonanywhere.com/cB", {"message": USER, "pw": "lkunited"}) == "registered" else "False"

    with open(HPATH+"konto.txt", "r", encoding="utf-8") as f:
        kontostand = f.read()

    def get_transaction():
        id_ = py.prompt("Transaktions-ID eingeben:", "ID")
        code = get_code()
        tra = bü.web_content("https://lkunited.pythonanywhere.com/bank/getTransaction",\
                             {"name": USER, "code": code, "id": id_})
        notification("Transaktion gelesen")
        try:
            tra_ = tra.split("#**#")
            py.alert("Eine Transaktion mit den folgenden Daten ist eingegangen:\n"+\
                     "Von: "+tra_[0]+"\nSumme: "+tra_[1]+"\nAn: "+tra_[2]+"\nNachricht:\n"+tra_[3])
            get_money()
        except:
            py.alert("Ein Fehler ist aufgetreten.", "Fehler")
            notification("Invalide ID: "+tra)

    def set_transaction():
        to = py.prompt("An welchen Nutzer wollen Sie Geld überweisen?", "Ziel")
        sum_ = format_money(py.prompt("Wie viel Geld wollen Sie überweisen?", "Summe", "0.00"))
        descr = py.prompt("Welche Nachricht wollen Sie der Überweisung beifügen?", "Nachricht")
        if bü.buttonLog(f"Zusammenfassung:\nZiel: {to}\nSumme: {sum_}\nNachricht: {descr}") == "Fortfahren":
            code = get_code()
            id_ = bü.web_content("https://lkunited.pythonanywhere.com/bank/setTransaction", {"name": USER,\
                                 "code": code, "to": to, "sum": sum_, "description": descr})
            notification("Überweisung getätigt: "+id_)
            match bü.buttonLog("Ihre Überweisungs-ID:\n"+id_, "Überweisung", ("Kopieren", "Link kopieren", "Zurück")):
                case "Kopieren":
                    pyperclip.copy(id_)
                    notification("Kopiert")
                case "Link kopieren":
                    pyperclip.copy("https://lkunited.pythonanywhere.com/bank/viewTransaction?name="+USER+"&code="+id_)
                    notification("Kopiert")
            get_money()
        else:
            notification("Vorgang abgebrochen")

    def view_online():
        wb.open("https://lkunited.pythonanywhere.com/bank/loginTransaction")

    def get_code():
        code = bü.web_content("https://lkunited.pythonanywhere.com/getCode", {"username": USER,\
                              "id": BETA, "devid": DEVID, "password": "lkunited"})
        notification("Code generiert: "+code)
        return code

    def get_money():
        c.money = bü.web_content("https://lkunited.pythonanywhere.com/bank/getMoney", {"name": USER, "code": get_code()})
        c.itemconfig(c.kontostand, text=c.money)
        with open(HPATH+"konto.txt", "w", encoding="utf-8") as f:
            f.write(unformat_money(c.money))
        notification("Kontostand aktualisiert")

    def format_money(money):    
        return str(money)+"0 €" if len(str(money).split(".")[-1]) < 2 else str(money)+" €"

    def unformat_money(money):
        return float(str(money).rstrip(" €"))

    def notification(text: str = ""):
        c.itemconfig(c.benachrichtigung, text=text)
        root.update()

    def quit_():
        notification("BüroBank beenden...")
        root.update()
        dLg.finalsave_log()
        quit(code="Beenden...")

    root = Tk()
    root.title("BüroBank")
    root.iconbitmap("./programdata/bank/money.ico")
    
    c = Canvas(root, width=700, height=350)
    c.configure(bg="light blue")
    c.pack()

    c.money = format_money(kontostand)

    c.create_text(350, 30, text="BüroBank", font=("Verdana", "30", "bold"))
    c.create_text(350, 345, text="Copyright LK 2024  -  Version 1.0.2", font=("Verdana", "5"))

    c.benachrichtigung = c.create_text(350, 260, text="BüroBank gestartet", font=("Verdana", "17"))
    c.create_window(350, 310, window=Button(master=root, command=quit_, text="Beenden", background="light blue", relief="ridge", height=2, width=30))

    c.kontostand = c.create_text(350, 150, text=c.money, font=("Verdana", "40", "bold"))

    c.create_window(550, 150, window=Button(master=root, command=get_money, text="⟳", background="light blue", activebackground="blue", relief="ridge"), width=33)
    c.create_window(590, 150, window=Button(master=root, command=view_online, text="🌐", background="light blue", activebackground="yellow", relief="ridge"), width=33)
    c.create_window(150, 150, window=Button(master=root, command=set_transaction, text="➖", background="light blue", activebackground="red", relief="ridge"), width=33)
    c.create_window(110, 150, window=Button(master=root, command=get_transaction, text="➕", background="light blue", activebackground="light green", relief="ridge"), width=33)

    c.after(300, get_money)

    dLg.entry("BüroBank gestartet.")
    root.mainloop()
else:
    py.alert("Sie benötigen Büro PREMIUM, um BüroBank nutzen zu können.", "BüroBank nicht verfügbar")
    dLg.finalsave_log()
    quit(code="Büro PREMIUM fehlt")