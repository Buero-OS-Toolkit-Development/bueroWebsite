import pyautogui as py
import bueroUtils

bü = bueroUtils.bueroUtils()

BPATH = "./programdata/buero/"
HPATH = "./programdata/mail/"

with open(BPATH+"username.txt", "r", encoding="utf-8") as f:
    USER = f.read()
with open(BPATH+"devid.txt", "r", encoding="utf-8") as f:
    DEVID = f.read()
    
try:
    with open("./premiumpass.txt", "r", encoding="utf-8") as f:
        premiumContent = f.read()
except:
    PREMIUM = False
if "True" in bü.web_content("https://lkunited.pythonanywhere.com/checkerP", {"message":premiumContent, "pw":"lkunited"}):
    PREMIUM = True
else:
    PREMIUM = False
    
if PREMIUM:
    from tkinter import *
    from tkinter.filedialog import askopenfilename
    import shutil, os
    
    def load_mail():
        global USER
        filename = askopenfilename(filetypes=[("*.txt", "TXT Mail file")], initialdir=HPATH+"inbox/unread")
        sbj = filename.split("/")[-1].rstrip(".txt")
        with open(filename, "r", encoding="utf-8") as f:
            ct = f.read()
        sender, content = ct.split("#**#")
        for i in c.textlist:
            i.delete("1.0", END)
        c.inhalt.insert(END, content.rstrip())
        c.sender.insert(END, sender)
        c.empfänger.insert(END, USER)
        c.betreff.insert(END, sbj)
        if "/unread/" in filename:
            shutil.move(HPATH+"/inbox/unread/"+sbj+".txt", HPATH+"/inbox/archive/"+sbj+".txt")
        c.itemconfig(c.benachrichtigung, text="Mail geöffnet")
    
    def send_mail():
        global USER, DEVID
        c.itemconfig(c.benachrichtigung, text="Mail wird gesendet...")
        root.update()
        code = bü.web_content("https://lkunited.pythonanywhere.com/getCode", {"username": USER,\
                              "id": "True" if bü.web_content("https://lkunited.pythonanywhere.com/cB",\
                              {"message": USER, "pw": "lkunited"}) == "registered" else "False", "devid": DEVID, "password": "lkunited"})
        c.itemconfig(c.benachrichtigung, text="Code generiert: "+code)
        root.update()
        sbj = c.betreff.get("1.0", END).rstrip()
        cnt = c.inhalt.get("1.0", END)
        rcp = c.empfänger.get("1.0", END).rstrip()
        #print(sbj, cnt, rcp)
        send = bü.web_content("https://lkunited.pythonanywhere.com/sendMail",\
                              {"username": USER, "code": code, "subject": sbj, "content": cnt, "recipient": rcp})
        c.itemconfig(c.benachrichtigung, text="Mail gesendet: "+send)
    
    def redirect():
        global USER
        sender_before = c.sender.get("1.0", END)
        c.inhalt.insert("1.0", "\n\n"+sender_before.rstrip("\n")+" schrieb:\n")
        c.betreff.insert("1.0", "Wg- ")
        c.empfänger.delete("1.0", END)
        c.sender.delete("1.0", END)
        c.sender.insert(END, USER)
        c.itemconfig(c.benachrichtigung, text="Weiterleitung konfiguriert")
    
    def reply():
        global USER
        sender_before = c.sender.get("1.0", END)
        c.inhalt.insert("1.0", "\n\n"+sender_before.rstrip("\n")+" schrieb:\n")
        c.betreff.insert("1.0", "Aw- ")
        c.empfänger.delete("1.0", END)
        c.sender.delete("1.0", END)
        c.sender.insert(END, USER)
        c.empfänger.insert(END, sender_before)
        c.itemconfig(c.benachrichtigung, text="Antwort konfiguriert")
    
    def quit_():
        c.itemconfig(c.benachrichtigung, text="BüroMail beenden...")
        root.update()
        quit()
    
    def quit_agent():
        with open(HPATH+"runAgent.txt", "w", encoding="utf-8") as f:
            f.write("stop")
        c.itemconfig(c.benachrichtigung, text="BackgroundAgent beendet")

    root = Tk()
    root.title("BüroMail")
    
    c = Canvas(root, width=650, height=850)
    c.configure(bg="light blue")
    c.pack()

    c.create_text(325, 30, text="BüroMail", font=("Verdana", "30", "bold"))
    c.create_text(20, 100, text="Sender:", font=("Verdana", "20"), anchor="w")
    c.create_text(20, 140, text="Empfänger:", font=("Verdana", "20"), anchor="w")
    c.create_text(20, 200, text="Betreff:", font=("Verdana", "20"), anchor="w")
    c.create_text(325, 270, text="Inhalt:", font=("Verdana", "25"))

    c.inhalt = Text(root, wrap=WORD, font=("Verdana", "16"))
    c.create_window(10, 325, height=325, width=630, window=c.inhalt, anchor="nw")
    c.sender = Text(root, wrap="none", font=("Verdana", "16"))
    c.create_window(230, 100, height=35, width=370, window=c.sender, anchor="w")
    c.empfänger = Text(root, wrap="none", font=("Verdana", "16"))
    c.create_window(230, 140, height=35, width=370, window=c.empfänger, anchor="w")
    c.betreff = Text(root, wrap="none", font=("Verdana", "18"))
    c.create_window(230, 200, height=40, width=370, window=c.betreff, anchor="w")
    
    c.benachrichtigung = c.create_text(325, 820, text="BüroMail gestartet", font=("Verdana", "17"))
    
    c.create_text(325, 845, text="Copyright LK 2024  -  Version 1.1.0", font=("Verdana", "5"))
    
    c.create_window(15, 675, anchor="nw", window=Button(master=root, command=load_mail, text="Mail öffnen", background="light blue", relief="ridge", height=2, width=12))
    c.create_window(125, 675, anchor="nw", window=Button(master=root, command=reply, text="Antworten", background="light blue", relief="ridge", height=2, width=11))
    c.create_window(325, 675, anchor="n", window=Button(master=root, command=quit_agent, text="BackgroundAgent beenden", background="light blue", relief="ridge", height=2, width=23))
    c.create_window(525, 675, anchor="ne", window=Button(master=root, command=redirect, text="Weiterleiten", background="light blue", relief="ridge", height=2, width=11))
    c.create_window(635, 675, anchor="ne", window=Button(master=root, command=send_mail, text="Mail senden", background="light blue", relief="ridge", height=2, width=12))

    c.create_window(325, 770, window=Button(master=root, command=quit_, text="Quit", background="light blue", relief="ridge", height=2, width=30))

    c.textlist = [c.inhalt, c.sender, c.empfänger, c.betreff]

    if "pre_mail.txt" in os.listdir("./programdata/mail"):
        with open(HPATH+"pre_mail.txt", "r", encoding="utf-8") as f:
            content = f.read()
        os.remove(HPATH+"pre_mail.txt")
        #Empfänger, Betreff, Inhalt
        content_ = content.split("#**#")
        c.empfänger.insert(END, content_[0])
        c.betreff.insert(END, content_[1])
        c.inhalt.insert(END, content_[2])
        c.sender.insert(END, USER)
        c.itemconfig(c.benachrichtigung, text="Vorgespeicherte Mail geladen")
    else:
        c.inhalt.insert(END, "Öffne eine Mail oder setze eine neue Mail auf, um zu beginnen.")

    root.mainloop()
else:
    py.alert("Sie benötigen Büro PREMIUM, um BüroMail nutzen zu können.", "BüroMail nicht verfügbar")
    quit()