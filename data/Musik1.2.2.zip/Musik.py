from tkinter import *
import pygame, os, random
import pyautogui as py
import eyed3 as ey
from tkinter.filedialog import *
import pygame._sdl2.audio as pyaudio

pygame.mixer.init()

def init():
    with open("./programdata/music/files.txt", "r") as file:
        x = file.read().split(";")
    for i in x:
        if ":*:" in i:
            y = i.split(":*:")
            if y[0] not in c.all:
                c.all.append(y[0])
                c.locations.append(y[1])
                for i in [y[2], y[3], y[4], y[5]]:
                    c.reviews.append(i)

def play():
    global mus
    mus.pause()
    c.paused = True

def resume():
    global mus
    mus.unpause()
    c.paused = False

def choice():
    global mus
    title = py.prompt("Namen eingeben", "Titel")
    if title in c.all:
        c.titles.append(title)
        toload = c.locations[c.all.index(title)]
        if len(c.titles)>1:
            queue(toload)
        else:
            mus.load(toload)
            c.lens = round(ey.load(toload).info.time_secs)
            c.len = 0.0
            mus.play()

def scaleValue(event):
    mus.set_volume(volume.get()/100)

def activetitle():
    c.itemconfig(active, text="Aktueller Titel: "+c.titles[0] if len(c.titles)>0 else "Aktueller Titel:")
    window.after(1000, activetitle)

def nexttitle():
    x = "\n"
    try:
        y = [c.titles[abs(c.scroll)]]
        if len(c.titles) > abs(c.scroll + 1):
            y.append(c.titles[abs(c.scroll+1)])
        if len(c.titles) > abs(c.scroll + 2):
            y.append(c.titles[abs(c.scroll+2)])
    except:
        y = []
    #print(y, c.titles)
    for i in y:
        x += i + "\n"
    c.itemconfig(Next, text="Naechste Titel:" + x)
    window.after(1000, nexttitle)

def queue(filename):
    c.toload.append(filename)

def queuecheck():
    if not mus.get_busy() and len(c.titles) > 1 and not c.paused:
        c.titles.pop(0)
        c.len = 0.0
        if c.titles[0] != "":
            x = c.titles[0]
        else:
            x = c.titles[1]
            c.titles.pop(0)
        toload = c.locations[c.all.index(x)]
        c.lens = round(ey.load(toload).info.time_secs)
        mus.load(toload)
        mus.play()
    window.after(100, queuecheck)

def skip():
    global mus
    mus.stop()

def vorspulen(event):
    mus.rewind()
    mus.set_pos(fortschritt.get())
    c.len = round(fortschritt.get(), ndigits=1)

def show_len():
    var.set(c.len)
    fortschritt.configure(to=c.lens)
    scroller.configure(to=len(c.titles)-1)
    c.after(50, show_len)

def act_len():
    if mus.get_busy() and not c.paused:
        c.len += 0.05
    c.after(50, act_len)

def add_check(Object, folder):
    x = []
    if not os.path.isdir(folder+Object):
        y = list(str(list(Object.split("/"))[-1]).split("."))
        x = [folder+y[0]+"."+y[1]] if y[1] == "mp3" or y[1] == "wav" else []
        #print(y)
    else:
        for i in os.listdir(folder+Object):
            z = add_check(i, folder+Object+"/")
            for lk in z:
                x.append(lk)
            #print(z)
    #print(x)
    return x

def add():
    x = []
    if py.confirm("Einzelne Dateien oder Ordner waehlen?", buttons=("Datei", "Ordner")) == "Datei":
        x = askopenfilenames(title="Musik auswaehlen", filetypes=[("MP3-Datei", "*.mp3")])
    else:
        a = askdirectory(title="Ordner auswaehlen")
        for h in os.listdir(a):
            #print(h)
            j = add_check(h, a+"/")
            for i in j:
                x.append(i)
                #print(i)
    print(x)
    z = []
    with open("./programdata/music/files.txt", "a") as file:
        for i in x:
            y = list(list(str(i).split("/"))[-1].split("."))[0]
            file.write(y+":*:"+i+":*:5:*:5:*:5:*:5"+";")
            z.append(y)
    with open("./programdata/music/"+list(str(x[0]).split("/"))[-2]+".lkpl", "w", encoding="utf-8") as file2:
        for i in z:
            file2.write(i+";")
    init()

def loop():
    for i in range(int(py.prompt("Anzahl Wiederholungen", "Schleife"))):
        c.titles.insert(1, c.titles[0])

def save():
    with open(asksaveasfilename(title="Datei waehlen", filetypes=[("LK-Playlist", "*.lkpl")]) + ".lkpl", "w", encoding="utf-8") as file:
        for i in c.titles:
            file.write(i + ";")

def load():
    with open(askopenfilename(title="Datei waehlen", filetypes=[("LK-Playlist", "*.lkpl")]), "r", encoding="utf-8") as file:
        c.titles = list(file.read().split(";"))
        c.titles.insert(0, "LK")
        c.titles.remove(c.titles[-1])
    mus.stop()

def scroll(blabla):
    c.scroll = int(blabla)

def devices():
    c.device = py.confirm("Welches Ausgabegerät möchten Sie nutzen?", buttons=tuple(pyaudio.get_audio_device_names()))
    pygame.mixer.pre_init(devicename=c.device)

def bewerten(pkt):
    try:
        c.reviews[int((c.all.index(c.titles[0])+1)*c.usridx)-1] = pkt
    except:
        stars.set(pkt)

def save_all():
    with open("./programdata/music/files.txt", "w") as file:
        for i in range(len(c.all)):
            a = c.all[i]+":*:"+c.locations[i]
            for h in range(4):
                a += ":*:"+c.reviews[(i+1)*(h+1)-1]
            file.write(a+";")
    c.after(30000, save_all)

def Quit():
    save_all()
    quit()

def zeige_bewertung():
    try:
        stars.set(c.reviews[((c.all.index(c.titles[0]) + 1) *  c.usridx - 1)])
    except:
        print("ERROR")
    finally:
        c.after(5000, zeige_bewertung)

def return_s(liste):
    l1 = []
    l2 = []
    l3 = []
    l4 = []
    x = 0
    for i in liste:
        if x == 0:
            l1.append(i)
        elif x == 1:
            l2.append(i)
        elif x == 2:
            l3.append(i)
        elif x == 3:
            l4.append(i)
            x = -1
        x += 1
    return l1, l2, l3, l4

def check(liste: list, anzahl: int, gegencheck=[]):
    pygame.mixer.quit()
    pygame.mixer.init(devicename=c.device)
    x = 0
    maxi = 0
    maxl = []
    max2l = []
    max3l = []
    a = True
    for i in liste:
        if int(i) > maxi:
            for h in gegencheck:
                if int(h[x]) <= round(maxi/3):
                    a = False
            if a:
                max2l = maxl.copy()
                maxl = [c.all[x]]
            maxi = int(i)
            a = True
        elif int(i) == maxi:
            for h in gegencheck:
                if int(h[x]) <= round(maxi/3):
                    a = False
            if a:
                maxl.append(c.all[x])
            a = True
        elif int(i) == maxi-1:
            for h in gegencheck:
                if int(h[x]) <= round(maxi/3):
                    a = False
            if a:
                max2l.append(c.all[x])
            a = True
        elif int(i) > round(maxi/3):
            for h in gegencheck:
                if int(h[x]) <= round(maxi/3):
                    a = False
            if a:
                max3l.append(c.all[x])
            a = True
        x += 1
    if len(maxl) < anzahl:
        while len(maxl) < anzahl:
            try:
                maxl.append(max2l.pop(random.randint(0, len(max2l))))
            except:
                try:
                    maxl.append(max3l.pop(random.randint(0, len(max3l))))
                except:
                    break
    elif len(maxl) > anzahl:
        while len(maxl) > anzahl:
            maxl.remove(random.choice(maxl))
    if len(maxl) == 1:
        maxl.insert(0, "LK")
    return maxl

def favorites():
    anz = int(py.prompt("maximale Anzahl der Titel"))
    liste = list(return_s(c.reviews))
    print(liste)
    x = liste[c.usridx -1]
    c.titles = check(x, anz)

def all_favorites():
    l1, l2, l3, l4 = return_s(c.reviews)
    c.titles = check(l1, int(py.prompt("maximale Anzahl an Titeln")), gegencheck=[l2, l3, l4])

users = list(open("./programdata/music/users.txt", "r").read().split(" "))
user = py.confirm("Welcher Nutzer sind Sie?", "Warnung:SIE KÖNNEN GEMELDET WERDEN(!)", buttons=tuple(users))

window = Tk()
window.title("Musik")
var = DoubleVar()
stars = IntVar()
c = Canvas(window, width=500, height=650)
c.configure(bg="light green")
c.pack()
c.titles = []
c.toload = []
c.lens = 0.0
c.len = 0.0
c.scroll = 1
c.paused = False
c.all = []
c.locations = []
c.reviews = []
c.usridx = users.index(user)+1
c.device = ""
init()
devices()

pygame.mixer.quit()
pygame.mixer.init()
mus = pygame.mixer.music

c.create_text(250, 645, anchor="center", fill="black", text="Version 1.2.2")

c.create_window(80, 30, window=Button(master=window, command=play, text="Pausieren"), width=160)
c.create_window(250, 30, window=Button(master=window, command=resume, text="Spielen"), width=160)
c.create_window(420, 30, window=Button(master=window, command=loop, text="Schleife"), width=170)
c.create_window(190, 70, window=Button(master=window, command=choice, text="Titel waehlen"))
c.create_window(330, 70, window=Button(master=window, command=skip, text="Titel ueberspringen"))
c.create_window(250, 450, window=Button(master=window, command=add, text="Mediathek aktualisieren"), width=300)
c.create_window(162, 490, window=Button(master=window, command=save, text="Playlist speichern"))
c.create_window(350, 490, window=Button(master=window, command=load, text="Playlist laden"))
c.create_window(250, 615, window=Button(master=window, command=Quit, text="Beenden"))
c.create_window(75, 550, window=Button(master=window, command=all_favorites, text="allgemeine Favoriten", width=17))
c.create_window(425, 550, window=Button(master=window, command=favorites, text="Meine Favoriten", width=17))

active = c.create_text(250, 280, fill="black")
Next = c.create_text(250, 350, fill="black", width=300)

volume = Scale(orient="horizontal", command=scaleValue, label="Volume", showvalue=True)
volume.config(from_=0, to=100, length=365, resolution=1.0)
volume.pack(pady=10)
volume.set(100)
c.create_window(250, 130, window=volume)

fortschritt = Scale(orient="horizontal", showvalue=0, command=vorspulen, name="fortschritt", label="Title", variable=var, repeatdelay=500)
fortschritt.config(from_=0.0, to=c.lens, length=365, resolution=0.05, showvalue=True)
fortschritt.pack(pady=10)
c.create_window(250, 200, window=fortschritt)

scroller = Scale(orient="vertical", showvalue=0, command=scroll)
scroller.config(from_=1, to = len(c.titles) - 1, length=80, resolution=1.0)
scroller.pack()
c.create_window(450, 350, window=scroller)

bewertung = Scale(orient="horizontal", showvalue=5, command=bewerten, label="Bewertung", variable=stars)
bewertung.config(from_=0, to=10, length=205, resolution=1.0)
stars.set(5)
bewertung.pack()
c.create_window(250, 560, window=bewertung)

c.after(1000, activetitle)
c.after(1000, nexttitle)
c.after(100, queuecheck)
c.after(100, show_len)
c.after(1000, act_len)
c.after(30000, save_all)
c.after(5000, zeige_bewertung)

window.mainloop()
