import random
import sys, os

print("SCHERE, STEIN, PAPIER")

wins = 0
losses = 0
ties = 0

win_stein = 0
win_schere = 0
win_papier = 0

win_stein_akt = 0
win_schere_akt = 0
win_papier_akt = 0

use_stein = 0
use_schere = 0
use_papier = 0

with open("./programdata/schingschangschongiq/win.txt", "r") as file:
    winfile = file.read()
    win_stein, win_schere, win_papier = winfile.split(" ")
    file.close()

win_stein = int(win_stein)
win_schere = int(win_schere)
win_papier = int(win_papier)

runden = input("Wie viele Runden willst du spielen?")

for i in range(1, (int(runden) + 1)):
    print("Noch " + str(runden) + " Runden!")
    print("%s Siege, %s Niederlagen, %s Unentschieden" % (wins, losses, ties))
    while True:
        print("Gib deinen Zug an: stein(r), (p)apier, (s)chere oder (q)uit")
        playerMove = input()
        if playerMove == "q":
            sys.exit()
        if playerMove == "r" or playerMove == "s" or playerMove == "p":
            break
        print("Dies ist ein ungültiger Zug!")

    if playerMove == "r":
        print("STEIN gegen...")
        use_stein += 1
    elif playerMove == "p":
        print("PAPIER gegen...")
        use_papier += 1
    elif playerMove == "s":
        print("SCHERE gegen...")
        use_schere += 1

    randomNumber = random.randint(1, 4)
    if randomNumber == 1 or randomNumber == 4:
        maxw = max(win_stein, win_schere, win_papier)
        if maxw == win_stein:
            computerMove = "r"
            print("STEIN")
        elif maxw == win_papier:
            computerMove = "p"
            print("PAPIER")
        elif maxw == win_schere:
            computerMove = "s"
            print("SCHERE")
    elif randomNumber == 2:
        maxw = max(win_stein_akt, win_schere_akt, win_papier_akt)
        if maxw == win_stein_akt:
            computerMove = "r"
            print("STEIN")
        elif maxw == win_papier_akt:
            computerMove = "p"
            print("PAPIER")
        elif maxw == win_schere_akt:
            computerMove = "s"
            print("SCHERE")
    elif randomNumber == 3:
        maxw = max(use_stein, use_schere, use_papier)
        if maxw == use_stein:
            computerMove = "p"
            print("PAPIER")
        elif maxw == use_papier:
            computerMove = "s"
            print("SCHERE")
        elif maxw == use_schere:
            computerMove = "r"
            print("STEIN")

    if playerMove == computerMove:
        print("Unentschieden!")
        ties += 1
    elif playerMove == "r" and computerMove == "s":
        print("Sieg!")
        wins += 1
        win_stein += 1
        win_stein_akt += 1
    elif playerMove == "s" and computerMove == "p":
        print("Sieg!")
        wins += 1
        win_schere += 1
        win_schere_akt += 1
    elif playerMove == "p" and computerMove == "r":
        print("Sieg!")
        wins += 1
        win_papier += 1
        win_papier_akt += 1
    elif computerMove == "r" and playerMove == "s":
        print("Niederlage!")
        losses += 1
        win_stein += 1
        win_stein_akt += 1
    elif computerMove == "s" and playerMove == "p":
        print("Niederlage!")
        losses += 1
        win_schere += 1
        win_schere_akt += 1
    elif computerMove == "p" and playerMove == "r":
        print("Niederlage!")
        losses += 1
        win_papier += 1
        win_papier_akt += 1
    runden = int(runden)
    runden -= 1

print("%s Siege, %s Niederlagen, %s Unentschieden" % (wins, losses, ties))
if wins > losses:
    print("Der Spieler hat gewonnen!")
elif losses > wins:
    print("Der Computer hat gewonnen!")
elif wins == losses:
    print("Gleich viele Siege und Niederlagen ==> Unentschieden!")

writev = str(win_stein) + " " + str(win_schere) + " " + str(win_papier)

with open("./programdata/schingschangschongiq/win.txt", "w") as file2:
    file2.write(writev)
    file2.close()

os.system("python ./SchingSchangSchongIntelligent.py")
