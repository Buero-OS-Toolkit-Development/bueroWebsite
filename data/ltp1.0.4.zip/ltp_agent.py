﻿import pyautogui as py
import bueroUtils, webbrowser, threading
from tkinter import *

print("LTP Agent wird gestartet...\nDies kann einen Moment in Anspruch nehmen...")

bü = bueroUtils.bueroUtils(packageName="LTP-Agent")
dLg = bü.dLg

def info():
    py.alert("LateinTrainerPlus ist ein Projekt von Leander Kafemann.\nEs bietet unter Anderem Ranglisten zum Vergleichen der Punktzahlen untereinander."+\
             "\n\nDer DesktopAgent ruft diese Daten ab und sendet Sie an unsere Server,\nsodass Sie Ihren Stand auch mobil abrufen können."+\
             "\n\nDie meisten Features sind nur im Browser verfügbar.\n\n"+\
             "Es ist empfohlen, den LTP-Agent möglichst oft auszuführen,\ndamit Ihre Punkte aktuell bleiben."+\
             "\n\nViel Spaß!", "Info")

def getCode() -> str:
    return bü.web_content("https://lkunited.pythonanywhere.com/getCode", {"username": USER, "id": BETA, "devid": DEVID, "password": "lkunited"})

def get_score(ID: str, book: str) -> tuple[str, str, str]:
    a = bü.web_content("https://latein.lernen.creativecouple.de/LateinTrainer/user/login", {"name": ID, "lehrbuch": book})
    x = "";y=""
    z = a.find("Gesamtpunkte:") + 21
    while x != "<":
        y += x
        z += 1
        x = a[z]
    b = ""; x = ""
    z = a.find("em")+2
    while x != "<":
        b += x
        z += 1
        x = a[z]
    c = "";x = ""
    z = a.find("Streak:")+15 #??
    while x != "<":
        c += x
        z += 1
        x = a[z]
    with open("./programdata/ltp/savedData.txt", "w", encoding="utf-8") as f:
        f.write(b+"#*#"+y+"#*#"+c)
    return y, b, c

def openLTP():
    webbrowser.open("https://leanderkafemann.github.io/LateinTrainerPlus/#")

root = Tk()
root.title("LTP Agent")
    
c = Canvas(root, width=400, height=250)
c.configure(bg="light blue")
c.pack()

c.create_text(180, 30, text="LTP Agent", font=("Verdana", "30", "bold"))
c.create_window(340, 30, anchor="w", window=Button(master=root, command=info, relief="flat", height=1, width=2, text="ⓘ", background="light blue", font=("Verdana", "20")))
c.create_text(200, 245, text="Copyright Leander Kafemann 2025  -  Version 1.0.4", font=("Verdana", "5"))

with open("./programdata/buero/username.txt", "r", encoding="utf-8") as f:
    USER = f.read()
with open("./programdata/buero/devid.txt", "r", encoding="utf-8") as f:
    DEVID = f.read()
BETA = str(bü.checkBETA(USER))
lt_ = bü.web_content("https://lkunited.pythonanywhere.com/ltp/getConnectedID", {"name": USER, "code": getCode()}).split("#*#")
LTID = lt_[0]; LTBOOK = lt_[1]

c.create_text(35, 75, anchor="w", text=f"LateinTrainer-ID: {LTID}\nBuch: {LTBOOK}    verknüpfter Büro-Nutzername: {USER}", font=("Verdana", "6", "italic"))

c.punkte, c.name, c.streak = get_score(LTID, LTBOOK)

c.scoreText = c.create_text(200, 150, text=f"Name: {c.name}\nPunkte: {c.punkte}\nStreak: {c.streak}", font=("Verdana", "16", "bold"))

def upload_data():
    py.alert(bü.web_content("https://lkunited.pythonanywhere.com/ltp/setScoreData", {"name": USER, "code": getCode(), "data": c.punkte+"#*#"+c.name+"#*#"+c.streak}), "Upload")

def share():
    emp = py.prompt("Empfänger angeben:", "Teilen")
    if emp != None:
        bü.shareViaMail(emp, "LateinTrainerPlus", f"Ich habe das folgende Ergebnis:\n{c.name}\n\nPunkte: {c.punkte}\nStreak: {c.streak}")

def refresh():
    c.punkte, c.name, c.streak = get_score(LTID, LTBOOK)
    c.itemconfig(c.scoreText, text=f"Name: {c.name}\nPunkte: {c.punkte}\nStreak: {c.streak}")
    root.update()
    upload_data()

threading.Thread(target=upload_data).start()

c.create_window(155, 220, anchor="center", window=Button(master=root, command=openLTP, relief="ridge", height=1, width=2, text="🌐", background="light blue"))
c.create_window(245, 220, anchor="center", window=Button(master=root, command=share, relief="ridge", height=1, width=2, text="⮫", background="light blue"))
c.create_window(185, 220, anchor="center", window=Button(master=root, command=refresh, relief="ridge", height=1, width=2, text="⟳", background="light blue"))
c.create_window(215, 220, anchor="center", window=Button(master=root, command=quit, relief="ridge", height=1, width=2, text="⏹", background="light blue"))

root.mainloop()