import os
import pyautogui as py

räume = os.listdir("./programdata/lebensmittel")
for i in range(len(räume)):
    räume[i] = räume[i].rstrip(".txt").capitalize()

lebensmittel = []
for i in räume:
    with open("./programdata/lebensmittel/"+i.lower()+".txt", "r", encoding="utf-8") as f:
        lebensmittel.append(f.read().split("#*#"))

mengen = []
for i in lebensmittel:
    i.remove("Default, 1")
    a = []
    for j in range(len(i)):
        b = i[j].split(", ") 
        a.append(b[1])
        i[j] = b[0]
    mengen.append(a)

while True:
    antwort = py.confirm("Welche dieser Optionen wollen Sie nutzen?", "Main Menu",\
                         buttons=("Lebensmittel hinzufügen", "Lebensmittel finden", "Neuer Raum", "Quit"))
    if antwort == "Lebensmittel hinzufügen":
        while True:
            antwort2 = py.confirm("In welchen Raum wollen Sie Lebensmittel hinzufügen?", "Raum", buttons=räume+["Zurück"])
            if antwort2 != "Zurück":
                idx = räume.index(antwort2)
            else:
                break
            while True:
                if len(lebensmittel[idx]) < 5:
                    antwort3 = py.confirm("Welches Lebensmittel wollen Sie hinzufügen?", antwort2, buttons=lebensmittel[idx]+["Neues Lebensmittel", "Zurück"])
                else:
                    antwort3 = py.prompt("Welches Lebensmittel wollen Sie hinzufügen?", antwort2, lebensmittel[idx][1])
                    if antwort3 == None:
                        antwort3 = "Zurück"
                if antwort3 != "Zurück":
                    if antwort3 == "Neues Lebensmittel":
                        antwort3 = py.prompt("Neues Lebensmittel eingeben:", "neues Lebensmittel")
                    antwort4 = py.prompt("Menge des Lebensmittels angeben (Anzahl der Packungen etc.):", antwort2, "1")
                    if not antwort3 in lebensmittel[idx]:
                        lebensmittel[idx].append(antwort3)
                        mengen[idx].append(antwort4)
                    else:
                        mengen[idx][lebensmittel[idx].index(antwort3)] = str(int(mengen[idx][lebensmittel[idx].find(antwort3)])+int(antwort4))
                else:
                    break
    elif antwort == "Lebensmittel finden":
        while True:
            llist = ["Zurück"]
            for i in lebensmittel[0]+lebensmittel[1]:
                if i not in llist:
                    llist.insert(0, i)
            if len(llist) < 7:
                antwort2 = py.confirm("Welches Lebensmittel wollen Sie finden?", "Lebensmittel finden", buttons=llist)
            else:
                antwort2 = py.prompt("Welches Lebensmittel wollen Sie finden?", "Lebensmittel finden", llist[1])
                if antwort2 == None:
                    antwort2 = "Zurück"
            if antwort2 != "Zurück":
                for i in range(len(lebensmittel)):
                    if antwort2 in lebensmittel[i]:
                        if py.confirm("Von dem Lebensmittel {} befinden sich {} Stück im Raum {}.".format(antwort2, mengen[i][lebensmittel[i].index(antwort2)], räume[i]),\
                                      "Lebensmittel gefunden", ("Zurück", "Lebensmittel entfernen")) == "Lebensmittel entfernen":
                            mng = mengen[i][lebensmittel[i].index(antwort2)]
                            mngEntf = py.prompt("Wie viel des Lebensmittels soll entfernt werden?", "Lebensmittel entfernen", mng)
                            if mngEntf == mng:
                                mengen[i].pop(lebensmittel[i].index(antwort2))
                                lebensmittel[i].remove(antwort2)
                            else:
                                mengen[i][lebensmittel[i].index(antwort2)] = str(int(mng)-int(mngEntf))
            else:
                break
    elif antwort == "Neuer Raum":
        antwort2 = py.prompt("Neuen Raum hinzufügen:", "neuer Raum")
        räume.append(antwort2)
        lebensmittel.append([])
        mengen.append([])
        with open("./programdata/lebensmittel/"+antwort2.lower()+".txt", "x", encoding="utf-8") as f:
            f.write("Default, 1")
    else:
        break

for i in räume:
    with open("./programdata/lebensmittel/"+i.lower()+".txt", "w", encoding="utf-8") as f:
        f.write("Default, 1")
        for j in lebensmittel[räume.index(i)]:
            f.write("#*#"+j+", "+mengen[räume.index(i)][lebensmittel[räume.index(i)].index(j)])
