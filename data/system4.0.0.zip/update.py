"""
Skript zum Installieren von Updates/-grades für Büro.
"""
def update(alter="Update", pStart=False):
    """
    Update: vorhandenes Paket wird upgedatet
    Upgrade: Paket wird neu installiert
    pStart: update wurde manuell (nicht über Büro) gestartet
    """
    import os, shutil, zipfile
    from tkinter.filedialog import askopenfilename
    import bueroUtils as b
    import pyautogui as py
    bü = b.bueroUtils()
    C_, C, T = bü.get_colors()
    s = bü.status("Updatevorgang", 49, 7, parts=7, colors=C, tcolors=T)
    s.send_message(" #initialisieren")
    #Initialisierung
    installiert = []
    addlist = ["Verschlüsseler", "Haustier", "Ballonfahrt", "SchingSchangSchongIQ",\
        "abstrakte Verzerrung", "im Verlies", "Passwortgenerator", "Musik", "Garten im Glück", "Lebensmittel", "Das große Quiz", "Rechnungen"]

    s.send_message(" #Pakete prüfen")
    files = os.listdir()
    if "verschlüsseln.py" in files:
        installiert.insert(0, "Verschlüsseler")
    if "Haustier.py" in files:
        installiert.insert(0, "Haustier")
    if "Ballonfahrt.py" in files and "Ballonfahrt-M2_1.py" in files and "Ballonfahrt-M2_2.py" in files:
        installiert.append("Ballonfahrt")
    if "SchingSchangSchongIntelligent.py" in files:
        installiert.insert(0, "SchingSchangSchongIQ")
    s.send_message(" #Pakete prüfen")
    if "abstrakt.py" in files:
        installiert.insert(0, "abstrakte Verzerrung")
    if "quest.py" in files and "level-editor.py" in files:
        installiert.insert(0, "im Verlies")
    if "Passwortgenerator.py" in files:
        installiert.insert(0, "Passwortgenerator")
    if "Musik.py" in files:
        installiert.insert(0, "Musik")
    if "Garten-im-Glück.py" in files:
        installiert.insert(0, "Garten im Glück")
    if "lebensmittel.py" in files:
        installiert.insert(0, "Lebensmittel")
    if "quiz.py" in files:
        installiert.insert(0, "Das große Quiz")
    if "Rechnung.pyw" in files:
        installiert.insert(0, "Rechnungen")

    for i in installiert:
        addlist.remove(i)
    installiert.append("Büro")

    pfad = askopenfilename(title="Zip-Datei mit Update auswählen", filetypes=[("ZIP comprimized folder", "*.zip")])
    tempfile = "./programdata/update"
    versiotest_ = list(pfad.split("/")[-1].rstrip(".zip").split("."))
    versiotest = versiotest_[0][-1]+"."+versiotest_[1]+"."+versiotest_[2]
    versionneu = py.prompt("Geben Sie die neu installierte Version an:", "Version angeben", versiotest)
    s.send_message(" #Update-Dateien lesen") #4.te Nachricht von 7
    with zipfile.ZipFile(pfad, 'r') as zip_ref:
        zip_ref.extractall(tempfile)
    print("Vorbereitung abgeschlossen.")
    if alter == "Update":
        antwort2 = py.confirm("Welches Ihrer Pakete wollen Sie updaten?", "Paket auswählen", buttons=(installiert))
        s.send_message(" #Update beginnen")
        if antwort2 == "Verschlüsseler":
            os.remove("./verschlüsseln.py")
            shutil.rmtree("./shopping")
            filelist = os.listdir("./programdata/verschlüsseln")
            filelist.remove("userlist.txt")
            for i in filelist:
                os.remove("./programdata/verschlüsseln/" + i)
            shutil.move(tempfile + "/verschlüsseln.py", "./verschlüsseln.py")
            shutil.move(tempfile + "/shopping", "./shopping")
            filelist = os.listdir(tempfile + "/programdata/verschlüsseln")
            filelist.remove("userlist.txt")
            for i in filelist:
                shutil.move(tempfile + "/programdata/verschlüsseln/" + i, "./programdata/verschlüsseln/" + i)
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Verschlüsseler.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Haustier":
            os.remove("./Haustier.py")
            shutil.move(tempfile + "/Haustier.py", "./Haustier.py")
            filelist = os.listdir(tempfile + "/programdata/haustier")
            filelist.remove("saved")
            filelist.remove("aktien")
            for i in filelist:
                shutil.rmtree("./programdata/haustier/" + i)
                shutil.move(tempfile + "/programdata/haustier/" + i, "./programdata/haustier/" + i)
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Haustier.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Ballonfahrt":
            filelist = os.listdir(tempfile + "/")
            filelist.remove("images"); filelist.remove("programdata")
            for i in filelist:
                try:
                    os.remove("./" + i)
                except:
                    pass
                shutil.move(tempfile + "/" + i, "./" + i)
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Ballonfahrt.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "SchingSchangSchongIQ":
            os.remove("./SchingSchangSchongIntelligent.py")
            shutil.move(tempfile + "/SchingSchangSchongIntelligent.py", "./SchingSchangSchongIntelligent.py")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_SchingSchangSchongIntelligent.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "abstrakte Verzerrung":
            os.remove("./abstrakt.py")
            shutil.move(tempfile + "/abstrakt.py", "./abstrakt.py")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_abstrakte Verzerrung.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "im Verlies":
            os.remove("./quest.py")
            os.remove("./level-editor.py")
            shutil.move(tempfile + "/quest.py", "./quest.py")
            shutil.move(tempfile + "/level_editor.py", "./level-editor.py")
            shutil.rmtree(tempfile + "/programdata")
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            with open("./programdata/buero/versioninfo_im Verlies.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Passwortgenerator":
            os.remove("./Passwortgenerator.py")
            shutil.move(tempfile + "/Passwortgenerator.py", "./Passwortgenerator.py")
            shutil.rmtree("./programdata/password")
            shutil.move(tempfile + "/programdata/password", "./programdata/password")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Passwortgenerator.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Musik":
            os.remove("./Musik.py")
            shutil.move(tempfile+"/Musik.py", "./Musik.py")
            shutil.rmtree(tempfile+"/programdata")
            with open("./programdata/buero/versioninfo_Musik.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Garten im Glück":
            os.remove("./Garten-im-Glück.py")
            shutil.move(tempfile+"/Garten-im-Glück.py", "./Garten-im-Glück.py")
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            with open("./programdata/buero/versioninfo_Garten im Glück.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Lebensmittel":
            os.remove("./lebensmittel.py")
            shutil.move(tempfile+"/lebensmittel.py", "./lebensmittel.py")
            with open("./programdata/buero/versioninfo_Garten im Glück.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Das große Quiz":
            os.remove("./quiz.py")
            shutil.move(tempfile+"/quiz.py", "./quiz.py")
            for i in os.listdir(tempfile+"/music"):
                shutil.move(tempfile+"/music/"+i, "./music/"+i)
            shutil.rmtree(tempfile+"/music")
            with open("./programdata/buero/versioninfo_Das große Quiz.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Rechnungen":
            os.remove("./Rechnung.pyw")
            shutil.move(tempfile+"/Rechnung.pyw", "./Rechnung.pyw")
            with open("./programdata/buero/versioninfo_Rechnungen.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "BüroMail":
            os.remove("./mail.py")
            os.remove("./mail_agent.py")
            shutil.move(tempfile + "/mail.py", "./mail.py")
            shutil.move(tempfile + "/mail_agent.pyw", "./mail_agent.pyw")
            for i in os.listdir(tempfile + "/programdata/mail"):
                if "." in i:
                    shutil.move(tempfile + "/programdata/mail/"+i, "./programdata/mail/"+i)
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_BüroMail.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Büro":
            os.remove("./büro.py")
            os.remove("./bueroUtils.py")
            shutil.move(tempfile + "/büro.py", "./büro.py")
            shutil.move(tempfile + "/bueroUtils.py", "./bueroUtils.py")
            for i in os.listdir(tempfile):
                if "tipps.txt" == i:
                    os.remove("./programdata/buero/tipps.txt")
                    shutil.move(tempfile+"/"+i, "./programdata/buero/tipps.txt")
                elif ".lkim" in i:
                    if "Special" in i:
                        shutil.move(tempfile+"/"+i, "./programdata/lkims/"+i)
                    else:
                        if i in os.listdir("./programdata/achievements"):
                            os.remove("./programdata/achievements/"+i)
                        shutil.move(tempfile+"/"+i, "./programdata/achievements/"+i)
                elif "z!" in i:
                    shutil.move(tempfile+"/"+i, "./programdata/win/"+i)
                else:
                    shutil.move(tempfile+"/" + i, "./programdata/ads/" + i)
            with open("./programdata/buero/versioninfo.txt", "w") as newV:
                newV.write(versionneu)
            py.alert("Bitte beachten Sie, dass Sie nach dem Updaten von Büro ggf. zunächst die Fehleranalyse starten sollten, um Fehler beim Bootvorgang zu vermeiden.", "Fehleranalyse")
        else:
            quit(code="ERROR")
        s.send_message(" #Update installieren")
        print("Installation abgeschlossen")
    elif alter == "Upgrade":
        antwort2 = py.confirm("Welches unserer Pakete möchten Sie neu hinzufügen?", "Upgrade", buttons=(addlist))
        s.send_message(" #Upgrade beginnen")
        if antwort2 == "Verschlüsseler":
            shutil.move(tempfile + "/verschlüsseln.py", "./verschlüsseln.py")
            shutil.move(tempfile + "/shopping", "./shopping")
            os.mkdir("./programdata/verschlüsseln")
            filelist = os.listdir(tempfile + "/programdata/verschlüsseln")
            for i in filelist:
                shutil.move(tempfile + "/programdata/verschlüsseln/" + i, "./programdata/verschlüsseln/" + i)
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Verschlüsseler.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Haustier":
            shutil.move(tempfile + "/Haustier.py", "./Haustier.py")
            with open("./programdata/buero/versioninfo_Haustier.txt", "w") as newV:
                newV.write(versionneu)
            os.mkdir("./programdata/haustier")
            shutil.move(tempfile + "/programdata/haustier/music", "./programdata/haustier/music")
            shutil.move(tempfile + "/programdata/haustier/saved", "./programdata/haustier/saved")
            shutil.rmtree(tempfile + "/programdata")
        elif antwort2 == "Ballonfahrt":
            filelist = os.listdir(tempfile + "/")
            filelist.remove("images"); filelist.remove("programdata")
            for i in filelist:
                shutil.move(tempfile + "/" + i, "./" + i)
            shutil.move(tempfile + "/programdata/ballonfahrt", "./programdata/ballonfahrt")
            shutil.rmtree(tempfile + "/programdata")
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            with open("./programdata/buero/versioninfo_Ballonfahrt.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "SchingSchangSchongIQ":
            shutil.move(tempfile + "/SchingSchangSchongIntelligent.py", "./SchingSchangSchongIntelligent.py")
            shutil.move(tempfile + "/programdata/schingschangschongiq", "./programdata/schingschangschongiq")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_SchingSchangSchongIQ.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "abstrakte Verzerrung":
            shutil.move(tempfile + "/abstrakt.py", "./abstrakt.py")
            shutil.move(tempfile + "/programdata/abstrakt", "./programdata/abstrakt")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_abstrakte Verzerrung.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "im Verlies":
            shutil.move(tempfile + "/quest.py", "./quest.py")
            shutil.move(tempfile + "/level_editor.py", "./level-editor.py")
            shutil.move(tempfile + "/programdata/verlies", "./programdata/verlies")
            shutil.rmtree(tempfile + "/programdata")
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            with open("./programdata/buero/versioninfo_im Verlies.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Passwortgenerator":
            shutil.move(tempfile + "/Passwortgenerator.py", "./Passwortgenerator.py")
            shutil.move(tempfile + "/programdata/password", "./programdata/password")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Passwortgenerator.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Musik":
            shutil.move(tempfile + "/Musik.py", "./Musik.py")
            shutil.move(tempfile + "/programdata/music", "./programdata/music")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Musik.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Garten im Glück":
            shutil.move(tempfile+"/Garten-im-Glück.py", "./Garten-im-Glück.py")
            filelist = os.listdir(tempfile + "/images")
            for i in filelist:
                shutil.move(tempfile + "/images/" + i, "./images/" + i)
            shutil.rmtree(tempfile + "/images")
            with open("./programdata/buero/versioninfo_Garten im Glück.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Lebensmittel":
            shutil.move(tempfile + "/lebensmittel.py", "./lebensmittel.py")
            shutil.move(tempfile + "/programdata/lebensmittel", "./programdata/lebensmittel")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_Lebensmittel.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Das große Quiz":
            shutil.move(tempfile+"/quiz.py", "./quiz.py")
            for i in os.listdir(tempfile+"/music"):
                shutil.move(tempfile+"/music/"+i, "./music/"+i)
            shutil.rmtree(tempfile+"/music")
            with open("./programdata/buero/versioninfo_Das große Quiz.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "Rechnungen":
            shutil.move(tempfile+"/Rechnung.pyw", "./Rechnung.pyw")
            os.mkdir("./programdata/rechnungen")
            with open("./programdata/buero/versioninfo_Rechnungen.txt", "w") as newV:
                newV.write(versionneu)
        elif antwort2 == "BüroMail":
            shutil.move(tempfile + "/mail.py", "./mail.py")
            shutil.move(tempfile + "/mail_agent.pyw", "./mail_agent.pyw")
            shutil.move(tempfile + "/programdata/mail", "./programdata/mail")
            shutil.rmtree(tempfile + "/programdata")
            with open("./programdata/buero/versioninfo_BüroMail.txt", "w") as newV:
                newV.write(versionneu)
        else:
            quit(code="ERROR")
        s.send_message(" #Upgrade installieren")
        print("Installation abgeschlossen.")
    else:
        quit(code="ERROR")
    s.send_message(" #Vorgang abschließen")
    py.alert("Die Operation war erfolgreich.", "Ende")
    if not pStart:
        try:
            bü.restart()
        except:
            py.alert("Fehler beim Neustarten.\nStarten Sie Büro manuell neu.", "Fehler")
    else:
        if py.confirm("Jetzt ausprobieren?", "Büro starten", buttons=("JA", "NEIN")) == "JA":
            py.alert("Warnung: Falls Sie Büro jetzt starten, kann es zu Fehlern kommen.")
            os.system("python ./büro.py")
    
if __name__ == "__main__":
    import pyautogui as py
    update(alter=("Update" if py.confirm("Art des Vorgangs wählen:", "Update", buttons=("Update", "Upgrade")) == "Update" else "Upgrade"), pStart=True)
