"""
Werkzeuge für Büro.
"""
class bueroUtils:
    """
    Werkzeuge für Büro.
    """
    def __init__(self, spec: bool = False, packageName: str = "Büro"):
        """
        Initialisiert bueroUtils.
        spec -- Verhindert erneutes Laden eines debugLogs.
        packageName -- spezifiert Namen des ausgeführten Pakets.
        """
        import pycols, os
        self.status = status
        self.debugLog = debugLog
        if not spec:
            self.dLg = debugLog(packageName=packageName)
            self.dLg.entry(self.dLg)
        self.c = pycols.color()
        self.os = os
    def installmod(self, module: str):
        """
        Installiert gegebenes Modul in subshell.
        """
        print(module, "wird installiert...")
        self.os.system("python -m pip install " + module)
        print("Installation erfolgreich abgeschlossen.")
    def installmodules(self, modules: list[str]):
        """
        Installiert gegebene Module mit obiger Funktion
        """
        if len(modules) > 0:
            C_, C, T = self.get_colors()
            s = self.status("Modulinstallation: ", parts=len(modules)+1, colors=C, tcolors=T)
            s.send_message(" #Modulinstallation beginnen")
            for i in modules:
                self.installmod(i)
                s.send_message(" #Modul "+i+" installiert")
            s.send_message(" #Vorgang abschließen")
    def install_check(self, modules: list[str]):
        """
        Überprüft für  jedes Modul, ob dieses installiert ist.
        Installiert fehlende Module.
        """
        x = []
        C_, C, T = self.get_colors()
        s = self.status("Modulüberprüfung: ", parts=len(modules)+1, fill=">", number=40, colors=C, tcolors=T)
        for i in modules:
            s.send_message(add=" #Modul "+i+" prüfen")
            if not self.is_installed(i if i != "pillow" else "PIL"):
                x.append(i)
        s.send_message(add=" #fehlende Module ({}{}{}) installieren".format(self.c.col(self.traffic(len(x),\
                       0, len(modules), duo=False, traffic_col=T))+self.c.BRIGHT,str(len(x)), self.c.RESET_ALL+self.c.col(C[1])))
        self.installmodules(x)
        s.send_message(add=" #Vorgang abschließen")
    def is_installed(self, pkcg):
        """
        Prüft, ob Modul installiert ist.
        """
        import sys, io
        x = sys.stdout; sys.stdout = io.StringIO(); IN = True
        try:
            __import__(pkcg)
        except:
            IN = False
        finally:
            sys.stdout = x
            return IN
    def update(self, module="pip"):
        """
        Installiert über subshell Update für gegebenes Paket.
        """
        print("Modul " + module + " wird aktualisiert.")
        self.os.system("python.exe -m pip install --upgrade " + module)
        print("Aktualisierung erfolgreich abgeschlossen.")
    def updates(self, modules: list[str, str]):
        """
        Updated mehrere Pakete über obige Funktion.
        """
        C_, C, T = self.get_colors()
        s = status("Modulupdates: ", parts=len(modules), colors=C, tcolors=T)
        for i in modules:
            s.send_message(" #Modul "+(i if i != "" else "pip")+" aktualisieren")
            if  i == "":
                self.update()
            else:
                self.update(i)
        s.send_message(" #Updatevorgang abschließen")
    def remove_(self, files: list[str, str] = [], filepath: str = "./"):
        """
        Entfernt mehrere Dateien
        """
        import os
        self.dLg.entry(files)
        for i in files:
            os.remove(filepath+i)
    def round_agent(self, zähler: int = 10, nenner: int = 10, max_: int = 90, min_: int = 10):
        """
        Kürzt Wert
        """
        import math
        while nenner > max_:
            zähler /= 1.3; nenner /= 1.3
        while nenner < min_:
            zähler *= 1.3; nenner *= 1.3
        return math.ceil(zähler), math.ceil(nenner)
    def getad(self, Id: str, end=".png"):
        """
        Sendet Anzeige.
        """
        self.dLg.entrys("bü.getad called", Id, end)
        file = "./programdata/ads/" + Id + end
        from easygui import buttonbox
        buttonbox("", "Ad", [], image=file)
    def pruefePIN(self, toCheck: str, PIN_e: str, lenge: int):
        """
        Überprüft eingegebene PIN mit echter, verschlüsselter PIN.
        """
        self.dLg.entrys("bü.pruefePIN called", toCheck, PIN_e, lenge)
        import pyautogui as py
        if len(toCheck) == lenge:
            import random
            random.seed(int(toCheck))
            if str(random.randint(1, 10**30)) == PIN_e:
                return True
            else:
                py.alert("Falsche Eingabe!", "FALSCH!")
                return False
        else:
            py.alert("Fehlerhafte Eingabe!", "FALSCH!")
            return False
    def PIN_check(self, PIN_e: str, lenge: int, act: str):
        """
        komplette Methode zur Überprüfung der PIN, falls PIN aktiv
        """
        self.dLg.entrys("bü.PIN_check called", PIN_e, lenge, act)
        if act == "True":
            import pyautogui as py
            PIN_u = py.password("PIN eingeben:")
            return self.pruefePIN(PIN_u, PIN_e, lenge)
        else:
            return True
    def PIN_erstellen(self, PIN_e: str = "198441737587687207744109680148", lenge: int = 4):
        """
        Methode zum erstellen einer neuen PIN.
        Falls der Vorgang abgebrochen wird, wird die PIN bei in Büro auftretenden Fehlern auf 0000 gesetzt.
        """
        self.dLg.entry("bü.PIN_erstellen called")
        import pyautogui as py
        import random
        pin = 1; pin2 = 2; restore = 0; breakForced = False
        while pin != pin2 or len(str(pin)) not in list(range(4, 31)):
            pin_ = py.password("4- bis 30-stellige Büro-PIN erstellen:", "Büro-PIN")
            pin2_ = py.password("Büro-PIN bestätigen:", "Büro-PIN")
            if pin_ == None or pin2_ == None:
                breakForced = True
                break
            else:
                pin = int(pin_); pin2 = int(pin2_)
        if not breakForced:
            while restore == 0 or len(str(restore)) != 32:
                restore = int(py.prompt("Wiederherstellungs-PIN erstellen:\nHinweis: Der Wiederherstellungsschlüssel wird benötigt, um deine PIN wiederherzustellen und hat 32 Stellen.", "Wiederherstellungsschlüssel", random.randint(1, 10**32-1)))
            random.seed(pin)
            lenge = len(str(pin))
            PIN_e = str(random.randint(1, 10**30))
            with open("./programdata/buero/PIN.txt", "w") as pin_f:
                pin_f.write(PIN_e)
            with open("./programdata/buero/PIN_l.txt", "w") as pin_l:
                pin_l.write(str(lenge))
            random.seed(restore)
            with open("./programdata/buero/restore.txt", "w") as rest:
                rest.write(str(random.randint(1, 10**40)))
            return PIN_e, lenge
        else:
            py.alert("Achtung:\nFalls Sie gerade eine PIN zum ersten Mal erstellen sollten, wurde sie soeben auf 0000 zurückgesetzt.", "Achtung")
            return PIN_e, lenge
    def uninstallmessage(self):
        """
        Sendet Nachricht, dass Büro deinstalliert wurde.
        """
        self.dLg.entry("bü.uninstallmessage called")
        import pyautogui as py
        py.alert("Büro deinstalliert!")
        quit()
    def get_size(self, path: str):
        """
        Ermittelt Größe einer Datei oder rekursiv aller untergeordneten Dateien.
        """
        self.dLg.entrys("bü.get_size called", path)
        size = 0
        if self.os.path.isdir(path):
            for file in self.os.listdir(path):
                size += self.get_size(path+"/"+file)
        else:
            size = self.os.stat(path).st_size
        return size
    def get_sizes(self, pathlist: list[str, str] = [], prepath: str = ""):
        """
        Wendet obige Methode auf mehrere Dateien/Ordner an.
        Falls impath == True wird automatisch ein Pfadbestandteil ergänzt.
        """
        self.dLg.entrys("bü.get_sizes called", pathlist, prepath)
        size = 0
        for i in pathlist:
            size += self.get_size(prepath + i)
        return size
    def traffic(self, numb: int = 1, prgs_min: int = 0, prgs_max = 2, traffic_col = ["RED", "YELLOW", "GREEN"], expt: str = "min", duo: bool = True):
        """
        Gibt Farbe aus 2/3 langer Liste je nach gegebenem Wert und Prognosen zurück.
        """
        self.dLg.entrys("bü.traffic called", numb, prgs_min, prgs_max, traffic_col, expt, duo)
        t_c = traffic_col.copy()
        if expt == "min":
            t_c.reverse()
        x = (prgs_max-prgs_min+1)/(2 if duo else 3)
        a = t_c[2]
        if numb < prgs_min+(0 if duo else x):
            a = t_c[0]
        if numb < prgs_min+(x if duo else 2*x) and numb >= prgs_min+(0 if duo else x):
            a = t_c[1]
        return a
    def trafficer(self, numb: int = 1, prgs_min: int = 0, prgs_max = 2, traffic_col = ["RED", "YELLOW", "GREEN"], expt: str = "min", duo: bool = True, mthd: callable = str):
        """
        Verwaltet mit obiger Methode Nachricht.
        """
        return self.c.col(self.traffic(numb, prgs_min, prgs_max, traffic_col, expt, duo))+mthd(numb)+self.c.RESET_ALL
    def get_colors_(self):
        """
        Liest gespeicherte Farben aus.
        """
        with open("./programdata/buero/color.txt", "r") as f:
            x = list(f.read().rstrip("#*#").split("#*#"))
        self.dLg.entrys("get_colors:", x)
        return x
    def get_colors(self):
        """
        Verpackt gespeicherte Farben in Listen.
        """
        x = self.get_colors_()
        return x, x[0:2], x[2:6]
    def display_achievement(self, name: str):
        """
        Zeigt Erfolg an.
        """
        import pyimager as pi
        schabl = "./programdata/achievements/{}.lkim"; self.dLg.entry(name)
        try:
            pi.display(schabl.format(name))
        except:
            pi.display(schabl.format("Hidden"))
            self.dLg.entry("MISSING!"); print("ERFOLG FEHLT! SIE HABEN EIN UPDATE NICHT INSTALLIERT! WENDEN SIE SICH AN DEN KUNDENSERVICE!")
    def numeral(self, grade:int = 1, sex: str = "m"):
        """
        Ermittelt Numeral (Zahlwort) für gegebene Zahl mit gegebenem Geschlecht.
        Range: 1 bis 12, danach ValueError
        """
        match grade:
            case 1:
                a = "erste"
            case 2:
                a = "zweite"
            case 3:
                a = "dritte"
            case 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12:
                b = ["vier", "fünf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwölf"]
                a = b[grade-4]+"te"
            case _:
                raise ValueError("Value not in Range")
        if sex == "m":
            a += "r"
        elif sex == "n":
            a += "s"
        return a
    def web_content(self, url: str, data: dict = {}, update: bool = False):
        """
        Lädt Webinhalte herunter.
        """
        import requests
        rq = requests.post(url, data).content
        return str(rq, encoding="utf-8").lstrip("b").replace("'", "").replace('"', '') if not update else rq; str
    def web_update(self, url: str, username: str = "RANDOM_USER"):
        """
        Lädt Update aus Web herunter.
        """
        import pyautogui as py
        import zipfile
        update_list = self.web_content(url, {"message": username, "pw": "lkunited"}, True).decode("unicode_escape").lstrip("b'").rstrip("'").split("#**"+"*#")
        update_string = update_list[-1]; update_version = update_list[0]
        if not update_string in ["SERVERWARTUNG", "FLAG_DOWN", "UPLOADING", "BETA"]:
            if py.confirm(f"Update erfolgreich heruntergeladen.\nheruntergeladene Version: {update_version}\nWollen Sie fortfahren?", "Herunterladen erfolgreich", buttons=("JA", "NEIN")) == "JA":
                update_files = update_string.split("#SEP_FOR"+"_UPDATES#") #Aufteilung notwendig
                filenames_u = ["büro.py", "bueroUtils.py", "tipps.txt"]
                for i in range(3):
                    with open("./programdata/update/"+filenames_u[i], "w", encoding="utf-8") as f:
                        update_files[i] = update_files[i].lstrip("b'").rstrip("'").replace("Ã¼", "ü").replace("\r\n", "\n")
                        update_files[i] = update_files[i].replace("Ã¤", "ä").replace("Ã¶", "ö").replace("Ã", "Ö").replace("BÖRO", "BÜRO").replace("Önderung", "Änderung")
                        f.write(update_files[i])
                with zipfile.ZipFile(f"./büro{update_version}.zip", "w") as update_file:
                    for i in filenames_u:
                        update_file.write("./programdata/update/"+i, i)
                        self.os.remove("./programdata/update/"+i)
                py.alert("Das Herunterladen war erfolgreich.\nBitte beachten Sie, dass keine neuen Eventdaten heruntergeladen wurden.", "Erfolgreich")
                return True
            else:
                return False
        else:
            py.alert("Herunterladen fehlgeschlagen.\nDer Server wird aktuell vermutlich gewartet.\nFehlercode: "+update_string, "Fehler")
            return False
    def checkPREMIUM(self, pass_: str = "", getPass: bool = False) -> bool:
        """
        Überprüft, ob der gegebene Pass des Nutzers gültig ist.
        Setzen Sie getpass auf True, damit bueroUtils den Pass automatisch selbst ausliest.
        """
        if getPass:
            try:
                with open("./premiumpass.txt", "r", encoding="utf-8") as f:
                    pass_ = f.read()
            except:
                return False; bool
        checkPRE = "True" in self.web_content("https://lkunited.pythonanywhere.com/checkerP", {"message":pass_, "pw":"lkunited"})
        return checkPRE; bool
    def createPreMail(self, to: str, subject: str, content: str):
        """
        Creates presaved Mail for BüroMail,
        overwriting any other presaved mails.
        """
        with open("./programdata/mail/pre_mail.txt", "w", encoding="utf-8") as f:
            f.write(f"{to}#**#{subject}#**#{content}")
    def buttonLog(self, text: str = "Bitte bestätigen:", title: str = "Bestätigen", buttons: tuple = ("Fortfahren", "Abbrechen")):
        """
        Fragt den Nutzer nach gegebenen Aspekten und trägt Antwort in debugLog ein.
        """
        import pyautogui as py
        aw = py.confirm(text, title, buttons)
        self.dLg.entry(aw)
        return aw; str
    def error_quit(self):
        """
        Beendet Büro nach User-Error.
        """
        try:
            self.error_message()
        finally:
            self.os.remove("./programdata/run/running.txt")
            self.dLg.entry("User-Error; Quitting")
            self.dLg.finalsave_log()
            quit(code="Error-Edited")
    def error_message(self):
        """
        Sendet Fehlermeldung.
        """
        import pyautogui as py
        py.alert("Büro ist abgestürzt. Nutzen Sie fehleranalyse.py, um ein DebugLog zu übermitteln.")
    def restart(self):
        """
        Startet Büro ggf. neu.
        """
        import pyautogui as py
        import sys
        if self.buttonLog("Eventuell muss Büro neugestartet werden, um alle Änderungen zu übernehmen.", "Neustart erforderlich", buttons=("NEU STARTEN", "IGNORIEREN")) == "NEU STARTEN":
            self.dLg.finalsave_log()
            self.os.remove("./programdata/run/running.txt")
            self.os.system("cls")
            self.os.execv(sys.executable, ['python'] + sys.argv)
    def normal_quit(self):
        """
        Beendet Büro regulär.
        """
        self.os.remove("./programdata/run/running.txt")
        self.dLg.finalsave_log()
        quit(code="Ende-Edited")

class debugLog(bueroUtils):
    """
    Klasse zum Erstellen eines Debug-Logs.
    """
    def __init__(self, packageName: str = "Büro"):
        from io import StringIO
        self.out = StringIO()
        self.canceled = False
        self.packageName = packageName
        bueroUtils.__init__(self, spec=True)
    def entry(self, entry, sep: str = "\n"):
        """
        Fügt Eintrag in Debug-Log-Objekt hinzu.
        """
        print(entry, file=self.out, sep=sep)
    def entrys(self, sep: str = "\n", *arg):
        """
        Fügt über obige Methode mehrere Einträge hinzu.
        """
        for i in arg:
            self.entry(str(i), sep=sep)
    def save_log(self, name_add: str = ""):
        """
        Speichert Debug-Log.
        """
        import datetime
        if self.canceled == False:
            with open("./programdata/buero/debug/{}{}_debug_log_{}.txt".format(name_add, self.packageName, str(datetime.datetime.today())[0:-7].replace(" ", "-").replace(":", "-")), "w", encoding="utf-8") as f:
                f.write(self.out.getvalue())
    def presave_log(self):
        """
        Speichert Debug-Log mit vorangehendem 'pre_'-Code.
        """
        self.entry("Presaving log...")
        self.save_log(name_add="pre_")
    def finalsave_log(self):
        """
        Speichert Debug-Log und entfernt alle presaves.
        """
        for i in list(self.os.listdir("./programdata/buero/debug")):
            if i.startswith("pre_"):
                self.os.remove("./programdata/buero/debug/"+i)
        self.save_log()
    def alter_package_name(self, newPackageName: str):
        self.packageName = newPackageName
    def cancel_(self):
        """
        Kehrt canceled-Einstlg. um
        """
        from naturalsize import reverse
        self.canceled = reverse(self.canceled)

class status(bueroUtils):
    """
    Klasse für das Erstellen eines Status-Bars.
    """
    def __init__(self, message: str = "", number: int = 50, start: int = 0, fill: str = "-", unfill: str = " ", end: str = "|", \
                 parts: int = 1, colors: list[str, str] = ["WHITE"]*2, tcolors: list[str, str, str] = ["WHITE"]*3):
        bueroUtils.__init__(self)
        self.message = message
        self.number = number
        self.fill = fill
        self.unfill = unfill
        self.end = end
        self.akt = start
        self.parts = parts
        self.colors = colors
        self.tcolors = tcolors
        while self.number % self.parts != 0:
            self.number += 1
        self.dLg.entry("Status-Class used: {}#{}#{}#{}#{}#{}#{}#{}".format(message, str(number), str(self.number), fill, unfill, end, start, parts))
    def send_message(self, add: str = ""):
        """
        Sendet vollständigen Status-Bar mit variabler Nachricht und Farbe.
        """
        print(self.c.col(self.colors[0])+self.message+self.c.RESET_ALL+self.end+\
              self.c.col(self.traffic(self.akt, 0, self.number, self.tcolors, "max", False))+self.akt*self.fill+\
              (self.number-self.akt)*self.unfill+self.c.RESET_ALL+self.end+self.c.col(self.colors[1])+add+self.c.RESET_ALL)
        self.akt += int(self.number/self.parts)
        self.dLg.entry("Number:{};Message:{}".format(self.akt, add))
    def init_one_bar(self):
        """
        Initialisiert einen Status-Bar.
        """
        print(self.c.col(self.colors[0])+self.message+self.c.col("RESET")+self.end+self.c.col(self.colors[1])+\
              self.akt*self.fill, end="")
        self.dLg.entry("One-Bar-Init")
    def draw_one_bar(self):
        """
        Setzt initialisierten Status-Bar fort.
        Hinweis: Diese Methode ergibt nur bei einem schnellen Prozess Sinn!
        """
        print(int(self.number/self.parts)*self.fill, end="")
        self.dLg.entry("Draw-One-Bar")
    def finish_one_bar(self):
        """
        Beendet fertigen Status-Bar.
        """
        print(self.c.col("RESET")+self.end)
        self.dLg.entry("Finish-One-Bar")

if __name__ == "__main__":
    import naturalsize
    print("Warten Sie einige Sekunden, um alle Ihre Module aktualisieren zu lassen.\nDrücken Sie Strg+c zum Abbrechen.")
    if not naturalsize.special_starter(300000000):
        bueroUtils().updates(modules=['', 'colorama', 'easygui', 'eyed3', 'keyboard', 'naturalsize', 'numpy', 'pgzero', 'pillow', 'ping3', 'pyautogui', 'pycols', 'pygame', 'pyimager', 'pyperclip', 'pysounds', 'requests'])
elif __name__ == "bueroUtils":
    import sys
    allowed = ["", "büro.py", "bueroUtils.py", "update.py", "mail.py", "mail_agent.pyw"]
    sys_ = [i.split("\\")[-1].split("./")[-1] for i in sys.argv]
    #print(sys_)
    proceed = True
    for i in sys_:
        if i not in allowed:
            proceed = False
            break
    if not proceed:
        raise ImportError("Invalid or unauthorized script or plugin.")