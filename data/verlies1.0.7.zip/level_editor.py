class level:
    def levelmaker(level: str, mapping: list):
        with open("./programdata/verlies/lvl" + level + ".txt", "x") as file:
            x = len(mapping) - 1
            durchlauf = 0
            for i in mapping:
                if not durchlauf == x:
                    file.write(i + "\n")
                else:
                    file.write(i)
                durchlauf += 1
            file.close()

    def levelmakers(self, levels: list[str], mappings: list[list[str]]):
        for i in levels:
            self.levelmaker(i, mappings[levels.index(i)])

class console:
    def __init__(self, toLoad = [], selected = " "):
        self.level = toLoad
        self.selected = selected
    def get(self, margin = 0, message = ""):
        return input(margin * " " + message + " >>> ")
    def select(self, toSelect):
        self.selected = toSelect
    def add_line(self, numb):
        for i in range(numb):
            self.level.append(self.width() * self.selected)
    def alter(self, lineIndex, charIndex):
        line = self.level[lineIndex]
        line2 = ""
        for i in range(len(line)):
            if not i == charIndex:
                line2 += line[i]
            else:
                line2 += self.selected
        self.level[lineIndex] = line2
    def alter_line(self, lineIndex):
        self.level[lineIndex] = self.width() * self.selected
    def alter_column(self, rowIndex):
        for i in range(self.height()):
            self.alter(i, rowIndex)
    def alter_out(self):
        self.alter_line(0)
        self.alter_column(0)
        self.alter_column(self.width() - 1)
        self.alter_line(self.height() - 1)
    def add_column(self, numb):
        for i in self.level:
            self.level[self.level.index(i)] += numb * self.selected
    def save(self, name):
        level.levelmaker(name, self.level)
    def quitAll(self):
        import os
        os._exit(-1)
    def width(self):
        return len(self.level[0])
    def height(self):
        return len(self.level)

class get:
    global con
    def __init__(self, initialize):
        self.initialize = initialize
        self.definitionen = []
        self.befehle = []
        self.vars = []
        self.werte = []
        self.def_active = False
    def get_args(self, todoAll):
        self.arg1 = None
        self.arg2 = None
        try:
            self.todo, self.arg1, self.arg2 = todoAll.split(" ")
        except:
            try:
                self.todo, self.arg1 = todoAll.split(" ")
            except:
                self.todo = todoAll
        self.alter_to_var(self.arg1)
        self.alter_to_var(self.arg2, var="arg2")
        arg = str(self.arg1)
        if not "+" in arg and not "-" in arg and not "*" in arg and not "/" in arg:
            self.check_operation(self.arg1)
        self.check_operation(self.arg2, var="arg2")
    def alter_to_var(self, toCheck, var="arg1"):
        if toCheck != None and  self.todo != "save":
            toCheck = str(toCheck)
            for i in self.vars:
                if i in toCheck:
                    toCheckRet = ""
                    for i in toCheck:
                        toCheckRet += i if not i in self.vars else str(self.werte[self.vars.index(i)])
                    if var == "arg1":
                        self.arg1 = toCheckRet
                    elif var == "arg2":
                        self.arg2 = toCheckRet
                    elif var == "todo":
                        self.todo = toCheckRet
    def check_operation(self, toCheck, var="arg1"):
        if toCheck != None:
            toCheck = str(toCheck)
            if "*" in toCheck and not "+" in toCheck and not "-" in toCheck and not "**" in toCheck:
                operatorList = list(toCheck.split("*", 1))
                d = 0
                for i in operatorList:
                    if "+" in i or "-" in i or "*" in i or "/" in i:
                        i = self.check_operation(i, var="return")
                    operatorList[d] = float(i)
                    d += 1
                if var == "arg1":
                    self.arg1 = operatorList[0] * operatorList[1]
                elif var == "arg2":
                    self.arg2 = operatorList[0] * operatorList[1]
                elif var == "todo":
                    self.todo = operatorList[0] * operatorList[1]
                else:
                    return operatorList[0] * operatorList[1]
            elif "-" in toCheck and "-" != toCheck[0]:
                operatorList = list(toCheck.split("-", 1))
                d = 0
                for i in operatorList:
                    if "+" in i or "-" in i or "*" in i or "/" in i:
                        i = self.check_operation(i, var="return")
                    operatorList[d] = float(i)
                    d += 1
                if var == "arg1":
                    self.arg1 = operatorList[0] - operatorList[1]
                elif var == "arg2":
                    self.arg2 = operatorList[0] - operatorList[1]
                elif var == "todo":
                    self.todo = operatorList[0] - operatorList[1]
                else:
                    return operatorList[0] - operatorList[1]
            elif "/" in toCheck and not "+" in toCheck and not "-" in toCheck:
                operatorList = list(toCheck.split("/", 1))
                d = 0
                for i in operatorList:
                    if "+" in i or "-" in i or "*" in i or "/" in i:
                        i = self.check_operation(i, var="return")
                    operatorList[d] = float(i)
                    d += 1
                if var == "arg1":
                    self.arg1 = operatorList[0] / operatorList[1]
                elif var == "arg2":
                    self.arg2 = operatorList[0] / operatorList[1]
                elif var == "todo":
                    self.todo = operatorList[0] / operatorList[1]
                else:
                    return operatorList[0] / operatorList[1]
            elif "+" in toCheck:
                operatorList = list(toCheck.split("+", 1))
                d = 0
                for i in operatorList:
                    if "+" in i or "-" in i or "*" in i or "/" in i:
                        i = self.check_operation(i, var="return")
                    operatorList[d] = float(i)
                    d += 1
                if var == "arg1":
                    self.arg1 = operatorList[0] + operatorList[1]
                elif var == "arg2":
                    self.arg2 = operatorList[0] + operatorList[1]
                elif var == "todo":
                    self.todo = operatorList[0] + operatorList[1]
                else:
                    return operatorList[0] + operatorList[1]
            elif "**" in toCheck:
                operatorList = list(toCheck.split("**", 1))
                d = 0
                for i in operatorList:
                    if ("+" in i or "-" in i or "*" in i or "/" in i or "**" in i):
                        i = self.check_operation(i, var="return")
                    operatorList[d] = float(i)
                    d += 1
                if var == "arg1":
                    self.arg1 = operatorList[0] ** operatorList[1]
                elif var == "arg2":
                    self.arg2 = operatorList[0] ** operatorList[1]
                elif var == "todo":
                    self.todo = operatorList[0] ** operatorList[1]
                else:
                    return operatorList[0] ** operatorList[1]
            else:
                return "an error occured"
    def get_new_args(self, margin=4, message="", arg="arg1", var=True):
        if arg == "arg1":
            self.arg1 = con.get(margin=margin, message=message)
            if var:
                self.alter_to_var(self.arg1)
                self.check_operation(self.arg1, var="arg1")
        elif arg == "arg2":
            self.arg2 = con.get(margin=margin, message=message)
            if var:
                self.alter_to_var(self.arg2, var="arg2")
                self.check_operation(self.arg2, var="arg2")
        else:
            self.todo = con.get(margin=margin, message=message)
            if var:
                self.alter_to_var(self.todo, var="todo")
                self.check_operation(self.todo, var="todo")
    def get_todo(self, toLoad=""):
        global active
        active = True
        if toLoad == "":
            self.get_args(con.get())
        else:
            self.get_args(toLoad)
        self.run_command()
    def run_command(self):
        global active
        active = True
        if self.todo == "addLine":
            if self.arg1 == None:
                self.get_new_args(message="numb")
            con.add_line(int(self.arg1))
        elif self.todo == "addColumn":
            if self.arg1 == None:
                self.get_new_args(message="numb")
            con.add_column(int(self.arg1))
        elif self.todo == "alterChar":
            if self.arg1 == None:
                self.get_new_args(message="X")
            if self.arg2 == None:
                self.get_new_args(message="Y", arg="arg2")
            con.alter(int(self.arg2), int(self.arg1))
        elif self.todo == "alterLine":
            if self.arg1 == None:
                self.get_new_args(message="Y")
            con.alter_line(int(self.arg1))
        elif self.todo == "alterColumn":
            if self.arg1 == None:
                self.get_new_args(message="X")
            con.alter_column(int(self.arg1))
        elif self.todo == "alterOut":
            con.alter_out()
        elif self.todo == "select":
            if self.arg1 == None:
                self.get_new_args()
            con.select(self.arg1)
        elif self.todo == "save":
            if self.arg1 == None:
                self.get_new_args(message="name", var=False)
            con.save(self.arg1)
        elif self.todo == "quit":
            con.quitAll()
        elif self.todo == "repeat":
            if self.arg1 == None:
                self.get_new_args(message="numb")
            toexecute = []
            if self.arg2 == None:
                while True:
                    befehl = con.get(margin=12)
                    if not befehl == "end":
                        toexecute.append(befehl)
                    else:
                        break
            else:
                toexecute = list(self.arg2.split(";"))
            self.def_active = True
            for i in range(int(self.arg1)):
                for i in toexecute:
                    self.get_args(i)
                    self.run_command()
            self.def_active = False
        elif self.todo == "int":
            if self.arg1 == None:
                self.arg1 = con.get(margin=4, message="varname")
            if self.arg2 == None:
                self.get_new_args(message="int", arg="arg2")
            self.vars.append(self.arg1)
            self.werte.append(int(self.arg2))
        elif self.todo == "float":
            if self.arg1 == None:
                self.arg1 = con.get(margin=4, message="varname")
            if self.arg2 == None:
                self.get_new_args(message="float", arg="arg2")
            self.vars.append(self.arg1)
            self.werte.append(float(self.arg2))
        elif self.todo == "def":
            if self.arg1 == None:
                self.arg1 = con.get(margin=4, message="Name")
            befehletoappend = []
            while True:
                befehl = con.get(margin=12)
                if not befehl == "end":
                    befehletoappend.append(befehl)
                else:
                    break
            self.befehle.append(befehletoappend)
            self.definitionen.append(self.arg1)
        else:
            if self.todo in self.definitionen:
                tdlist = self.befehle[self.definitionen.index(self.todo)]
                self.def_active = True
                for i in tdlist:
                    self.get_args(i)
                    self.run_command()
                self.def_active = False
            elif self.todo in self.vars:
                if self.arg1 == "++":
                    self.werte[self.vars.index(self.todo)] += 1
                elif self.arg1 == "--":
                    self.werte[self.vars.index(self.todo)] -= 1
                elif self.arg1 == "+":
                    self.werte[self.vars.index(self.todo)] += int(self.arg2) if type(self.werte[self.vars.index(self.todo)]) == int else float(self.arg2)
                elif self.arg1 == "-":
                    self.werte[self.vars.index(self.todo)] -= int(self.arg2) if type(self.werte[self.vars.index(self.todo)]) == int else float(self.arg2)
                elif self.arg1 == "*":
                    self.werte[self.vars.index(self.todo)] *= int(self.arg2) if type(self.werte[self.vars.index(self.todo)]) == int else float(self.arg2)
                elif self.arg1 == "/":
                    self.werte[self.vars.index(self.todo)] /= int(self.arg2) if type(self.werte[self.vars.index(self.todo)]) == int else float(self.arg2)
                elif self.arg1 == "**":
                    self.werte[self.vars.index(self.todo)] **= int(self.arg2) if type(self.werte[self.vars.index(self.todo)]) == int else float(self.arg2)
                else:
                    self.alter_to_var(self.todo, var="todo")
                    self.check_operation(self.todo, var="todo")
                    print(self.todo)
            else:
                self.alter_to_var(self.todo, var="todo")
                self.check_operation(self.todo, var="todo")
                print(self.todo)
        if not self.def_active:
             active = False

import pgzrun, threading

con = console(toLoad=[" "])
gt = get("LK")

active = False

def screen_coords(x, y):
    return (x * 50, y * 50)

def real_coords(x, y):
    return (int(x/50), int(y/50))

def draw():
    global con
    width = con.width()
    height = con.height()
    level = con.level
    for y in range(height):
        for x in range(width):
            if x % 2 == y % 2:
                screen.blit("floor1", screen_coords(x, y))
            else:
                screen.blit("floor2", screen_coords(x, y))
            square = level[y][x]
            if square == "W":
                screen.blit("wall", screen_coords(x, y))
            elif square == "G":
                screen.blit("guard", screen_coords(x, y))
            elif square == "P":
                screen.blit("player", screen_coords(x, y))
            elif square == "E":
                screen.blit("energie", screen_coords(x, y))
            elif square == "S":
                screen.blit("superguard", screen_coords(x, y))
            elif square == "D":
                screen.blit("door", screen_coords(x, y))
            elif square == "K":
                screen.blit("key", screen_coords(x, y))

def update():
    global active
    if not active:
        th = threading.Thread(target=gt.get_todo)
        th.start()

pgzrun.go()
