"""
COPYRIGHT
DE: 'Büro', alle zugehörigen Pakete und Funktionen wurden von Leander Kafemann programmiert und zusammengestellt.
    Die Weiterverbreitung ist strengstens untersagt.
EN: 'Büro', all accompanying packages and functions were programmed and compiled by Leander Kafemann.
    The redistribution is forbidden strictly.
LA: 'Büro', cuncti fasces comitantes finctionesque programmati confecti et conventi sunt Leandre Kafemanne.
    Diffundum interdictum severe est.
IT: 'Büro', tutti i pachi relativi e funzioni sono stati programmati da Leander Kafemann.
    La ritrasmissione è severamente vietata.
{Ihre aktuelle Version erschien am/
 Your version was released the/
 Tua varianta singularis apparebat ad/
 La Loro versione è stata pubblicata il}
11.10.2024/XI.X.MMXXIV.
"""
#Python-Version prüfen
import sys, os
from time import sleep
import webbrowser as wb
if sys.version_info < (3, 11, 0):
    wb.open("www.python.org/downloads")
    print("Sie benötigen eine höhere Python-Version!\nEinige Features sind mit Ihrer Version eventuell nicht verfügbar.");sleep(3)
    print("\n\n\nEventuell wird Python gleich abstürzen! Es wird dringend mindestens Python 3.11 benötigt!");sleep(5)
if sys.version_info > (3, 12, 0):
    print("Büro ist für Ihre Python-Version nicht getestet.\nBitte melden Sie auftretende Fehler dem Kundenservice.")
print("Bootvorgang gestartet. Dies kann einen Moment in Anspruch nehmen.")
#Running-Check
if "running.txt" in os.listdir("./programdata/run"):
    run = input("Büro läuft bereits.\nDas erneute Ausführen kann zu erheblichen Fehlern führen.\nWie wollen Sie fortfahren?\nOptionen: Quit, Fehler beheben --> ")
    if run == "Fehler beheben":
        os.remove("./programdata/run/running.txt")
        print("Fehler erfolgreich behoben."); sleep(1.1)
        input("Sie können Büro nun schließen oder starten (Eingabe-Taste drücken).")
        open("./programdata/run/running.txt", "x").close()
    else:
        quit(code="Already running")
else:
    open("./programdata/run/running.txt", "x").close()
#preimport und notwendige Daten
import bueroUtils, pycols
bü = bueroUtils.bueroUtils()
dLg = bü.dLg
cOl = pycols.color()
COLORS_, COLORS, TCOLORS = bü.get_colors()
PACKAGES = ['colorama', 'easygui', 'eyed3', 'keyboard', 'naturalsize', 'numpy', 'pgzero', 'pillow', 'ping3', 'pyautogui', 'pycols', 'pygame', 'pyimager', 'pyperclip', 'pysounds', 'requests']
s = bü.status("Bootvorgang: ", number=45, start=3, parts=15, colors=COLORS, tcolors=TCOLORS)
s.send_message(" #Preimport getätigt");s.send_message(" #Python-Version geprüft"); s.send_message(" #Running-Daten überprüfen")
#notwendige Imports
s.send_message(" #weitere Imports abschließen")
import shutil, threading, requests
from random import choice, randint
import update
#Modulüberprüfung
s.send_message(" #Module prüfen")
bü.install_check(PACKAGES)
import pyautogui as py
import pyimager, pysounds, pyperclip, numpy, pycols
from naturalsize import *
if numpy.__version__ != "1.26.4":
    dLg.entry("numpyToNewVersion ausgelöst")
    if bü.buttonLog("Besser geeignete, evtl. aber veraltete Version von numpy installieren?") == "Fortfahren":
        os.system("py -m pip install numpy==1.26.4")
        bü.restart()
    else:
        print("Durch Ihre Entscheidung kann es zu Fehlern kommen.\nEs ist möglich, dass Büro abstürzt.")
#Initialisierung
s.send_message(" #Daten initialisieren")
antwort = ""
upgr = ["Verschlüsseler", "Haustier", "Ballonfahrt", "SchingSchangSchongIQ", "abstrakte Verzerrung", "im Verlies", "Passwortgenerator", "Musik",\
        "Garten im Glück", "Lebensmittel", "Das große Quiz", "Rechnungen", "BüroMail", "BüroBank"]
adlist = ["büro4.1.png", "bueroLogo.png", "büroMail.png"]
lklist = []#"JSLoginSpecial.lkim"]
winlist = ["z!GG11110.txt"]
PREMIUM = False; ILLEGAL = False; OFFLINE = False; AGB = True
FLAG = False; BETA = False; BETAFLAG = False
toBook = False
unterhaltung = []; werkzeuge = []; plugin = []; medien = []; lernen = []; bereiche = []
BPATH = "./programdata/buero/"
#Dateilisten für ausgewählte Pakete
imlist = ['crack1.png', 'crack2.png', 'door.png', 'energie.png', 'floor1.png', 'floor2.png',\
          'guard.png', 'key.png', 'player.png', 'superguard.png', 'wall.png']
balims = ['background.png', 'background2.png', 'balloon.png', 'balloon2.png', 'balloon_am fettesten.png', 'balloon_am kleinsten.png',\
          'balloon_antrieb.png', 'balloon_bierbauch.png', 'balloon_fett.png', 'balloon_fetter.png', 'balloon_kampf.png', 'balloon_klein.png',\
          'balloon_kleiner.png', 'balloon_lachend.png', 'balloon_leicht entzündlich.png', 'balloon_magie.png', 'balloon_schild.png',\
          'balloon_unsichtbar.png', 'bird-down.png', 'bird-up.png', 'bomb.png', 'coin.png', 'explosion.png', 'house.png', 'mystery.png',\
          'rocket.png', 'tree.png', 'ufo_ballonfahrt.png']
gigims = ['cow.png', 'cow-water.png', 'fangflower.png', 'flower.png', 'flower-wilt.png',\
          'garden.png', 'ufo.png', 'zap.png']
quizmusic = ['quiz-music.mp3']
#Button-Datenbank
konfig = ["Tools", "Informationen", "Shopping & Weiteres", "Account", "BüroOnline", "Für Dich", "Debug", "Speicherplatz", "Zurück"]
buttons = [["Update", "Upgrade", "Systemupdate", "Update herunterladen", "BETA herunterladen","Aktualisieren", "Notizen"],\
           ["VersionInfo", "UpgradeInfo", "BüroUpdateInfo", "Coming Soon", "What's new?", "BETA-Testinhalte", "Tipps"],\
           ["Anfordern", "Releases abonnieren", "Büro PREMIUM", "Gewinnspiele", "Sonderangebote", "Feedback & Funktionsvorschläge", "AGB ablehnen"],\
           ["PIN ändern", "PIN-Status ändern", "Nutzernamen ansehen", "Nutzernamen ändern", "BETA verwalten"],\
           ["DeviceID ansehen", "statische DeviceID", "DeviceID aktualisieren", "Online einloggen", "Über Büro"],\
           ["Status personalisieren", "Startmenü personalisieren", "Erfolge ansehen", "Fortschritt ansehen"],\
           ["schnelle Fehleranalyse", "Debug-Log übermitteln","PREMIUM funktioniert nicht", "PIN vergessen", "Erfolge aktualisieren", "aktuelles Log", "jedes Log"],\
           ["SpeicherInfo", "Deinstallieren", "DebugLogInfo", "Aufräumen"]]
skip = False; skip2 = False; skipagb = False; skipwin = False
get_package = ""
PLUS = []
#verfügbare Pakete prüfen
s.send_message(" #verfügbare Pakete prüfen")
files = os.listdir()
if "verschlüsseln.py" in files:
    werkzeuge.append("Verschlüsseler")
if "Haustier.py" in files:
    unterhaltung.append("Haustier")
if "Ballonfahrt.py" in files and "Ballonfahrt-M2_1.py" in files and "Ballonfahrt-M2_2.py" in files:
    unterhaltung.append("Ballonfahrt")
if "SchingSchangSchongIntelligent.py" in files:
    lernen.append("SchingSchangSchongIQ")
if "abstrakt.py" in files:
    medien.append("abstrakte Verzerrung")
if "quest.py" in files and "level-editor.py" in files:
    lernen.append("im Verlies")
if "Passwortgenerator.py" in files:
    werkzeuge.append("Passwortgenerator")
if "Musik.py" in files:
    medien.append("Musik")
if "Garten-im-Glück.py" in files:
    unterhaltung.append("Garten im Glück")
if "lebensmittel.py" in files:
    werkzeuge.append("Lebensmittel")
if "quiz.py" in files:
    lernen.append("Das große Quiz")
if "Rechnung.pyw" in files:
    werkzeuge.append("Rechnungen")
if "mail.py" in files and "mail_agent.pyw" in files:
    plugin.append("BüroMail")
if "bank.py" in files:
    plugin.append("BüroBank")
#installierte Pakete verarbeiten    
s.send_message(" #installierte Pakete verarbeiten")
installiert = werkzeuge+unterhaltung+medien+plugin+lernen
#Bereich-Listen erstellen
list_container = [werkzeuge, unterhaltung, medien, lernen, plugin]
name_container = ["Werkzeuge", "Unterhaltung", "Medien", "Lernen", "Plugins"]
for i in range(len(list_container)):
    if len(list_container[i]) > 0:
        bereiche.append(name_container[i])
#Upgrade-Liste verwalten
for i in installiert:
    upgr.remove(i)
#FF prüfen        
s.send_message(" #Feature-Flags prüfen")
try:
    if bü.web_content("https://lkunited.pythonanywhere.com/featureFlag") == "True":
        FLAG = True
except:
    OFFLINE = True; FLAG = False
    print(bü.c.bcol("RED")+"Sie sind OFFLINE."+bü.c.bcol("RESET"))
#PREMIUM prüfen    
s.send_message(" #Büro PREMIUM prüfen")
pre_check = ""; pre_z = []
if "premiumpass.txt" in files:
    if not OFFLINE:
        with open("./premiumpass.txt", "r", encoding="utf-8") as f:
            x = f.read()
        pre_check = bü.web_content("https://lkunited.pythonanywhere.com/checkerP", {"message":x, "pw":"lkunited"})
        if "True" in pre_check:
            PREMIUM = True
            pre_z = list(pre_check.split(";*;"))[1].split(":")
        else:
            ILLEGAL = True
    else:
        PREMIUM = False
#PIN lesen
s.send_message(" #Büro-PIN auslesen")
with open(BPATH+"PIN_opt.txt", "r") as PIN_opt:
    act = PIN_opt.read()
with open(BPATH+"PIN_l.txt", "r") as PIN_l:
    lenge = int(PIN_l.read())
try:
    with open(BPATH+"PIN.txt", "r") as PIN_f:
        PIN_e = PIN_f.read()
except:   
    PIN_e, lenge = bü.PIN_erstellen()
#weitere Daten lesen und aufbereiten    
s.send_message(" #weitere Daten vorbereiten und auslesen")
with open(BPATH+"log.txt", "r") as lg:
    a = lg.read()
    if a == "True":
        dLg.cancel_()
    elif a not in ["False", "True"]:
        print("Ihre DebugLog-Einstellung ist fehlerhaft. Ihre Logs bleiben daher automatisch aktiv.");sleep(3)
        print(bü.c.bcol("RED")+"Eventuell wurden Sie gehackt!"+bü.c.bcol("RESET"))
with open(BPATH+"tipps.txt", "r", encoding="utf-8") as f:
    tipps = list(f.read().split("#*#"))
with open(BPATH+"agb.txt", "r") as f:
    if f.read() == "False":
        AGB = False
with open(BPATH+"menu.txt", "r", encoding="utf-8") as f:
    for i in f.read().split("#*#"):
        if i != "":
            PLUS.append(i)
try:
    with open(BPATH+"username.txt", "r", encoding="utf-8") as f:
        USER = f.read()
except:
    USER = "RANDOM_NAME_NO_PROFILE_"+str(randint(10**4, 10**5-1))
#Erfolge initialisieren
s.send_message(" #Erfolgsdaten initialisieren")
with open(BPATH+"achievements.txt", "r", encoding="utf-8") as f:
    achievements, unlocked = f.read().split("#*#")
achievements = achievements.split(" ")
for i in range(len(achievements)):
    achievements[i] = int(achievements[i])
unlocked = unlocked.strip().split(" ")
achs = [["Paketbote"], ["Baby", "Anfänger", "Kenner", "Profi", "Experte"], ["Multitalent"], ["Millionär"], ["Entdecker"], ["Neuling", "Lernender", "Fortgeschrittener"]]; gesamt = 12
needs = [[10], [3, 10, 100, 200, 1000], [3], [True], [True], [3, 5, 10]]
texts = ["(installiere {} Pakete)", "(führe Büro {} mal aus)", "(installiere Pakete aus {} Bereichen)", "(buche PREMIUM)", "(das ist geheim)", "(schalte {} Erfolge frei)"]
targets = [len(installiert), achievements[0], len(bereiche), PREMIUM, False, len(unlocked)]
#Erfolge prüfen und verleihen
s.send_message(" #Erfolge prüfen und verleihen")
achievements[0] += 1
for i in range(len(achs)):
    for j in range(len(achs[i])):
        target = targets[i]
        if target >= needs[i][j] and achs[i][j] not in unlocked:
            unlocked.append(achs[i][j]); targets[-1] += 1
            bü.display_achievement(achs[i][j])
            print(achs[i][j], texts[i].format(str(needs[i][j])))
            pysounds.fanfare()
with open(BPATH+"achievements.txt", "w", encoding="utf-8") as f:
    for i in achievements:
        f.write(str(i)+(" " if achievements.index(i) != len(achievements)-1 else "#*#"))
    for i in unlocked:
        f.write(str(i)+" ")
#Version und DeviceID-Daten auslesen
s.send_message(" #Version auslesen und Bootvorgang abschließen")
with open(BPATH+"versioninfo.txt", "r") as versioninfo:
    version = versioninfo.read()
with open(BPATH+"deviceidstatic.txt", "r", encoding="utf-8") as f:
    devidst = True if f.read() == "True" else False
if devidst:
    with open(BPATH+"devid.txt", "r", encoding="utf-8") as f:
        DEVID = f.read()
else:
    with open(BPATH+"devid.txt", "w", encoding="utf-8") as f:
        DEVID = version.split(".")[0]+"-"+str(randint(10000, 99999))+"-"+version.split(".")[1]+"."+version.split(".")[2]
        f.write(DEVID)
#Nutzer registrieren            
if not OFFLINE:
    requests.post("https://lkunited.pythonanywhere.com/rU", {"message":USER, "pw": "lkunited", "devid": DEVID})
#BETA und BETAFLAG lesen und setzen
if not OFFLINE:
    if bü.web_content("https://lkunited.pythonanywhere.com/cB", {"message": USER, "pw": "lkunited"}) == "unregistered":
        BETA = True
BETAFLAG = FLAG and BETA
#Debug
dLg.entrys(act, lenge, PIN_e, version, bereiche, werkzeuge, unterhaltung, medien, lernen, plugin, PREMIUM, pre_check,\
           ILLEGAL, installiert, bü, AGB, COLORS_, PLUS, unlocked, achievements, OFFLINE, USER, DEVID, devidst,\
           pyimager.about(), about(), pycols.about(), pysounds.about(), FLAG, pre_z, upgr, BETA, BETAFLAG)
dLg.presave_log()
#variable Nachricht
try:
    if OFFLINE:
        bcolb = ""
        quit(code="exc")
    a = bü.web_content("https://lkunited.pythonanywhere.com/bueroMessage")
    bcol = cOl.bcol(a.split("%%")[0].lstrip('bcol-')) if "%%" in a else ""
    b = a.split("%%")[1]+cOl.RESET_ALL if "%%" in a else a
    bcolb = bcol + b
except:
    OFFLINE = True
    dLg.entry("Offline Mode")
print(bcolb); dLg.entry(bcolb)
#Specials
for i in os.listdir("./programdata/lkims"):
     pyimager.display("./programdata/lkims/"+i)
     print(i[0:-5])
#Menü
while True:
    try:
        if not PREMIUM:
            dLg.entry("Loading ad...")
            for i in range(1 if not ILLEGAL else 3):
                bü.getad(choice(os.listdir("./programdata/ads")), end="")
            if ILLEGAL:
                if bü.buttonLog("SIE SIND ILLEGAL! FAHREN SIE FORT ODER LÖSCHEN SIE IHREN PREMIUM-PASS.", "ILLEGAL", buttons=("LÖSCHEN", "WEITER")) == "LÖSCHEN":
                    os.remove("./premiumpass.txt");bü.restart()
        if "PRE" in version:
            if bü.buttonLog("Sie haben eine BETA-Version. Wollen Sie jetzt Feedback geben?", "BETA", buttons=("JA", "NEIN")) == "JA":
                feedback = py.prompt("BETA-Feedback eingeben:", "BETA-Feedback")
                if feedback != None:
                    wb.open("mailto:leander@kafemann.berlin?subject=BETA-Test&body="+feedback)
                    dLg.entrys("Following feedback entered:", feedback)
        dLg.presave_log()
        ## Platz für ANNOUNCEMENTS
        ## py.alert("Bitte beachten Sie, dass Sie in naher Zukunft nur noch über BüroMail an Gewinnspielen teilnehmen werden können.", "BüroMail")
        ## print("Es dürfen hier auch Aktionen ausgeführt werden")
        dLg.presave_log()
    except IndexError:
        dLg.entry("NO ADS!!")
    except:
        dLg.entry("Error loading ad / sending beta feedback")
    finally:
        while True:
            if antwort == "TEST":
                antwort = "NOTEST"
                break
            dLg.entry("Main Menu");dLg.presave_log()
            discover = randint(1, 77) if "Entdecker" not in unlocked else 0; dLg.entry(discover)
            if not skipwin:
                antwort = py.confirm("Welches unserer Programme wollen Sie nutzen?", "Büro V" + version, buttons=bereiche+PLUS+(["KLICK ME"] if discover == 1 else [])+["Konfigurieren", "Quit"])
            dLg.entry(antwort)
            if not skip2 and not skipwin:
                if antwort in bereiche+["KLICK ME"]:
                    target = ["Erfolg freischalten"]
                    if antwort in name_container:
                        target = list_container[name_container.index(antwort)].copy()
                    antwort = py.confirm("Welches unserer Programme wollen Sie nutzen?", antwort, buttons=(target+["Zurück"]))
            else:
                skip2 = False
            dLg.entry(antwort)
            if antwort == "Erfolg freischalten":
                unlocked.append("Entdecker"); bü.display_achievement("Entdecker"); print(achs[-2][0], texts[-2])
                pysounds.fanfare()
                with open(BPATH+"achievements.txt", "a") as f:
                    f.write("Entdecker ")
            elif antwort == "Verschlüsseler":
                os.system("py ./verschlüsseln.py")
            elif antwort == "Passwortgenerator":
                os.system("py ./Passwortgenerator.py")
            elif antwort == "Musik":
                os.system("py ./Musik.py")
            elif antwort == "Lebensmittel":
                os.system("py ./lebensmittel.py")
            elif antwort == "Rechnungen":
                os.system("py ./Rechnung.pyw")
            elif antwort == "Haustier":
                os.system("py ./Haustier.py")
            elif antwort == "Das große Quiz":
                os.system("py ./quiz.py")
            elif antwort == "Ballonfahrt":
                antwort2 = bü.buttonLog("Single- oder Multiplayer?", "Ballonfahrt", buttons=("Single", "Multi", "Zurück"))
                match antwort2:
                    case "Single":
                        os.system("python ./Ballonfahrt.py")
                    case "Multi":
                        antwort3 = bü.buttonLog("Wollen Sie die Verbindung im lokalen Netzwerk herstellen oder verbunden werden?", "Ballonfahrt-2P", buttons=("Aktiv", "Passiv"))
                        dLg.entry(antwort3)
                        if antwort3 == "Aktiv":
                            os.system("py ./Ballonfahrt-M2_1.py")
                        elif antwort3 == "Passiv":
                            os.system("py ./Ballonfahrt-M2_2.py")
                    case "Zurück":
                        continue
                    case _:
                        bü.error_quit()
            elif antwort == "im Verlies":
                antwort2 = bü.buttonLog("Wählen Sie eine der folgenden Optionen:", "im Verlies",\
                                        buttons=("im Verlies", "im Verlies - Level-editor", "Zurück"))
                match antwort2:
                    case "im Verlies":
                        os.system("py ./quest.py")
                    case "im Verlies - Level-editor":
                        os.system("py ./level-editor.py")
                    case "Zurück":
                        continue
                    case _:
                        bü.error_quit()
            elif antwort == "SchingSchangSchongIQ":
                os.system("py ./SchingSchangSchongIntelligent.py")
            elif antwort == "Garten im Glück":
                os.system("py ./Garten-im-Glück.py")
            elif antwort == "abstrakte Verzerrung":
                os.system("py ./abstrakt.py")
            elif antwort == "BüroMail":
                if not skipwin:
                    antwort5 = bü.buttonLog("Wollen Sie mit dem Hauptprogramm Mails lesen/senden oder den BackgroundAgent aktivieren,\num Ihren Posteingang im Hintergrund überprüfen zu lassen?",\
                                            "BüroMail", ("BüroMail", "BackgroundAgent", "Zurück"))
                else:
                    skipwin = False
                    antwort5 = "BüroMail"
                    dLg.entrys(antwort5, "called via skipwin mode")
                    py.alert("BüroMail wird gestartet, um am Gewinnspiel teilzunehmen.", "BüroMail")
                if antwort5 == "BüroMail":
                    if bü.PIN_check(PIN_e, lenge, act):
                        os.system("py ./mail.py")
                elif antwort5 == "BackgroundAgent":
                    def a():
                        os.system("py ./mail_agent.pyw")
                    threading.Thread(target=a).start()
            elif antwort == "BüroBank":
                os.system("py ./bank.py")
            elif antwort == "Konfigurieren":
                if not AGB:
                    if py.confirm("Sie haben unseren Nutzungsbedingungen nicht zugestimmt. Stimmen Sie zu?", "AGB", buttons=("JA", "NEIN")) == "JA":
                        with open(BPATH+"agb.txt", "w") as f:
                            f.write("True")
                        AGB = True
                    else:
                        continue
                while True:
                    if not skipagb and not skipwin:
                        antwort2 = py.confirm("Mit welchem der folgenden Bereiche wollen Sie fortfahren?", "Konfiguration", buttons=konfig)
                        dLg.entry(antwort2)
                    else:
                        skipagb = False
                    if antwort2 != "Zurück":
                        while True:
                            if not skip and not skipwin:
                                antwort3 = py.confirm("Welche der Optionen wollen Sie nutzen?", antwort2, buttons=buttons[konfig.index(antwort2)]+["Zurück"])
                            else:
                                skip = False
                            dLg.entry(antwort3); dLg.presave_log()
                            if antwort3 == "Update":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    try:
                                        update.update()
                                    except:
                                        dLg.entry("Fehler bei Updatevorgang")
                                        bü.error_quit()
                            elif antwort3 == "Upgrade":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    try:
                                        update.update(alter="Upgrade")
                                    except:
                                        dLg.entry("Fehler bei Upgradevorgang")
                                        bü.error_quit()
                            elif antwort3 == "Systemupdate":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    try:
                                        os.system("python ./systemupdate.py")
                                    finally:
                                        skip = True; antwort3 = "Aktualisieren"; print("Aktualisierung gestartet...")
                            elif antwort3 == "Aktualisieren":
                                bü.updates([""]+PACKAGES)
                                print("Pakete aktualisiert...")
                                for i in os.listdir("./programdata/ads"):
                                    if i not in adlist:
                                        os.remove("./programdata/ads/" + i)
                                print("Anzeigen aktualisiert...")
                                for i in os.listdir("./programdata/win"):
                                    if i not in winlist:
                                        os.remove("./programdata/win/"+i)
                                print("Gewinnspiele aktualisiert...")
                                for i in os.listdir("./programdata/lkims"):
                                    if i not in lklist:
                                        os.remove("./programdata/lkims/"+i)
                                print("Specials aktualisiert...\nVorgang abschließen...")
                                bü.restart()
                            elif antwort3 == "Update herunterladen":
                                if FLAG:
                                    if bü.web_update("https://lkunited.pythonanywhere.com/bueroVersion"):
                                        if bü.buttonLog("Wollen Sie das Update nun installieren?", "Update", ("JA", "NEIN")) == "JA":
                                            skip = True; antwort3 = "Update"
                                else:
                                    py.alert("Diese Funktion ist momentan nicht verfügbar.", "FF down")
                            elif antwort3 == "Notizen":
                                try:
                                    with open(BPATH+"notizen.txt", "r") as f:
                                        notizen = f.read()
                                except:
                                    with open(BPATH+"notizen.txt", "x") as f:
                                        f.write("")
                                    notizen = ""
                                finally:
                                    notizen_ = py.prompt("Notizen eingeben", "Notizen", notizen)
                                    if notizen_ == None:
                                        notizen_ = notizen
                                    with open(BPATH+"notizen.txt", "w") as f:
                                        f.write(notizen_)
                            elif antwort3 == "BETA herunterladen":
                                if BETA:
                                    if FLAG:
                                        if bü.web_update("https://lkunited.pythonanywhere.com/betaVersion", username=USER):
                                            if bü.buttonLog("Wollen Sie das Update nun installieren?", "BETA-Update", ("JA", "NEIN")) == "JA":
                                                skip = True; antwort3 = "Update"
                                    else:
                                        py.alert("Diese Funktion ist momentan nicht verfügbar.", "FF down")
                                else:
                                    py.alert("Sie sind nicht Teil des BETA-Programms!", "kein BETA-Nutzer")
                                    dLg.entry("kein BETA")
                            elif antwort3 == "VersionInfo":
                                alerttext = "Sie haben folgende Versionen:\nBüro: " + version + "\n"
                                for i in installiert+["System"]:
                                    filename = BPATH+"versioninfo_" + i + ".txt"
                                    with open(filename, "r") as r:
                                        read = r.read()
                                    alerttext += i + ": " + read + "\n"
                                py.alert(alerttext, "VersionInfo")
                            elif antwort3 == "UpgradeInfo":
                                alerttext = "Sie können folgende Pakete anfordern (und mit der Upgrade-Funktion installieren):\n"
                                for i in upgr:
                                    alerttext = alerttext + i + "\n"
                                if upgr == []:
                                    py.alert("Keine Aktualisierungen vorhanden.", "UpgradeInfo")
                                else:
                                    antwort4 = bü.buttonLog(alerttext, "UpgradeInfo", ("Jetzt anfordern", "Jetzt installieren", "Zurück"))
                                    if antwort4 == "Jetzt installieren":
                                            skip = True; antwort2 = "Tools"; antwort3 = "Upgrade"
                                    elif antwort4 == "Jetzt anfordern":
                                            skip = True; antwort2 = "Shopping & Weiteres"; antwort3 = "Anfordern"
                            elif antwort3 == "BüroUpdateInfo":
                                if not OFFLINE:
                                    v_a = bü.web_content("https://lkunited.pythonanywhere.com/bueroVersion").split("#**"+"*#")[0]
                                    v_b_a = bü.web_content("https://lkunited.pythonanywhere.com/betaVersion", {"pw": "lkunited", "message": USER}).split("#**"+"*#")[0]
                                    if v_a == version:
                                        py.alert("Sie sind auf dem neuesten Stand.\nDie neueste BETA-Version ist: "+v_b_a, "BüroUpdateInfo")
                                    else:
                                        antwort4 = bü.buttonLog("Ihre Version: "+version+"\naktuellste Version: "+v_a+"\naktuellste BETA: "+v_b_a, "BüroUpdateInfo", ("Zurück", "Jetzt aktualisieren", "Jetzt anfordern", "Jetzt herunterladen"))
                                        if antwort4 == "Jetzt aktualisieren":
                                            skip = True; antwort2 = "Tools"; antwort3 = "Update"
                                        elif antwort4 == "Jetzt anfordern":
                                            skip = True; antwort2 = "Shopping & Weiteres"; antwort3 = "Anfordern"; get_package = "Büro, "+v_a
                                        elif antwort4 == "Jetzt herunterladen":
                                            skip = True; antwort2 = "Tools"; antwort3 = "Update herunterladen"
                                else:
                                    py.alert("Sie sind offline.", "Netzwerkfehler")
                            elif antwort3 == "Coming Soon":
                                up_list = ["im Verlies - levelEditor EasyMode", "Haustier - Börse2"];addtext = ""
                                for i in up_list:
                                    addtext += "\n+" + i
                                neu_list = ["Flappy Bird", "LK-Foto ALPHA", "Verschlüsseln 7*"];addtext2 = ""
                                for i in neu_list:
                                    addtext2 += "++" + i + "\n"
                                py.alert("Folgende Pakete werden bald erscheinen:\n"+addtext2+"Folgende wichtige Updates sind geplant:"+addtext, "Coming Soon")
                            elif antwort3 == "What's new?":
                                py.alert("Neu:\n-(Speicher- und) Effizienzverbesserungen\n-Verbesserungen bei einigen Funktionen\n-Aktualisierung von Inhalten\n-Bugfix\n-HIER KÖNNTE IHR FUNKTIONSVORSCHLAG STEHEN!\n-Vorbereitung auf V4.1\n-diverse kleinere Verbesserungen"+\
                                         "\n-verbesserter Bootvorgang\n-verbessertes Starten von Paketen\n-verbessertes BETA"+\
                                         "\n-verbesserter OFFLINE-Modus", "What's new?")
                            elif antwort3 == "BETA-Testinhalte":
                                if BETA:
                                    beta = ["Dies ist eine Vollversion.\nEs gibt keine BETA-Testinhalte.",\
                                            ""]
                                    py.alert(beta[0], "BETA-Inhalte")
                                else:
                                    py.alert("Sie müssen für diese Aktion Teil des BETA-Programms sein.", "BETA erforderlich")
                            elif antwort3 == "Tipps":
                                antwort4 = "Noch ein Tipp"
                                while antwort4 == "Noch ein Tipp":
                                    antwort4 = bü.buttonLog(choice(tipps), "Tipp", ("Noch ein Tipp", "Zurück"))
                            elif antwort3 == "Anfordern":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    anfordern = py.prompt("{Paket}, {Version} anfordern", "Anfordern", get_package)
                                    if anfordern != None:
                                        bü.createPreMail("The Creator", "Anfordern", f"Ich möchte hiermit {anfordern} anfordern.")
                                        get_package = ""
                                        antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                            elif antwort3 == "Releases abonnieren":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    bü.createPreMail("The Creator", "Abo", "Ich möchte alle erscheinenden Versionen von Büro kostenlos zugesandt bekommen und bin mit den Bedingungen einverstanden.")
                                    antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                            elif antwort3 == "Büro PREMIUM":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    if PREMIUM:
                                        antwort4 = bü.buttonLog(f"Sie haben Büro PREMIUM bis {pre_z} (Jahr, Monat) gebucht.", "PREMIUM vorhanden", ("Zurück", "PREMIUM verlängern", "PREMIUM erneuern"))
                                        if antwort4 == "PREMIUM verlängern":
                                            monat = py.prompt("Um wie viele Monate wollen Sie Büro PREMIUM verlängern?\nKosten: 1,59 € pro Monat", "PREMIUM verlängern")
                                            if monat != None:
                                                monat = int(monat)
                                                new_date = [0, 0];preis = 0;new_year = int(pre_z[0])
                                                if monat > 0:
                                                    while monat > (12 - int(pre_z[1])):
                                                        new_year += 1
                                                        preis += 12 * 1.59
                                                        monat -= (12 - int(z[1]))
                                                    new_date = [str(new_year), str(int(pre_z[1])+monat)]
                                                    preis += monat * 1.59
                                                    bü.createPreMail("The Creator", "Büro PREMIUM verlängern", f"Ich möchte Büro PREMIUM verbindlich für {preis}€ bis {new_date} verlängern.")
                                                    antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                                                else:
                                                    py.alert("Fehlerhafte Eingabe!", "Fehler")
                                            else:
                                                py.alert("Vorgang abgebrochen!", "Abbruch")
                                        elif antwort4 == "PREMIUM erneuern":
                                            toBook = True
                                    else:
                                        antwort4 = bü.buttonLog("Büro PREMIUM für 1,59€ für diesen Monat buchen oder Gutscheincode nutzen?", "PREMIUM nicht vorhanden", ("Buchen", "Gutschein", "Zurück"))
                                        if antwort4 == "Buchen":
                                            bü.createPreMail("The Creator", "Büro Premium buchen", "Ich möchte für 1.59€ Büro Premium verbindlich für diesen Monat kaufen.")
                                            antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                                        elif antwort4 == "Gutschein":
                                            toBook = True
                                    if toBook and bü.buttonLog("Die PREMIUM-Buchung wird initiiert.\nBitte bestätigen:") == "Fortfahren":
                                        toBook = False
                                        if not OFFLINE:
                                            if bü.buttonLog("Wollen Sie einen Gutscheincode oder einen Pass angeben?", "Code", ("Gutscheincode", "Pass")) == "Gutscheincode":
                                                a = bü.web_content("https://lkunited.pythonanywhere.com/checkerC", {"message": py.prompt("Gutscheincode eingeben:", "Code"), "pw": "lkunited"})
                                            else:
                                                a = py.prompt("Pass eingeben:", "Pass")
                                            if a != "INCORRECT" and a != "FALSE":
                                                py.alert(f"Ihr ermittelter Pass:\n{a}", "Gutscheincode eingelöst")
                                                a = a.format(py.prompt("Geben Sie Ihren Namen ein, um den Pass zu vervollständigen.", "Name", USER)); dLg.entry(a)
                                                with open("./premiumpass.txt", "w", encoding="utf-8") as f:
                                                    f.write(a)
                                                bü.restart()
                                            else:
                                                py.alert(a, "Error")
                                        else:
                                            py.alert("Sie sind offline", "Netzwerkfehler")
                            elif antwort3 == "Gewinnspiele":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    while True:
                                        games = os.listdir("./programdata/win"); dLg.entry(games)
                                        for i in range(len(games)):
                                            games[i] = games[i].rstrip(".txt")
                                        game = bü.buttonLog("Welches der installierten Gewinnspiele wollen Sie wählen?\n"+\
                                                          "Neue Gewinnspiele werden bei Updates automatisch hinzugefügt oder können mit der Fehleranalyse eingespielt werden.", "Gewinnspiele", games+["Zurück"])
                                        if game != "Zurück":
                                            with open("./programdata/win/"+game+".txt", "r", encoding="utf-8") as gdata:
                                                toWin, maxTime, addInf = gdata.read().split("#**#")
                                            antwort4 = bü.buttonLog(f"Informationen zu gewähltem Gewinnspiel:\nmögliche Gewinne: {toWin}\nDeadline: {maxTime}\nandere Informationen: {addInf}", "Gewinnspiel", ("Teilnehmen", "Löschen", "Zurück"))
                                            if antwort4 == "Teilnehmen":
                                                if not "BüroMail" in installiert:
                                                    py.alert("Sie benötigen BüroMail zur Teilnahme!", "Fehler")
                                                else:
                                                    bü.createPreMail("The Creator", "Gewinnspiel", "Ich möchte am aktuellen Gewinnspiel teilnehmen."+\
                                                                     "Der Verifikationscode lautet {}. Meine Daten sind {}.".format(game, str(version)+";"+(str(pre_z) if PREMIUM else "kein PREMIUM")))
                                                    py.alert("Öffnen Sie BüroMail, um teilzunehmen.\nBitte beachten Sie, dass Sie bei mehreren Gewinnspielen nur hintereinander teilnehmen können.")
                                                    antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                                            elif antwort4 == "Löschen":
                                                os.remove("./programdata/win/"+game+".txt")
                                        else:
                                            break
                            elif  antwort3 == "Sonderangebote":
                                py.alert("Folgende Sonderangebote sind aktiv:"+\
                                         "\n-3*PREMIUM für 0,24€+8*Funktionsvorschlag (bis 30.09.24)", "Sonderangebote")
                            elif antwort3 == "Feedback & Funktionsvorschläge":
                                bü.createPreMail("The Creator", "Feedback/neue Funktion", py.prompt("Feedback/Funktionsvorschläge eingeben", "Feedback"))
                                antwort3 = "Zurück"; antwort2 = "Zurück"; antwort = "BüroMail"; skipwin = True; break
                            elif antwort3 == "AGB ablehnen":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    if bü.buttonLog("Wirklich ablehnen? Sie werden nicht mehr auf die Einstellungen zugreifen können.") == "Fortfahren":
                                        dLg.entry("AGB ablehnend...")
                                        with open(BPATH+"agb.txt", "w") as f:
                                            f.write("False")
                                        AGB = False; antwort2 = "Zurück"; skipagb = True; break
                            elif antwort3 == "PIN ändern":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    PIN_e, lenge = bü.PIN_erstellen(PIN_e, lenge)
                            elif antwort3 == "PIN-Status ändern":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    with open(BPATH+"PIN_opt.txt", "r") as pin_opt:
                                        akt = pin_opt.read()
                                    if akt == "True":
                                        antwort4 = bü.buttonLog("PIN deaktivieren?", "PIN aktiv", ("JA", "NEIN"))
                                        if antwort4 == "JA":
                                            with open(BPATH+"PIN_opt.txt", "w") as pin_opt:
                                                pin_opt.write("False")
                                            act = "False"
                                    elif akt == "False":
                                        antwort4 = bü.buttonLog("PIN aktivieren?", "PIN inaktiv", ("JA", "NEIN"))
                                        if antwort4 == "JA":
                                            with open(BPATH+"PIN_opt.txt", "w") as pin_opt:
                                                pin_opt.write("True")
                                            os.remove(BPATH+"PIN.txt")
                                            py.alert("Ihre PIN wurde zurückgesetzt.", "PIN aktiviert")
                                            bü.restart()
                                    else:
                                       print(bü.c.bcol("RED")+"Einige Daten sind fehlerhaft.\nEventuell wurden Sie gehackt."+bü.c.bcol("RESET"))
                            elif antwort3 == "Nutzernamen ändern":
                                if bü.PIN_check(PIN_e, lenge, act) and not OFFLINE and bü.buttonLog("Bitte beachten Sie,\ndass dies alle auf Ihren Nutzernamen gespeicherten Daten löscht.") == "Fortfahren":
                                    old_user = USER; try_user = old_user
                                    while try_user == old_user or bü.web_content("https://lkunited.pythonanywhere.com/cN", {"message": try_user, "pw": "lkunited"}) != "valid":
                                        try_user = py.prompt("Neuen Nutzernamen eingeben:\nHinweis: der Name darf nicht bereits existieren.", "Nutzernamen ändern", try_user)
                                        if try_user == None:
                                            break
                                    if try_user != None:
                                        USER = try_user
                                        with open(BPATH+"username.txt", "w", encoding="utf-8") as f:
                                            f.write(USER)
                                        if BETA:
                                            requests.post("https://lkunited.pythonanywhere.com/rB", {"message": "-"+old_user, "pw": "lkunited"})
                                            requests.post("https://lkunited.pythonanywhere.com/rB", {"message": USER, "pw": "lkunited"})
                                        requests.post("https://lkunited.pythonanywhere.com/rU", {"message": "-"+old_user, "pw": "lkunited"})
                                        requests.post("https://lkunited.pythonanywhere.com/rU", {"message": USER, "pw": "lkunited"})
                                        py.alert("Neuen Nutzernamen erfolgreich registriert.", "Nutzernamen ändern")
                                    else:
                                        py.alert("Sie haben den Vorgang abgebrochen.", "Vorgang abgebrochen")
                            elif antwort3 == "Nutzernamen ansehen":
                                if bü.buttonLog("Ihr Nutzername ist: "+USER, "Nutzernamen ansehen", ("Zurück", "Jetzt ändern")) == "Jetzt ändern":
                                    skip = True; antwort3 = "Nutzernamen ändern"
                            elif antwort3 == "BETA verwalten":
                                if bü.PIN_check(PIN_e, lenge, act) and not OFFLINE:
                                    if not BETA:
                                        if bü.buttonLog("Sie sind noch nicht für BETA angemeldet.\nJetzt anmelden?", "BETA-Anmeldung", buttons=("JA", "NEIN")) == "JA":
                                            if bü.buttonLog("Stimmen Sie unseren BETA-AGB zu?\nDiese schließen jegliche Haftung unsererseits aus und\nhalten Sie dazu an, BETA-Feedback einzureichen.", "BETA-AGB", ("JA", "NEIN")) == "JA":
                                                requests.post("https://lkunited.pythonanywhere.com/rB", {"message": USER, "pw": "lkunited"})
                                                py.alert("Erfolgreich für BETA angemeldet.", "BETA-Anmeldung")
                                                BETA = True; BETAFLAG = BETA and FLAG
                                    else:
                                        if bü.buttonLog("Sie sind bereits für BETA angemeldet.\nVon BETA abmelden?", "BETA-Anmeldung", buttons=("JA", "NEIN")) == "JA":
                                            requests.post("https://lkunited.pythonanywhere.com/rB", {"message": "-"+USER, "pw": "lkunited"})
                                            py.alert("Erfolgreich von BETA abgemeldet.", "BETA-Anmeldung")
                                            BETA = False; BETAFLAG = False
                                else:
                                    py.alert("Die Authentifizierung ist fehlgeschlagen.\nBitte beachten Sie, dass Sie hierfür Internet benötigen.", "Fehler")
                            elif antwort3 == "DeviceID ansehen":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    if bü.buttonLog("Ihre DeviceID lautet:\n"+DEVID, "DeviceID ansehen", buttons=("Kopieren", "Zurück")) == "Kopieren":
                                        pyperclip.copy(DEVID)
                            elif antwort3 == "Online einloggen":
                                match bü.buttonLog("Wollen Sie das Login nur öffnen oder auch einen Code generieren?", "Login", ("Code generieren", "Nur Login", "Zurück")):
                                    case "Code generieren":
                                        if bü.PIN_check(PIN_e, lenge, act) and not OFFLINE:
                                            code_ = bü.web_content("https://lkunited.pythonanywhere.com/getCode", {"username": USER,\
                                                                   "id": "True" if bü.web_content("https://lkunited.pythonanywhere.com/cB", {"message": USER, "pw": "lkunited"}) == "registered" else "False", "devid": DEVID, "password": "lkunited"})
                                            match bü.buttonLog("Ihr Code lautet:\n"+code_, "Bestätigungscode", buttons=("Einloggen", "Kopieren", "Zurück")):
                                                case "Kopieren":
                                                    pyperclip.copy(code_)
                                                case "Einloggen":
                                                    wb.open(f"https://lkunited.pythonanywhere.com/menu?counter=0&name={USER}&code={code_}")
                                        else:
                                            py.alert("Sie benötigen Ihre PIN und eine Internetverbingung zum Online-Login!", "Fehler")
                                    case "Nur Login":
                                        wb.open("https://lkunited.pythonanywhere.com/login")
                                    case "Zurück":
                                        continue
                                    case _:
                                        bü.error_quit()
                            elif antwort3 == "Über Büro":
                                wb.open("https://lkunited.pythonanywhere.com/aboutBuero")
                            elif antwort3 == "statische DeviceID":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    if bü.buttonLog("Sie haben {}eine statische DeviceID.\nWollen Sie das ändern?\nHinweise:\nDie statische ID macht das Login für Sie zwar einfacher, aber auch unsicherer.\n".format("" if devidst else "k")+\
                                                    "Falls Sie eine statische DeviceID haben, sollten Sie diese regelmäßig auf die neueste Version aktualisieren.","statische DeviceID", buttons=("Ja", "Nein")) == "Ja":
                                        devidst = reverse(devidst)
                                        with open(BPATH+"deviceidstatic.txt", "w", encoding="utf-8") as f:
                                            f.write(str(devidst))
                            elif antwort3 == "DeviceID aktualisieren":
                                if not OFFLINE:
                                    if bü.PIN_check(PIN_e, lenge, act):
                                        devidold = DEVID
                                        DEVID = version.split(".")[0]+"-"+devidold.split("-")[1]+"-"+version.split(".")[1]+"."+version.split(".")[2]
                                        with open(BPATH+"devid.txt", "w", encoding="utf-8") as f:
                                            f.write(DEVID)
                                        requests.post("https://lkunited.pythonanywhere.com/rU", {"message":USER, "pw": "lkunited", "devid": DEVID})
                                        py.alert(f"DeviceID erfolgreich aktualisiert.\nAlte DeviceID: {devidold}\nNeue DeviceID: {DEVID}", "DeviceID aktualisiert")
                                else:
                                    py.alert("Für diese Aktion benötigen Sie eine Internetverbindung.", "OFFLINE")
                            elif antwort3 == "Status personalisieren":
                                x = []
                                for i in range(5):
                                    match i:
                                        case 0:
                                            use = "Diese Farbe wird für den Namen des Vorgangs und den Status der SpeicherInfo verwendet."
                                        case 1:
                                            use = "Diese Farbe wird für den aktuellen Vorgang bei allen Statusbalken verwendet."
                                        case _:
                                            use = "Diese Farbe wird für Statusbalken sowie Ampelfunktionen (z.B. SpeicherInfo) verwendet."
                                    y = py.prompt("Wählen Sie die "+bü.numeral(i+1, sex="f")+" Farbe.\n"+use, "Personalisieren", COLORS_[i])
                                    try:
                                        cOl.col(y);x.append(y)
                                    except:
                                        x.append("WHITE")
                                with open(BPATH+"color.txt", "w") as f:
                                    for i in x:
                                        f.write(i+"#*#")
                                COLORS_ = x.copy();COLORS = COLORS_[0:2];TCOLORS = COLORS_[2:5]
                            elif antwort3 == "Startmenü personalisieren":
                                x = []
                                for i in range(3):
                                    z = PLUS[i] if len(PLUS) > i else ""
                                    a = py.prompt("Fügen Sie bis zu drei personalisierte Optionen zum Hauptmenü hinzu.", "Menü personalisieren", z)
                                    while a not in installiert:
                                        py.alert("Fehler!\nSie müssen die entsprechenden Pakete bereits installiert haben!\nVersuchen Sie es erneut.", "Fehler")
                                        a = py.prompt("Fügen Sie bis zu drei personalisierte Optionen zum Hauptmenü hinzu.", "Menü personalisieren", z)
                                    x.append(a)
                                PLUS = x.copy()
                                with open(BPATH+"menu.txt","w", encoding="utf-8") as f:
                                    for i in PLUS:
                                        f.write(i+"#*#")
                                bü.restart()
                            elif antwort3 == "Erfolge ansehen":
                                for i in unlocked:
                                    bü.display_achievement(i)
                                    for j in range(len(achs)):
                                        if i in achs[j]:
                                            target = j; tgt2 = achs[j].index(i)
                                    print(i, texts[target].format(str(needs[target][tgt2]))); sleep(1.2)
                                if len(unlocked) == 0:
                                    print("Sie haben noch keine Erfolge freigeschaltet.")
                            elif antwort3 == "Fortschritt ansehen":
                                for i in range(len(achs)):
                                    for j in range(len(achs[i])):
                                        if achs[i][j] not in unlocked:
                                            bü.display_achievement("Hidden")
                                            print(achs[i][j], texts[i].format(str(needs[i][j]))); sleep(1.2)
                                            init_values = bü.round_agent(int(targets[i]), int(needs[i][j]))
                                            s = bü.status("Fortschritt: ", init_values[1], init_values[0], "+", colors=COLORS, tcolors=TCOLORS)
                                            s.send_message(" "+str(targets[i])+" von "+str(needs[i][j]))
                                if len(unlocked) == gesamt:
                                    print("Sie haben bereits alle Erfolge freigeschaltet.")
                            elif antwort3 == "schnelle Fehleranalyse":
                                try:
                                    os.system("python ./fehleranalyse.py")
                                except:
                                    print("Etwas ist schiefgelaufen...")
                            elif antwort3 == "PREMIUM funktioniert nicht":
                                anl = bü.buttonLog("Eventuell wurde Ihnen bereits ein neuer PREMIUM-Pass zugesandt.")
                                if anl == "JA":
                                    wb.open("mailto:leander@kafemann.berlin?subject=PREMIUM disfunktional&body==Mein gültiger PREMIUM-Pass funktioniert nicht.")
                                    py.alert("Bitte hängen Sie Ihren PREMIUM-Pass an.", "PREMIUM funktioniert nicht")
                            elif antwort3 in ["Debug-Log übermitteln", "PIN vergessen", "Erfolge aktualisieren"]:
                                py.alert("Bitte nutzen Sie die Option in der schnellen Fehleranalyse.")
                            elif antwort3 == "aktuelles Log":
                                if bü.buttonLog("Wollen Sie das aktuelle Log {}?".format("aktivieren" if dLg.canceled else "deaktivieren"), "Log konfigurieren", ("JA", "NEIN")) == "JA":
                                    dLg.cancel_()
                            elif antwort3 == "jedes Log":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    with open(BPATH+"log.txt", "r") as lg:
                                        lg_a = lg.read()
                                    if bü.buttonLog("Wollen Sie jedes Log {}?".format("aktivieren" if lg_a == "True" else "deaktivieren"), "Logs konfigurieren", ("JA", "NEIN")) == "JA":
                                        if str(dLg.canceled) == lg_a:
                                            dLg.cancel_()
                                        with open(BPATH+"log.txt", "w") as lg:
                                            lg.write(str(dLg.canceled))
                            elif antwort3 == "SpeicherInfo":
                                st = bü.status("SpeicherInfo: ", parts=len(installiert)+5, fill="~", colors=COLORS)
                                x = 5*"-";at = "Folgender Speicherplatz wird von den einzelnen Paketen belegt:\nBeispiel: {} Größe {} ( Programme - / Daten {} / Bilder {} / Audio {} )".format(14*"-", x, x, 4*"-", x)
                                in2 = installiert.copy();in2 += ["Events", "Büro", "System", "Hintergrundsystem", "gesamt"]
                                ges5 = [];ges6 = [];ges7 = [];ges8 = [];ges9 = []
                                st.init_one_bar()
                                for i in in2:
                                    ges1 = 0;ges2 = 0;ges3 = 0;ges4 = 0
                                    st.draw_one_bar()
                                    if i == "Verschlüsseler":
                                        ges3 = bü.get_size("./shopping/images")
                                        ges1 = bü.get_sizes(["./verschlüsseln.py", "./shopping"]) - ges3                                   
                                        ges2 = bü.get_size("./programdata/verschlüsseln")
                                    elif i == "Haustier":
                                        ges1 = bü.get_size("./Haustier.py")
                                        ges2 = bü.get_sizes(["./programdata/haustier/saved", "./programdata/haustier/aktien"])
                                        ges4 = bü.get_size("./programdata/haustier/music")
                                    elif i == "Ballonfahrt":
                                        ges1 = bü.get_sizes(["./Ballonfahrt.py", "./Ballonfahrt-M2_1.py", "./Ballonfahrt-M2_2.py"])
                                        ges2 = bü.get_size("./programdata/ballonfahrt")
                                        ges3 = bü.get_sizes(balims, prepath="./images/")
                                    elif i == "SchingSchangSchongIQ":
                                        ges1 = bü.get_size("./SchingSchangSchongIntelligent.py")
                                        ges2 = bü.get_size("./programdata/schingschangschongiq")
                                    elif i == "abstrakte Verzerrung":
                                        ges1 = bü.get_size("./abstrakt.py")
                                        ges3 = bü.get_size("./programdata/abstrakt")
                                    elif i == "im Verlies":
                                        ges1 = bü.get_sizes(["./quest.py", "./level-editor.py"])
                                        ges2 = bü.get_size("./programdata/verlies")
                                        ges3 = bü.get_sizes(imlist, prepath="./images/")
                                    elif i == "Passwortgenerator":
                                        ges1 = bü.get_size("./Passwortgenerator.py")
                                        ges2 = bü.get_size("./programdata/password")
                                    elif i == "Musik":
                                        ges1 = bü.get_size("./Musik.py")
                                        ges2 = bü.get_size("./programdata/music")
                                    elif i == "Garten im Glück":
                                        ges1 = bü.get_size("./Garten-im-Glück.py")
                                        ges3 = bü.get_sizes(gigims, prepath="./images/")
                                    elif i == "Lebensmittel":
                                        ges1 = bü.get_size("./lebensmittel.py")
                                        ges2 = bü.get_size("./programdata/lebensmittel")
                                    elif i == "Das große Quiz":
                                        ges1 = bü.get_size("./quiz.py")
                                        ges4 = bü.get_sizes(quizmusic, prepath="./music/")
                                    elif i == "Rechnungen":
                                        ges1 = bü.get_size("./Rechnung.pyw")
                                        ges3 = bü.get_size("./programdata/rechnungen/rechnung.ico")
                                        ges2 = bü.get_size("./programdata/rechnungen") - ges3
                                    elif i == "BüroMail":
                                        ges1 = bü.get_sizes(["./mail.py", "./mail_agent.pyw"])
                                        ges2 = bü.get_size("./programdata/mail")
                                    elif i == "BüroBank":
                                        ges1 = bü.get_size("./bank.py")
                                        ges3 = bü.get_size("./programdata/bank/money.ico")
                                    elif i == "Events":
                                        ges3 = bü.get_sizes(["./programdata/ads", "./programdata/lkims"])
                                        ges2 = bü.get_size("./programdata/win")
                                        if PREMIUM:
                                            ges2 += bü.get_size("./premiumpass.txt")
                                    elif i == "Büro":
                                        ges1 = bü.get_sizes(["./büro.py", "./bueroUtils.py"])
                                        ges2 = bü.get_sizes(["./programdata/buero", "./programdata/run"])
                                        ges3 = bü.get_size("./programdata/achievements")
                                    elif i == "System":
                                        ges1 = bü.get_sizes(["./fehleranalyse.py", "./update.py"])
                                        ges2 = bü.get_size("./programdata/update")
                                    elif i == "Hintergrundsystem":
                                        ges1 = bü.get_size("./systemupdate.py")
                                    elif i == "gesamt":
                                        ges1 = listToInt(ges5)
                                        ges2 = listToInt(ges6)
                                        ges3 = listToInt(ges7)
                                        ges4 = listToInt(ges8)
                                    ges5.append(ges1);ges6.append(ges2);ges7.append(ges3);ges8.append(ges4)
                                    ges9.append(ges1+ges2+ges3+ges4)
                                ges9Compare = ges9.copy()
                                ges9Compare.remove(max(ges9Compare))
                                for i in in2:
                                    idx = in2.index(i)
                                    a = ges5[idx];b = ges6[idx];c = ges7[idx];d = ges8[idx];e = ges9[idx]
                                    at += "\n"+i+": "+(22-len(i))*"-"+" "+bü.trafficer(e, min(ges9Compare), max(ges9Compare), duo=False, mthd=nsize, traffic_col=TCOLORS)+cOl.RESET_ALL+" "+(10-len(nsize(e)))*"-"+\
                                          " ( "+bü.trafficer(a, min(ges5), max(ges5[0:-1]), duo=False, mthd=nsize, traffic_col=TCOLORS)+cOl.RESET_ALL+" "+(10-len(nsize(a)))*"-"+\
                                          " / "+bü.trafficer(b, min(ges6), max(ges6[0:-1]), duo=False, mthd=nsize, traffic_col=TCOLORS)+cOl.RESET_ALL+" "+(10-len(nsize(b)))*"-"+\
                                          " / "+bü.trafficer(c, min(ges7), max(ges7[0:-1]), duo=False, mthd=nsize, traffic_col=TCOLORS)+cOl.RESET_ALL+" "+(10-len(nsize(c)))*"-"+\
                                          " / "+bü.trafficer(d, min(ges8), max(ges8[0:-1]), duo=False, mthd=nsize, traffic_col=TCOLORS)+cOl.RESET_ALL+" "+(10-len(nsize(d)))*"-"+" )"
                                st.finish_one_bar()
                                print(at)
                            elif antwort3 == "Deinstallieren":
                                if bü.PIN_check(PIN_e, lenge, act):
                                    deinstalllist = installiert.copy()
                                    deinstalllist.append("Büro");deinstalllist.append("Quit")
                                    antwort4 = bü.buttonLog("Welches der installierten Programme wollen Sie deinstallieren?", "Deinstallation", deinstalllist)
                                    if antwort4 != "Quit" and antwort4 != "":
                                        antwort5 = bü.buttonLog(title=antwort4+" deinstallieren")
                                        if antwort5 == "Fortfahren":
                                            if antwort4 != "Büro":
                                                os.remove("./programdata/buero/versioninfo_"+antwort4+".txt")
                                            if antwort4 == "Verschlüsseler":
                                                os.remove("./verschlüsseln.py")
                                                shutil.rmtree("./shopping")
                                                shutil.rmtree("./programdata/verschlüsseln")
                                            elif antwort4 == "Haustier":
                                                os.remove("./Haustier.py")
                                                shutil.rmtree("./programdata/haustier")
                                            elif antwort4 == "Ballonfahrt":
                                                bü.remove_(["Ballonfahrt.py", "Ballonfahrt-M2_1.py", "Ballonfahrt-M2_2.py"])
                                                bü.remove_(balims, "./images/")
                                                shutil.rmtree("./programdata/ballonfahrt")
                                            elif antwort4 == "SchingSchangSchongIQ":
                                                os.remove("./SchingSchangSchongIntelligent.py")
                                                shutil.rmtree("./programdata/schingschangschongiq")
                                            elif antwort4 == "abstrakte Verzerrung":
                                                os.remove("./abstrakt.py")
                                                shutil.rmtree("./programdata/abstrakt")
                                            elif antwort4 == "im Verlies":
                                                bü.remove_(["quest.py", "level-editor.py"])
                                                shutil.rmtree("./programdata/im Verlies")
                                                bü.remove_(imlist, "./images/")
                                            elif antwort4 == "Passwortgenerator":
                                                os.remove("./Passwortgenerator.py")
                                                shutil.rmtree("./programdata/password")
                                            elif antwort4 == "Musik":
                                                os.remove("./Musik.py")
                                                shutil.rmtree("./programdata/music")
                                            elif antwort4 == "Garten im Glück":
                                                os.remove("./Garten-im-Glück.py")
                                                bü.remove_(gigims, "./images/")
                                            elif antwort4 == "Lebensmittel":
                                                os.remove("./lebensmittel.py")
                                                shutil.rmtree("./programdata/lebensmittel")
                                            elif antwort4 == "Das große Quiz":
                                                os.remove("./quiz.py")
                                                bü.remove_(quizmusic, "./music/")
                                            elif antwort4 == "Rechnungen":
                                                os.remove("./Rechnung.pyw")
                                                shutil.rmtree("./programdata/rechnungen")
                                            elif antwort4 == "BüroMail":
                                                bü.remove_(["./mail.py", "./mail_agent.pyw"])
                                                shutil.rmtree("./programdata/mail")
                                            elif antwort4 == "BüroBank":
                                                os.remove("./bank.py")
                                                shutil.rmtree("./programdata/bank")
                                            elif antwort4 == "Büro":
                                                antwort6 = py.confirm("WARNUNG!\nDiese Änderung ist nicht umkehrbar!",\
                                                                      "WARNUNG", buttons=("Fortfahren", "Abbrechen"))
                                                dLg.entry(antwort6)
                                                if antwort6 == "Fortfahren":
                                                    threading.Thread(target=bü.uninstallmessage).start()
                                                    shutil.rmtree("./")
                                                    print("Büro wurde deinstalliert!"); quit(code="BÜRO UNINSTALLED!")
                                            else:
                                                dLg.entry("Fehlerhafter Wert zum Deinstallieren angegeben!!!")
                                                bü.error_quit()
                                            installiert.remove(antwort4)
                                            for i in list_container + [PLUS]:
                                                if antwort4 in i:
                                                    i.remove(antwort4)
                                            bü.restart()
                            elif antwort3 == "DebugLogInfo":
                                antwort4 = bü.buttonLog("Ihre Büro-DebugLogs verbrauchen aktuell {} Speicherplatz".format(nsize(bü.get_size("./programdata/buero/debug"))),\
                                                      "DebugLogInfo", ("Zurück", "Logs löschen"))
                                if antwort4 == "Logs löschen":
                                    if bü.PIN_check(PIN_e, lenge, act):
                                        bü.remove_(os.listdir(BPATH+"debug"), BPATH+"/debug/")
                            elif antwort3 == "Aufräumen":
                                py.alert("Momentan kann nichts aufgeräumt werden.", "Aufräumen")
                            elif antwort3 == "More coming soon...":
                                py.alert("Ihre Auswahl beinhaltet keine Aktionen und wird daher abgebrochen.", "invalide Auswahl")
                            elif antwort3 == "Zurück":
                                break
                            else:
                                bü.error_quit()
                            dLg.presave_log()
                    else:
                        if not skipwin:
                            antwort = "TEST"; break
                        else:
                            dLg.entrys("skipwin var reached TEST barrier", "letting skipwin mode pass"); break
                dLg.presave_log()
            elif antwort == "Zurück":
                break
            elif antwort == "Quit":
                bü.normal_quit()
            else:
                bü.error_quit()
